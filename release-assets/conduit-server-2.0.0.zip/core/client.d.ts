import type { IMessage } from "@conduit/shared";
import type { WebSocket } from "ws";
/** Public interface for a connected signaling client. */
export interface IClient {
    /** Unique client identifier. */
    readonly id: string;
    /** Authentication token for this session. */
    readonly token: string;
    /** The underlying WebSocket, or `null` if disconnected. */
    readonly socket: WebSocket | null;
    /** Timestamp of the last heartbeat ping. */
    readonly lastPing: number;
    /** Attach or detach the WebSocket for this client. */
    setSocket(socket: WebSocket | null): void;
    /** Send a signaling message; returns `true` on success. */
    send(message: IMessage): boolean;
    /** Record a heartbeat ping. */
    updateLastPing(): void;
}
/** Default {@link IClient} implementation backed by a WebSocket. */
export declare class Client implements IClient {
    readonly id: string;
    readonly token: string;
    private _socket;
    private _lastPing;
    constructor(id: string, token: string);
    /** The underlying WebSocket, or `null` if disconnected. */
    get socket(): WebSocket | null;
    /** Timestamp of the last heartbeat ping. */
    get lastPing(): number;
    /** Attach or detach the WebSocket for this client. */
    setSocket(socket: WebSocket | null): void;
    /** Send a signaling message to the client; returns `true` on success. */
    send(message: IMessage): boolean;
    /** Record a heartbeat ping with the current timestamp. */
    updateLastPing(): void;
}
//# sourceMappingURL=client.d.ts.map