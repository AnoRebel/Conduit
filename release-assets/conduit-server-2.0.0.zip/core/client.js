/** Default {@link IClient} implementation backed by a WebSocket. */
export class Client {
    id;
    token;
    _socket = null;
    _lastPing = Date.now();
    constructor(id, token) {
        this.id = id;
        this.token = token;
    }
    /** The underlying WebSocket, or `null` if disconnected. */
    get socket() {
        return this._socket;
    }
    /** Timestamp of the last heartbeat ping. */
    get lastPing() {
        return this._lastPing;
    }
    /** Attach or detach the WebSocket for this client. */
    setSocket(socket) {
        this._socket = socket;
    }
    /** Send a signaling message to the client; returns `true` on success. */
    send(message) {
        if (this._socket?.readyState !== 1) {
            return false;
        }
        try {
            this._socket.send(JSON.stringify(message));
            return true;
        }
        catch {
            return false;
        }
    }
    /** Record a heartbeat ping with the current timestamp. */
    updateLastPing() {
        this._lastPing = Date.now();
    }
}
//# sourceMappingURL=client.js.map