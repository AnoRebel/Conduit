import { createHash, randomBytes } from "node:crypto";
import { MessageQueue } from "./messageQueue.js";
/** How long a released peer ID is remembered, in milliseconds. */
const RELEASED_ID_TTL = 10 * 60 * 1000;
/** In-memory implementation of {@link IRealm}. */
export class Realm {
    _clients = new Map();
    _messageQueue = new MessageQueue();
    /** IDs previously held by a session, kept briefly to detect ID takeover. */
    _releasedIds = new Map();
    /** IDs this server issued, which are unguessable by construction. */
    _serverGeneratedIds = new Set();
    /** Look up a client by ID. */
    getClient(id) {
        return this._clients.get(id);
    }
    /** Return all connected client IDs. */
    getClientIds() {
        return Array.from(this._clients.keys());
    }
    /** Register a client in the realm. */
    setClient(client) {
        this._clients.set(client.id, client);
    }
    /** Remove and return a client by ID. */
    removeClient(id) {
        const client = this._clients.get(id);
        if (client) {
            this._clients.delete(id);
            // Remember that this ID was held, so a later claimant presenting a
            // different token does not inherit mail addressed to this session.
            this.releaseId(id, client.token);
        }
        return client;
    }
    /** Access the realm's message queue. */
    getMessageQueue() {
        return this._messageQueue;
    }
    /** Generate a unique client ID. */
    generateClientId() {
        let id;
        do {
            id = this._randomId();
        } while (this._clients.has(id));
        this._serverGeneratedIds.add(id);
        return id;
    }
    /** Check whether a client with the given ID exists. */
    clientExists(id) {
        return this._clients.has(id);
    }
    /** Whether a connection may collect the messages queued for a peer ID. */
    mayCollectQueuedMessages(id, token) {
        this._pruneReleasedIds();
        const released = this._releasedIds.get(id);
        // Never held before: the queue belongs to this first connector.
        if (!released) {
            return true;
        }
        // Held before by this same token: the original peer returning.
        return released.tokenHash === this._hashToken(token);
    }
    /** Record that a peer ID has been released by its holder. */
    releaseId(id, token) {
        this._releasedIds.set(id, {
            tokenHash: this._hashToken(token),
            releasedAt: Date.now(),
            serverGenerated: this._serverGeneratedIds.has(id),
        });
        this._serverGeneratedIds.delete(id);
        this._pruneReleasedIds();
    }
    _pruneReleasedIds() {
        const cutoff = Date.now() - RELEASED_ID_TTL;
        for (const [id, entry] of this._releasedIds) {
            if (entry.releasedAt < cutoff) {
                this._releasedIds.delete(id);
            }
        }
    }
    /**
     * Fingerprint a session token.
     *
     * Only the digest is retained, so the released-ID table never holds a value
     * that could be replayed if it leaked.
     */
    _hashToken(token) {
        return createHash("sha256").update(token).digest("base64");
    }
    _randomId() {
        // Use cryptographically secure random bytes
        return randomBytes(12).toString("base64url");
    }
}
//# sourceMappingURL=realm.js.map