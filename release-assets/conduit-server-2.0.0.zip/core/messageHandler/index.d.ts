import { type IMessage } from "@conduit/shared";
import type { ServerConfig } from "../../config.js";
import type { IClient } from "../client.js";
import type { IRealm } from "../realm.js";
/** Strategy interface for handling incoming signaling messages. */
export interface MessageHandler {
    /** Route a message from the given client to the appropriate handler. */
    handle(client: IClient, message: IMessage): void;
}
/** Built-in {@link MessageHandler} that dispatches messages by {@link MessageType}. */
export declare class DefaultMessageHandler implements MessageHandler {
    private readonly realm;
    private readonly config;
    constructor(realm: IRealm, config: ServerConfig);
    /** Route a message from the given client to the appropriate handler based on its {@link MessageType}. */
    handle(client: IClient, message: IMessage): void;
}
//# sourceMappingURL=index.d.ts.map