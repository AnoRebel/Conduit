import { MessageType } from "@conduit/shared";
import { handleHeartbeat } from "./handlers/heartbeat.js";
import { handleRelay, handleRelayClose, handleRelayOpen } from "./handlers/relay.js";
import { handleAnswer, handleCandidate, handleLeave, handleOffer, } from "./handlers/transmission.js";
/** Built-in {@link MessageHandler} that dispatches messages by {@link MessageType}. */
export class DefaultMessageHandler {
    realm;
    config;
    constructor(realm, config) {
        this.realm = realm;
        this.config = config;
    }
    /** Route a message from the given client to the appropriate handler based on its {@link MessageType}. */
    handle(client, message) {
        const { type } = message;
        switch (type) {
            case MessageType.HEARTBEAT:
                handleHeartbeat(client);
                break;
            case MessageType.OFFER:
                handleOffer(client, message, this.realm);
                break;
            case MessageType.ANSWER:
                handleAnswer(client, message, this.realm);
                break;
            case MessageType.CANDIDATE:
                handleCandidate(client, message, this.realm);
                break;
            case MessageType.LEAVE:
                handleLeave(client, message, this.realm);
                break;
            case MessageType.RELAY:
                handleRelay(client, message, this.realm, this.config);
                break;
            case MessageType.RELAY_OPEN:
                handleRelayOpen(client, message, this.realm, this.config);
                break;
            case MessageType.RELAY_CLOSE:
                handleRelayClose(client, message, this.realm, this.config);
                break;
            default:
                // Unknown message type, ignore
                break;
        }
    }
}
//# sourceMappingURL=index.js.map