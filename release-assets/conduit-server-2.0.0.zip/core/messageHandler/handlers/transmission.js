import { MessageType } from "@conduit/shared";
import { validateId } from "../../validation.js";
export function handleTransmission(client, message, realm) {
    const { type, dst, payload } = message;
    if (!dst) {
        return;
    }
    // A destination must satisfy the same format rules as a peer ID. Without this
    // an arbitrary string becomes a message-queue key, letting a client grow the
    // queue map without bound by transmitting to destinations that never exist.
    if (!validateId(dst).valid) {
        client.send({
            type: MessageType.ERROR,
            payload: { msg: "Invalid destination" },
        });
        return;
    }
    const destinationClient = realm.getClient(dst);
    if (destinationClient) {
        // Destination client is online, send directly
        const transmitted = {
            type,
            src: client.id,
            dst,
            payload,
        };
        const sent = destinationClient.send(transmitted);
        if (!sent) {
            // Failed to send, queue the message
            realm.getMessageQueue().addMessage(dst, transmitted);
        }
    }
    else {
        // Destination client is offline, queue the message
        const transmitted = {
            type,
            src: client.id,
            dst,
            payload,
        };
        realm.getMessageQueue().addMessage(dst, transmitted);
    }
}
export function handleOffer(client, message, realm) {
    handleTransmission(client, message, realm);
}
export function handleAnswer(client, message, realm) {
    handleTransmission(client, message, realm);
}
export function handleCandidate(client, message, realm) {
    handleTransmission(client, message, realm);
}
export function handleLeave(client, message, realm) {
    const { dst } = message;
    if (!dst) {
        return;
    }
    const destinationClient = realm.getClient(dst);
    if (destinationClient) {
        destinationClient.send({
            type: MessageType.LEAVE,
            src: client.id,
            dst,
        });
    }
}
//# sourceMappingURL=transmission.js.map