import type { RawData, WebSocket } from "ws";
import { type ServerConfig } from "../config.js";
import { type ILogger } from "../logger.js";
import { type IClient } from "./client.js";
import { type MessageHandler } from "./messageHandler/index.js";
import { type IRealm } from "./realm.js";
/** The core Conduit signaling server — transport-agnostic. */
export interface ConduitServerCore {
    /** The realm that tracks all connected clients and queued messages. */
    readonly realm: IRealm;
    /** Resolved server configuration. */
    readonly config: ServerConfig;
    /** Structured logger instance. */
    readonly logger: ILogger;
    /**
     * Process a new WebSocket connection; returns the client or `null` on rejection.
     *
     * @param address - Transport-level source address, used for ban checks. Adapters
     * that cannot determine it may omit it; ban-by-address is then not enforced.
     */
    handleConnection(socket: WebSocket, id: string, token: string, key: string, address?: string): IClient | null;
    /** Process an incoming WebSocket message from an authenticated client. */
    handleMessage(client: IClient, data: RawData | string): void;
    /** Handle a client WebSocket disconnect. */
    handleDisconnect(client: IClient): void;
    /** Generate a cryptographically random, collision-free client ID. */
    generateClientId(): string;
    /** Start background maintenance tasks (heartbeat checks, message expiry). */
    start(): void;
    /** Stop all background tasks and release resources. */
    stop(): void;
}
/**
 * Decides whether a connection attempt is banned.
 *
 * Supplied by the host application -- typically `@conduit/admin`, which owns the
 * ban list. The server deliberately holds no ban state of its own: admin is an
 * optional dependency, and duplicating the list here would create a sync problem.
 *
 * @param clientId - Peer ID the connection is claiming.
 * @param address - Transport-level source address, when the adapter knows it.
 * @returns `true` to refuse the connection.
 */
export type BanPredicate = (clientId: string, address?: string) => boolean;
/** Options accepted by {@link createConduitServerCore}. */
export interface CreateConduitServerCoreOptions {
    /** Partial server configuration (merged with defaults). */
    config?: Partial<ServerConfig>;
    /** Custom message handler; uses {@link DefaultMessageHandler} when omitted. */
    messageHandler?: MessageHandler;
    /** Callback invoked when a client successfully connects. */
    onClientConnect?: (client: IClient) => void;
    /** Callback invoked when a client disconnects. */
    onClientDisconnect?: (clientId: string) => void;
    /**
     * Optional ban check consulted before a client is admitted. When omitted the
     * server admits clients as normal.
     */
    isBanned?: BanPredicate;
}
/** Create a new transport-agnostic Conduit signaling server core. */
export declare function createConduitServerCore(options?: CreateConduitServerCoreOptions): ConduitServerCore;
export { Client, type IClient } from "./client.js";
export { DefaultMessageHandler, type MessageHandler } from "./messageHandler/index.js";
export { type IMessageQueue, MessageQueue } from "./messageQueue.js";
export { type IRealm, Realm } from "./realm.js";
//# sourceMappingURL=index.d.ts.map