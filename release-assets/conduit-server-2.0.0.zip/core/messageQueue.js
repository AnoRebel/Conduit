/** In-memory implementation of {@link IMessageQueue}. */
export class MessageQueue {
    _queues = new Map();
    _lastReadAt = new Map();
    /** Retrieve and drain all queued messages for the given client ID. */
    getMessages(id) {
        const queue = this._queues.get(id);
        if (!queue) {
            return [];
        }
        // Return and clear messages
        const messages = [...queue];
        this._queues.delete(id);
        this._lastReadAt.set(id, Date.now());
        return messages;
    }
    /** Enqueue a message for the given client ID. */
    addMessage(id, message) {
        let queue = this._queues.get(id);
        if (!queue) {
            queue = [];
            this._queues.set(id, queue);
        }
        queue.push(message);
    }
    /** Remove all queued messages for the given client ID. */
    clearMessages(id) {
        this._queues.delete(id);
        this._lastReadAt.delete(id);
    }
    /** Timestamp of the last message retrieval for the given client ID. */
    getLastReadAt(id) {
        return this._lastReadAt.get(id) || 0;
    }
}
//# sourceMappingURL=messageQueue.js.map