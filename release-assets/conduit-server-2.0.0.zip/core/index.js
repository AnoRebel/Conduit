import { timingSafeEqual } from "node:crypto";
import { MessageType } from "@conduit/shared";
import { createConfig } from "../config.js";
import { createLogger, wrapLogger } from "../logger.js";
import { Client } from "./client.js";
import { DefaultMessageHandler } from "./messageHandler/index.js";
import { RateLimiter } from "./rateLimiter.js";
import { Realm } from "./realm.js";
import { CheckBrokenConnections } from "./services/checkBrokenConnections.js";
import { MessagesExpire } from "./services/messagesExpire.js";
import { MAX_MESSAGE_SIZE, safeJsonParse, validateId, validateMessage, validateToken, } from "./validation.js";
/**
 * Constant-time string comparison to prevent timing attacks on API key validation.
 */
function safeCompare(a, b) {
    const bufA = Buffer.from(a);
    const bufB = Buffer.from(b);
    if (bufA.length !== bufB.length) {
        // Compare against self to maintain constant time even for different lengths
        timingSafeEqual(bufA, bufA);
        return false;
    }
    return timingSafeEqual(bufA, bufB);
}
/** Create a new transport-agnostic Conduit signaling server core. */
export function createConduitServerCore(options = {}) {
    const config = createConfig(options.config);
    // Initialize structured logger
    const pinoLogger = createLogger({
        level: config.logging.level,
        pretty: config.logging.pretty,
    });
    const logger = wrapLogger(pinoLogger);
    const realm = new Realm();
    const messageHandler = options.messageHandler ?? new DefaultMessageHandler(realm, config);
    const checkBrokenConnections = new CheckBrokenConnections(realm, config, {
        onClose: clientId => {
            // Clean up rate limiter when client is removed
            rateLimiter.removeClient(clientId);
            options.onClientDisconnect?.(clientId);
        },
    });
    const messagesExpire = new MessagesExpire(realm, config);
    // Rate limiter for per-client message limiting
    const rateLimiter = new RateLimiter({
        maxTokens: config.rateLimit.maxTokens,
        refillRate: config.rateLimit.refillRate,
    });
    function handleConnection(socket, id, token, key, address) {
        const clientLogger = logger.child({ clientId: id });
        // Validate ID format
        const idValidation = validateId(id);
        if (!idValidation.valid) {
            clientLogger.warn("Connection rejected: invalid ID format");
            socket.send(JSON.stringify({
                type: MessageType.ERROR,
                payload: { msg: idValidation.error || "Invalid ID" },
            }));
            socket.close();
            return null;
        }
        // Validate token format
        const tokenValidation = validateToken(token);
        if (!tokenValidation.valid) {
            clientLogger.warn("Connection rejected: invalid token format");
            socket.send(JSON.stringify({
                type: MessageType.ERROR,
                payload: { msg: tokenValidation.error || "Invalid token" },
            }));
            socket.close();
            return null;
        }
        // Validate key (constant-time comparison to prevent timing attacks)
        // Skip validation when auth mode is "none"
        if (config.auth.mode === "key" && !safeCompare(key, config.key)) {
            clientLogger.warn("Connection rejected: invalid API key");
            socket.send(JSON.stringify({
                type: MessageType.ERROR,
                payload: { msg: "Invalid key provided" },
            }));
            socket.close();
            return null;
        }
        // Reject banned peers. Checked after key validation so that an
        // unauthenticated caller cannot use the response as a ban-list oracle.
        if (options.isBanned?.(id, address)) {
            clientLogger.warn("Connection rejected: banned");
            socket.send(JSON.stringify({
                type: MessageType.ERROR,
                payload: { msg: "Banned" },
            }));
            socket.close();
            return null;
        }
        // Check if ID is already taken
        const existingClient = realm.getClient(id);
        if (existingClient && existingClient.token !== token) {
            clientLogger.warn("Connection rejected: ID already taken");
            socket.send(JSON.stringify({
                type: MessageType.ID_TAKEN,
                payload: { msg: "ID is already taken" },
            }));
            socket.close();
            return null;
        }
        // Check concurrent limit
        if (realm.getClientIds().length >= config.concurrentLimit) {
            clientLogger.warn("Connection rejected: server at capacity");
            socket.send(JSON.stringify({
                type: MessageType.ERROR,
                payload: { msg: "Server has reached connection limit" },
            }));
            socket.close();
            return null;
        }
        // Whether this connection may collect mail queued for the ID. Decided
        // before the client is registered, since registering makes it "existing".
        const mayCollectQueue = existingClient
            ? true // Same live session: the token was already checked above.
            : realm.mayCollectQueuedMessages(id, token);
        // Create or update client
        let client;
        if (existingClient) {
            // Reconnecting client
            existingClient.setSocket(socket);
            client = existingClient;
            clientLogger.info("Client reconnected");
        }
        else {
            // New client
            client = new Client(id, token);
            client.setSocket(socket);
            realm.setClient(client);
            clientLogger.info("Client connected");
        }
        // Send OPEN message
        socket.send(JSON.stringify({
            type: MessageType.OPEN,
        }));
        // Deliver any queued messages. getMessages() also clears the queue, so a
        // party that may not collect them discards the mail rather than leaving it
        // for the next claimant.
        const queuedMessages = realm.getMessageQueue().getMessages(id);
        if (queuedMessages.length > 0) {
            if (mayCollectQueue) {
                clientLogger.debug("Delivering queued messages", queuedMessages.length);
                for (const message of queuedMessages) {
                    client.send(message);
                }
            }
            else {
                clientLogger.warn("Discarding messages queued for a previously-held ID", queuedMessages.length);
            }
        }
        options.onClientConnect?.(client);
        return client;
    }
    function handleMessage(client, data) {
        const clientLogger = logger.child({ clientId: client.id });
        // Rate limiting check (if enabled)
        if (config.rateLimit.enabled && !rateLimiter.tryConsume(client.id)) {
            clientLogger.warn("Rate limit exceeded");
            client.send({
                type: MessageType.ERROR,
                payload: { msg: "Rate limit exceeded. Please slow down." },
            });
            return;
        }
        const text = typeof data === "string" ? data : data.toString();
        // Safe parse with size limit
        const maxSize = config.relay?.maxMessageSize || MAX_MESSAGE_SIZE;
        const parseResult = safeJsonParse(text, maxSize);
        if (!parseResult.success) {
            clientLogger.warn("Invalid message received", parseResult.error);
            client.send({
                type: MessageType.ERROR,
                payload: { msg: parseResult.error },
            });
            return;
        }
        // Validate message structure
        const messageValidation = validateMessage(parseResult.data, maxSize);
        if (!messageValidation.valid) {
            clientLogger.warn("Message validation failed", messageValidation.error);
            client.send({
                type: MessageType.ERROR,
                payload: { msg: messageValidation.error },
            });
            return;
        }
        const msg = parseResult.data;
        clientLogger.trace("Message received", msg.type);
        messageHandler.handle(client, msg);
    }
    function handleDisconnect(client) {
        logger.child({ clientId: client.id }).debug("Client disconnected");
        client.setSocket(null);
        // Don't remove the client immediately, allow for reconnection
        // The CheckBrokenConnections service will clean up if needed
        options.onClientDisconnect?.(client.id);
    }
    function generateClientId() {
        return realm.generateClientId();
    }
    function start() {
        logger.info("Starting Conduit server core");
        checkBrokenConnections.start();
        messagesExpire.start();
    }
    function stop() {
        logger.info("Stopping Conduit server core");
        checkBrokenConnections.stop();
        messagesExpire.stop();
        rateLimiter.clear();
    }
    return {
        realm,
        config,
        logger,
        handleConnection,
        handleMessage,
        handleDisconnect,
        generateClientId,
        start,
        stop,
    };
}
export { Client } from "./client.js";
export { DefaultMessageHandler } from "./messageHandler/index.js";
export { MessageQueue } from "./messageQueue.js";
export { Realm } from "./realm.js";
//# sourceMappingURL=index.js.map