/**
 * @module @conduit/server/adapters/hono
 *
 * Hono middleware adapter for Conduit Server, including WebSocket signaling.
 *
 * ```typescript
 * import { Hono } from 'hono';
 * import { upgradeWebSocket, websocket } from 'hono/bun';
 * import { createConduitMiddleware } from '@conduit/server/adapters/hono';
 *
 * const app = new Hono();
 * const conduit = createConduitMiddleware();
 *
 * app.use('/conduit/*', conduit.middleware);
 * app.get('/conduit/ws', upgradeWebSocket(conduit.createWebSocketHandler));
 *
 * export default { fetch: app.fetch, websocket };
 * ```
 *
 * Hono's `upgradeWebSocket` is runtime-specific -- import it from `hono/bun`,
 * `hono/deno`, `hono/cloudflare-workers`, or `@hono/node-server` -- so this
 * adapter does not import it. It supplies the event handlers, and the caller
 * supplies the upgrade helper for the runtime they deploy to.
 */
import { type ConduitServerCore, type CreateConduitServerCoreOptions } from "../core/index.js";
interface HonoContext {
    req: {
        url: string;
        method: string;
        query: (key: string) => string | undefined;
        header: (key: string) => string | undefined;
    };
    json: (data: unknown, status?: number) => Response;
    text: (data: string, status?: number) => Response;
    header: (key: string, value: string) => void;
}
type HonoMiddleware = (c: HonoContext, next: () => Promise<void>) => Promise<Response | void>;
/**
 * Hono's WebSocket connection handle, structurally typed.
 *
 * Mirrors the `WSContext` passed to `upgradeWebSocket` handlers. Declared here
 * rather than imported because `hono` is an optional peer dependency.
 */
export interface HonoWSContext {
    send(data: string | ArrayBuffer | Uint8Array): void;
    close(code?: number, reason?: string): void;
    readyState: number;
}
/** A message event delivered to the `onMessage` handler. */
export interface HonoMessageEvent {
    data: unknown;
}
/** The handler object Hono's `upgradeWebSocket` expects. */
export interface HonoWSEvents {
    onOpen?(event: unknown, ws: HonoWSContext): void;
    onMessage?(event: HonoMessageEvent, ws: HonoWSContext): void;
    onClose?(event: unknown, ws: HonoWSContext): void;
    onError?(event: unknown, ws: HonoWSContext): void;
}
/** Options for the Hono adapter, extending core server options. */
export interface HonoAdapterOptions extends CreateConduitServerCoreOptions {
}
/** A Conduit server instance designed for the Hono framework. */
export interface HonoConduitServer {
    /** The Conduit server core that manages clients, realms, and message routing. */
    readonly core: ConduitServerCore;
    /** Hono middleware that handles HTTP requests and CORS for Conduit routes. */
    readonly middleware: HonoMiddleware;
    /** Get an array of route definitions for manual registration with a Hono app. */
    getRoutes(): {
        path: string;
        method: string;
        handler: (c: HonoContext) => Response | Promise<Response>;
    }[];
    /**
     * Build the WebSocket event handlers for a signaling connection.
     *
     * Pass this straight to your runtime's `upgradeWebSocket`:
     *
     * ```typescript
     * app.get('/conduit/ws', upgradeWebSocket(conduit.createWebSocketHandler));
     * ```
     *
     * Connection parameters are read from the query string (`key`, `id`,
     * `token`), and the origin allowlist is enforced before the socket is
     * admitted, matching the node and bun adapters.
     */
    createWebSocketHandler(c: HonoContext): HonoWSEvents;
    /** Stop the Conduit server core and release resources. */
    destroy(): void;
}
/**
 * Create a Conduit signaling server as Hono middleware.
 *
 * @param options - Adapter options including server configuration.
 * @returns A {@link HonoConduitServer} with middleware and route helpers.
 */
export declare function createConduitMiddleware(options?: HonoAdapterOptions): HonoConduitServer;
export default createConduitMiddleware;
//# sourceMappingURL=hono.d.ts.map