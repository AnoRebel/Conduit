/**
 * @module @conduit/server/adapters/bun
 *
 * Bun.serve adapter for Conduit Server.
 *
 * ```typescript
 * import { createConduitServer } from '@conduit/server/adapters/bun';
 *
 * const server = createConduitServer({ config: { port: 9000 } });
 * ```
 */
import { MessageType, VERSION } from "@conduit/shared";
import { resolveCorsOrigin } from "../core/cors.js";
import { createConduitServerCore, } from "../core/index.js";
/**
 * Create a Conduit signaling server optimised for the Bun runtime.
 *
 * @param options - Adapter options including server configuration.
 * @returns A {@link BunConduitServer} that can be started with {@link BunConduitServer.serve | serve()}.
 */
export function createConduitServer(options = {}) {
    const core = createConduitServerCore(options);
    const config = core.config;
    const clients = new Map();
    function getServeOptions() {
        return {
            port: config.port,
            hostname: config.host,
            fetch(request, server) {
                const url = new URL(request.url);
                const pathname = url.pathname;
                // Set CORS headers
                const corsHeaders = getCorsHeaders(config, request.headers.get("origin") ?? undefined);
                // HTTPS enforcement check
                if (config.requireSecure) {
                    const proto = request.headers.get("x-forwarded-proto");
                    const isSecure = proto === "https" || url.protocol === "https:";
                    if (!isSecure) {
                        return new Response(JSON.stringify({ error: "HTTPS required" }), {
                            status: 403,
                            headers: { ...corsHeaders, "Content-Type": "application/json" },
                        });
                    }
                }
                // Handle preflight
                if (request.method === "OPTIONS") {
                    return new Response(null, { status: 200, headers: corsHeaders });
                }
                // WebSocket upgrade
                if (request.headers.get("upgrade") === "websocket") {
                    if (pathname === `${config.path}conduit` || pathname === `${config.path}/conduit`) {
                        // Validate origin if allowedOrigins is configured
                        if (config.allowedOrigins && config.allowedOrigins.length > 0) {
                            const origin = request.headers.get("origin");
                            if (!origin || !config.allowedOrigins.includes(origin)) {
                                return new Response("Forbidden", { status: 403 });
                            }
                        }
                        const key = url.searchParams.get("key");
                        const id = url.searchParams.get("id");
                        const token = url.searchParams.get("token");
                        // key is required when auth mode is "key", optional when "none"
                        if ((!key && config.auth.mode === "key") || !id || !token) {
                            return new Response("Missing parameters", { status: 400 });
                        }
                        // @ts-expect-error - Bun's server.upgrade signature
                        const upgraded = server.upgrade(request, {
                            data: { id, token, key: key || config.key },
                        });
                        if (upgraded) {
                            return undefined;
                        }
                        return new Response("WebSocket upgrade failed", { status: 500 });
                    }
                }
                // Whether auth-less routes are available
                const noAuth = config.auth.mode === "none";
                // Route HTTP requests
                if (pathname === config.path || pathname === `${config.path}/`) {
                    return new Response(JSON.stringify({ name: "Conduit Server", version: VERSION }), {
                        headers: { ...corsHeaders, "Content-Type": "application/json" },
                    });
                }
                if (pathname === `${config.path}${config.key}/id` ||
                    pathname === `${config.path}/${config.key}/id` ||
                    (noAuth && (pathname === `${config.path}id` || pathname === `${config.path}/id`))) {
                    return new Response(core.generateClientId(), {
                        headers: { ...corsHeaders, "Content-Type": "text/plain" },
                    });
                }
                if (pathname === `${config.path}${config.key}/conduits` ||
                    pathname === `${config.path}/${config.key}/conduits` ||
                    (noAuth &&
                        (pathname === `${config.path}conduits` || pathname === `${config.path}/conduits`))) {
                    if (config.allowDiscovery) {
                        return new Response(JSON.stringify(core.realm.getClientIds()), {
                            headers: { ...corsHeaders, "Content-Type": "application/json" },
                        });
                    }
                    return new Response(JSON.stringify({ error: "Conduit discovery is disabled" }), {
                        status: 401,
                        headers: { ...corsHeaders, "Content-Type": "application/json" },
                    });
                }
                return new Response("Not Found", { status: 404 });
            },
            websocket: {
                open(ws) {
                    const { id, token, key } = ws.data;
                    // Create a WebSocket-like wrapper for the core
                    const wsWrapper = {
                        readyState: 1,
                        send: (data) => ws.send(data),
                        close: () => ws.close(),
                    };
                    const client = core.handleConnection(wsWrapper, id, token, key);
                    if (client) {
                        ws.data.client = client;
                        clients.set(ws, client);
                    }
                },
                message(ws, message) {
                    const client = clients.get(ws);
                    if (client) {
                        const data = typeof message === "string" ? message : new TextDecoder().decode(message);
                        core.handleMessage(client, data);
                    }
                },
                close(ws) {
                    const client = clients.get(ws);
                    if (client) {
                        core.handleDisconnect(client);
                        clients.delete(ws);
                    }
                },
            },
        };
    }
    function serve() {
        core.start();
        // @ts-expect-error - Bun global
        return Bun.serve(getServeOptions());
    }
    function close() {
        // Send GOAWAY message to all clients before closing
        const goawayMessage = JSON.stringify({
            type: MessageType.GOAWAY,
            payload: { msg: "Server is shutting down" },
        });
        for (const [ws] of clients) {
            try {
                ws.send(goawayMessage);
            }
            catch {
                // Ignore send errors during shutdown
            }
        }
        // Give clients a moment to receive the message before closing
        setTimeout(() => {
            for (const [ws] of clients) {
                try {
                    ws.close(1001, "Server shutdown");
                }
                catch {
                    // Ignore close errors during shutdown
                }
            }
            clients.clear();
            core.stop();
        }, 100);
    }
    return {
        core,
        serve,
        getServeOptions,
        close,
    };
}
function getCorsHeaders(config, requestOrigin) {
    const headers = {
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
    };
    const { allowOrigin, vary } = resolveCorsOrigin(requestOrigin, config.corsOrigin);
    if (allowOrigin !== undefined) {
        headers["Access-Control-Allow-Origin"] = allowOrigin;
    }
    if (vary) {
        headers.Vary = "Origin";
    }
    return headers;
}
export default createConduitServer;
//# sourceMappingURL=bun.js.map