/**
 * @module @conduit/server/adapters/fastify
 *
 * Fastify plugin adapter for Conduit Server.
 *
 * ```typescript
 * import Fastify from 'fastify';
 * import { fastifyConduitPlugin } from '@conduit/server/adapters/fastify';
 *
 * const fastify = Fastify();
 * fastify.register(fastifyConduitPlugin, { path: '/conduit' });
 * fastify.listen({ port: 9000 });
 * ```
 */
import type { IncomingMessage } from "node:http";
import { type CreateConduitServerCoreOptions } from "../core/index.js";
interface FastifyInstance {
    server: import("node:http").Server;
    get(path: string, handler: FastifyHandler): void;
    addHook(hook: string, handler: (...args: unknown[]) => void): void;
}
interface FastifyRequest {
    url: string;
    method: string;
    query: Record<string, string>;
    headers: Record<string, string | string[] | undefined>;
    raw: IncomingMessage;
}
interface FastifyReply {
    code(code: number): FastifyReply;
    header(key: string, value: string): FastifyReply;
    send(data: unknown): void;
}
type FastifyHandler = (request: FastifyRequest, reply: FastifyReply) => void | Promise<void>;
/** Options for the Fastify adapter, extending core server options. */
export interface FastifyAdapterOptions extends CreateConduitServerCoreOptions {
}
/**
 * Fastify plugin that registers Conduit signaling routes and WebSocket handling.
 *
 * @param fastify - The Fastify instance to register the plugin with.
 * @param options - Adapter options including server configuration.
 */
export declare function fastifyConduitPlugin(fastify: FastifyInstance, options?: FastifyAdapterOptions): Promise<void>;
export default fastifyConduitPlugin;
//# sourceMappingURL=fastify.d.ts.map