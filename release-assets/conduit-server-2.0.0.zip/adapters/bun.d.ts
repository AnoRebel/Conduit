/**
 * @module @conduit/server/adapters/bun
 *
 * Bun.serve adapter for Conduit Server.
 *
 * ```typescript
 * import { createConduitServer } from '@conduit/server/adapters/bun';
 *
 * const server = createConduitServer({ config: { port: 9000 } });
 * ```
 */
import { type ConduitServerCore, type CreateConduitServerCoreOptions, type IClient } from "../core/index.js";
interface BunWebSocket<T = unknown> {
    readonly data: T;
    readonly readyState: number;
    send(data: string | ArrayBuffer | Uint8Array): void;
    close(code?: number, reason?: string): void;
}
interface BunServer {
    readonly port: number;
    readonly hostname: string;
    stop(closeActiveConnections?: boolean): void;
}
/** Options for the Bun adapter, extending core server options. */
export interface BunAdapterOptions extends CreateConduitServerCoreOptions {
}
/** A Conduit server instance built for the Bun runtime. */
export interface BunConduitServer {
    /** The Conduit server core that manages clients, realms, and message routing. */
    readonly core: ConduitServerCore;
    /** Start the server via `Bun.serve()` and return the Bun server handle. */
    serve(): BunServer;
    /** Get the raw `Bun.serve()` options for advanced composition (e.g. adding custom routes). */
    getServeOptions(): BunServeOptions;
    /** Gracefully shut down the server, sending GOAWAY to connected clients first. */
    close(): void;
}
interface BunServeOptions {
    port: number;
    hostname: string;
    fetch: (request: Request, server: BunServer) => Response | Promise<Response>;
    websocket: {
        open: (ws: BunWebSocket<WebSocketData>) => void;
        message: (ws: BunWebSocket<WebSocketData>, message: string | ArrayBuffer) => void;
        close: (ws: BunWebSocket<WebSocketData>) => void;
    };
}
interface WebSocketData {
    client?: IClient;
    id: string;
    token: string;
    key: string;
}
/**
 * Create a Conduit signaling server optimised for the Bun runtime.
 *
 * @param options - Adapter options including server configuration.
 * @returns A {@link BunConduitServer} that can be started with {@link BunConduitServer.serve | serve()}.
 */
export declare function createConduitServer(options?: BunAdapterOptions): BunConduitServer;
export default createConduitServer;
//# sourceMappingURL=bun.d.ts.map