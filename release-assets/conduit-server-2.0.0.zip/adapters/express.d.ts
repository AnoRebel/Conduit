/**
 * @module @conduit/server/adapters/express
 *
 * Express middleware adapter for Conduit Server.
 *
 * ```typescript
 * import express from 'express';
 * import { ExpressConduitServer } from '@conduit/server/adapters/express';
 *
 * const app = express();
 * const server = app.listen(9000);
 * const conduitServer = ExpressConduitServer(server, { path: '/conduit' });
 *
 * app.use('/conduit', conduitServer);
 * ```
 */
import type { Server } from "node:http";
import { type CreateConduitServerCoreOptions } from "../core/index.js";
interface Request {
    url?: string;
    method?: string;
    headers?: Record<string, string | string[] | undefined>;
}
interface Response {
    setHeader(name: string, value: string): void;
    writeHead(statusCode: number, headers?: Record<string, string>): void;
    json(data: unknown): void;
    send(data: string): void;
    status(code: number): Response;
    end(data?: string): void;
}
type NextFunction = () => void;
type ExpressMiddleware = (req: Request, res: Response, next: NextFunction) => void;
/** Options for the Express adapter, extending core server options. */
export interface ExpressAdapterOptions extends CreateConduitServerCoreOptions {
}
/** An Express middleware that also exposes a {@link close} method for graceful shutdown. */
export interface ExpressConduitInstance extends ExpressMiddleware {
    /** Gracefully shut down the Conduit server, sending GOAWAY to connected clients. */
    close: () => void;
}
/**
 * Create an Express middleware that adds Conduit signaling routes and WebSocket handling.
 *
 * @param server - The underlying Node.js HTTP server (from `app.listen()`).
 * @param options - Adapter options including server configuration.
 * @returns An Express middleware function with an attached {@link ExpressConduitInstance.close | close()} method.
 */
export declare function ExpressConduitServer(server: Server, options?: ExpressAdapterOptions): ExpressMiddleware;
export default ExpressConduitServer;
//# sourceMappingURL=express.d.ts.map