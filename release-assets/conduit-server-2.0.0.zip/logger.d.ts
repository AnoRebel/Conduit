import { type LoggerOptions, type Logger as PinoLogger } from "pino";
/** Supported log levels, matching pino's level names. */
export type LogLevel = "fatal" | "error" | "warn" | "info" | "debug" | "trace" | "silent";
/** Options for configuring the pino-based structured logger. */
export interface LoggerConfig {
    /** Log level (default: "info") */
    level?: LogLevel;
    /** Pretty print logs (default: false, use true for development) */
    pretty?: boolean;
    /** Add timestamp to logs (default: true) */
    timestamp?: boolean;
    /** Custom pino options */
    pinoOptions?: LoggerOptions;
}
/**
 * Create or get the logger instance
 */
export declare function createLogger(config?: LoggerConfig): PinoLogger;
/**
 * Get the current logger instance or create a default one
 */
export declare function getLogger(): PinoLogger;
/**
 * Create a child logger with additional context
 */
export declare function createChildLogger(bindings: Record<string, unknown>): PinoLogger;
/**
 * Logger interface for the server core
 */
export interface ILogger {
    /** Log a fatal-level message (unrecoverable errors). */
    fatal(msg: string, ...args: unknown[]): void;
    /** Log an error-level message. */
    error(msg: string, ...args: unknown[]): void;
    /** Log a warning-level message. */
    warn(msg: string, ...args: unknown[]): void;
    /** Log an info-level message. */
    info(msg: string, ...args: unknown[]): void;
    /** Log a debug-level message. */
    debug(msg: string, ...args: unknown[]): void;
    /** Log a trace-level message (finest granularity). */
    trace(msg: string, ...args: unknown[]): void;
    /** Create a child logger with additional context bindings. */
    child(bindings: Record<string, unknown>): ILogger;
}
/**
 * Wrap pino logger to match ILogger interface
 */
export declare function wrapLogger(pinoLogger: PinoLogger): ILogger;
/** Convenience namespace bundling all logger factory functions. */
export declare const logger: {
    create: typeof createLogger;
    get: typeof getLogger;
    child: typeof createChildLogger;
    wrap: typeof wrapLogger;
};
export default logger;
//# sourceMappingURL=logger.d.ts.map