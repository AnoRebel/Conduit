import { error, json } from "./index.js";
export const auditRoutes = [
    {
        method: "GET",
        path: "/audit",
        requiresAuth: true,
        handler: ctx => {
            const { limit, user, action, start, end } = ctx.query;
            let entries;
            if (user) {
                entries = ctx.admin.audit.getEntriesByUser(user, limit ? parseInt(limit, 10) : undefined);
            }
            else if (action) {
                entries = ctx.admin.audit.getEntriesByAction(action, limit ? parseInt(limit, 10) : undefined);
            }
            else if (start && end) {
                const startTime = parseInt(start, 10);
                const endTime = parseInt(end, 10);
                if (Number.isNaN(startTime) || Number.isNaN(endTime)) {
                    return error("Invalid start or end timestamp");
                }
                entries = ctx.admin.audit.getEntriesInRange(startTime, endTime);
            }
            else {
                entries = ctx.admin.audit.getEntries(limit ? parseInt(limit, 10) : 100);
            }
            return json({
                entries,
                total: entries.length,
            });
        },
    },
    {
        method: "DELETE",
        path: "/audit",
        requiresAuth: true,
        handler: ctx => {
            const userId = ctx.auth.userId ?? "unknown";
            const count = ctx.admin.audit.size;
            // Log before clearing so this entry is included
            ctx.admin.audit.log("clear_audit", userId, { previousCount: count });
            ctx.admin.audit.clear();
            return json({
                success: true,
                message: `Cleared ${count} audit entries`,
                count,
            });
        },
    },
];
//# sourceMappingURL=audit.js.map