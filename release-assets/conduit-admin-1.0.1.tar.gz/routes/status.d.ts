import type { Route } from "./index.js";
export declare const statusRoutes: Route[];
//# sourceMappingURL=status.d.ts.map