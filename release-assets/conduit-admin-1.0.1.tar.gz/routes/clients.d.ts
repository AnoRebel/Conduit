import type { Route } from "./index.js";
export declare const clientRoutes: Route[];
//# sourceMappingURL=clients.d.ts.map