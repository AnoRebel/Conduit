import type { Route } from "./index.js";
export declare const configRoutes: Route[];
//# sourceMappingURL=config.d.ts.map