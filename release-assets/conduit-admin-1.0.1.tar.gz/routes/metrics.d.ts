import type { Route } from "./index.js";
export declare const metricsRoutes: Route[];
//# sourceMappingURL=metrics.d.ts.map