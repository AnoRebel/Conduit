import type { Route } from "./index.js";
export declare const auditRoutes: Route[];
//# sourceMappingURL=audit.d.ts.map