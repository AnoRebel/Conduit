import type { Route } from "./index.js";
export declare const bansRoutes: Route[];
//# sourceMappingURL=bans.d.ts.map