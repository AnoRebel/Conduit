/**
 * @module @conduit/admin
 *
 * Admin API and dashboard backend for Conduit signaling servers.
 * Provides authentication, metrics collection, audit logging, ban management,
 * and REST/SSE/WebSocket endpoints for real-time server monitoring.
 *
 * @example
 * ```typescript
 * import { createAdminCore, createAdminConfig } from '@conduit/admin';
 * import { createNodeAdminServer } from '@conduit/admin/adapters/node';
 *
 * const config = createAdminConfig({ auth: { methods: ['apiKey'] } });
 * const admin = createAdminCore({ config });
 * const server = createNodeAdminServer({ admin });
 * server.listen(9001);
 * ```
 */
// ============================================================================
// Authentication
// ============================================================================
export { ApiKeyAuth } from "./auth/apiKey.js";
export { BasicAuth } from "./auth/basic.js";
export { createAuthManager, } from "./auth/index.js";
export { JWTAuth } from "./auth/jwt.js";
export { SessionManager } from "./auth/session.js";
// ============================================================================
// Configuration
// ============================================================================
export { createAdminConfig, validateAdminConfig, } from "./config.js";
// ============================================================================
// Persistence
// ============================================================================
export { createPersistenceStore, MemoryStore, SQLiteStore, } from "./persistence/index.js";
// ============================================================================
// Core Admin Components
// ============================================================================
export { createAdminActions, createAdminCore, createAuditLogger, createBanManager, } from "./core/index.js";
// ============================================================================
// Metrics
// ============================================================================
export { 
// Classes
CircularTimeSeries, Counter, CounterMap, 
// Factory functions
createMetricsCollector, createMetricsProxy, Gauge, GaugeMap, instrumentServerCore, syncRealmToMetrics, TimeSeriesMap, } from "./metrics/index.js";
// ============================================================================
// Routes
// ============================================================================
export { createRoutes, 
// Response helpers
error, forbidden, json, notFound, unauthorized, } from "./routes/index.js";
// ============================================================================
// Server-Sent Events (SSE)
// ============================================================================
export { createSSERoutes, createSSEServer, } from "./sse/index.js";
// ============================================================================
// WebSocket
// ============================================================================
export { createAdminWSServer, createEvent, parseClientMessage, serializeEvent, } from "./websocket/index.js";
// ============================================================================
// Adapters
// ============================================================================
export { 
// Express
createExpressAdminMiddleware, 
// Fastify
createFastifyAdminPlugin, 
// Hono
createHonoAdminMiddleware, 
// Node
createNodeAdminServer, } from "./adapters/index.js";
// ============================================================================
// Standalone Mode (Multi-server management)
// ============================================================================
export { aggregateMetrics, aggregateStatus, createRemoteServer, createStandaloneAdmin, } from "./standalone/index.js";
//# sourceMappingURL=index.js.map