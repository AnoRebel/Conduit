import type { IncomingMessage } from "node:http";
import type { WebSocket } from "ws";
import type { AdminCore } from "../core/index.js";
import type { MetricsSnapshot } from "../types.js";
import { type AdminEventType, type ServerToClientEvents } from "./events.js";
/** A connected WebSocket client with subscription tracking. */
export interface AdminWSClient {
    id: string;
    socket: WebSocket;
    subscriptions: Set<AdminEventType>;
    authenticated: boolean;
    userId?: string;
}
/** WebSocket server for broadcasting real-time admin events to connected clients. */
export interface AdminWSServer {
    handleConnection(socket: WebSocket, request: IncomingMessage): void;
    broadcast<T extends AdminEventType>(type: T, data: ServerToClientEvents[T]): number;
    broadcastToSubscribers<T extends AdminEventType>(type: T, data: ServerToClientEvents[T]): number;
    getClients(): AdminWSClient[];
    getClientCount(): number;
    close(): void;
    emitClientConnected(clientId: string): void;
    emitClientDisconnected(clientId: string, reason: string): void;
    emitMetricsUpdate(snapshot: MetricsSnapshot): void;
    emitError(type: string, message: string): void;
}
/** Options for {@link createAdminWSServer}. */
export interface AdminWSServerOptions {
    admin: AdminCore;
    pingInterval?: number;
    metricsInterval?: number;
}
/**
 * Create a WebSocket server for real-time admin updates
 */
export declare function createAdminWSServer(options: AdminWSServerOptions): AdminWSServer;
export { type AdminEventMessage, type AdminEventType, type ClientToServerEvents, createEvent, parseClientMessage, type ServerToClientEvents, serializeEvent, } from "./events.js";
//# sourceMappingURL=server.d.ts.map