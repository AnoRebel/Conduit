import { parseClientMessage, serializeEvent, } from "./events.js";
/**
 * Create a WebSocket server for real-time admin updates
 */
export function createAdminWSServer(options) {
    const { admin, pingInterval = 30000, metricsInterval = 5000 } = options;
    const clients = new Map();
    let clientIdCounter = 0;
    let pingTimer = null;
    let metricsTimer = null;
    // Start periodic tasks
    startPingInterval();
    startMetricsInterval();
    function handleConnection(socket, request) {
        const clientId = `ws_${++clientIdCounter}_${Date.now()}`;
        // Authenticate via query string or headers
        const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
        const token = url.searchParams.get("token") ??
            url.searchParams.get("apiKey") ??
            request.headers["x-api-key"];
        let authResult = { valid: false, userId: undefined };
        if (token) {
            // Try API key first
            const apiKeyResult = admin.auth.validateApiKey(token);
            if (apiKeyResult.valid) {
                authResult = { valid: true, userId: apiKeyResult.userId };
            }
            else {
                // Try JWT
                const jwtResult = admin.auth.validateJWT(token);
                if (jwtResult.valid) {
                    authResult = { valid: true, userId: jwtResult.userId };
                }
            }
        }
        if (!authResult.valid) {
            socket.close(4001, "Unauthorized");
            return;
        }
        const client = {
            id: clientId,
            socket,
            subscriptions: new Set(["metrics:update", "client:connected", "client:disconnected"]),
            authenticated: true,
            userId: authResult.userId,
        };
        clients.set(clientId, client);
        // Send welcome message
        socket.send(JSON.stringify({
            type: "connected",
            data: {
                clientId,
                subscriptions: Array.from(client.subscriptions),
            },
        }));
        // Handle messages
        socket.on("message", (data) => {
            handleMessage(client, data);
        });
        // Handle close
        socket.on("close", () => {
            clients.delete(clientId);
        });
        // Handle errors
        socket.on("error", _err => {
            console.error(`WebSocket error for client ${clientId}:`);
            clients.delete(clientId);
        });
    }
    function handleMessage(client, data) {
        const text = data.toString();
        const message = parseClientMessage(text);
        if (!message) {
            return;
        }
        switch (message.type) {
            case "subscribe": {
                const payload = message.payload;
                const events = payload.events ?? [];
                for (const event of events) {
                    if (isValidEventType(event)) {
                        client.subscriptions.add(event);
                    }
                }
                client.socket.send(JSON.stringify({
                    type: "subscribed",
                    data: { events: Array.from(client.subscriptions) },
                }));
                break;
            }
            case "unsubscribe": {
                const payload = message.payload;
                const events = payload.events ?? [];
                for (const event of events) {
                    if (isValidEventType(event)) {
                        client.subscriptions.delete(event);
                    }
                }
                client.socket.send(JSON.stringify({
                    type: "unsubscribed",
                    data: { events: Array.from(client.subscriptions) },
                }));
                break;
            }
            case "ping": {
                client.socket.send(JSON.stringify({ type: "pong", data: {} }));
                break;
            }
        }
    }
    function broadcast(type, data) {
        const message = serializeEvent(type, data);
        let count = 0;
        for (const client of clients.values()) {
            if (client.socket.readyState === 1) {
                // OPEN
                try {
                    client.socket.send(message);
                    count++;
                }
                catch {
                    // Client may have disconnected
                }
            }
        }
        return count;
    }
    function broadcastToSubscribers(type, data) {
        const message = serializeEvent(type, data);
        let count = 0;
        for (const client of clients.values()) {
            if (client.subscriptions.has(type) && client.socket.readyState === 1) {
                try {
                    client.socket.send(message);
                    count++;
                }
                catch {
                    // Client may have disconnected
                }
            }
        }
        return count;
    }
    function getClients() {
        return Array.from(clients.values());
    }
    function getClientCount() {
        return clients.size;
    }
    function close() {
        if (pingTimer) {
            clearInterval(pingTimer);
            pingTimer = null;
        }
        if (metricsTimer) {
            clearInterval(metricsTimer);
            metricsTimer = null;
        }
        for (const client of clients.values()) {
            client.socket.close(1000, "Server shutting down");
        }
        clients.clear();
    }
    function startPingInterval() {
        pingTimer = setInterval(() => {
            for (const client of clients.values()) {
                if (client.socket.readyState === 1) {
                    client.socket.ping();
                }
            }
        }, pingInterval);
        if (pingTimer.unref) {
            pingTimer.unref();
        }
    }
    function startMetricsInterval() {
        metricsTimer = setInterval(() => {
            const snapshot = admin.getMetricsSnapshot();
            broadcastToSubscribers("metrics:update", snapshot);
        }, metricsInterval);
        if (metricsTimer.unref) {
            metricsTimer.unref();
        }
    }
    // Event emitters
    function emitClientConnected(clientId) {
        broadcastToSubscribers("client:connected", {
            id: clientId,
            timestamp: Date.now(),
        });
    }
    function emitClientDisconnected(clientId, reason) {
        broadcastToSubscribers("client:disconnected", {
            id: clientId,
            reason,
            timestamp: Date.now(),
        });
    }
    function emitMetricsUpdate(snapshot) {
        broadcastToSubscribers("metrics:update", snapshot);
    }
    function emitError(type, message) {
        broadcastToSubscribers("error:occurred", {
            type,
            message,
            timestamp: Date.now(),
        });
    }
    return {
        handleConnection,
        broadcast,
        broadcastToSubscribers,
        getClients,
        getClientCount,
        close,
        emitClientConnected,
        emitClientDisconnected,
        emitMetricsUpdate,
        emitError,
    };
}
function isValidEventType(event) {
    const validTypes = [
        "client:connected",
        "client:disconnected",
        "metrics:update",
        "error:occurred",
        "ban:added",
        "ban:removed",
        "audit:entry",
    ];
    return validTypes.includes(event);
}
export { createEvent, parseClientMessage, serializeEvent, } from "./events.js";
//# sourceMappingURL=server.js.map