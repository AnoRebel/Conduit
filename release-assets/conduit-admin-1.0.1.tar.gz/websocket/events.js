/**
 * Create an event message
 */
export function createEvent(type, data) {
    return { type, data };
}
/**
 * Serialize an event to JSON string
 */
export function serializeEvent(type, data) {
    return JSON.stringify(createEvent(type, data));
}
/**
 * Parse an incoming client message
 */
export function parseClientMessage(data) {
    try {
        const parsed = JSON.parse(data);
        if (typeof parsed !== "object" || !parsed.type) {
            return null;
        }
        return {
            type: parsed.type,
            payload: parsed.data ?? parsed.payload ?? {},
        };
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=events.js.map