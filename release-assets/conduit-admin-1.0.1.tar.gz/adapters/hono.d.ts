/**
 * @module @conduit/admin/adapters/hono
 *
 * Hono middleware adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import { Hono } from 'hono';
 * import { createHonoAdminMiddleware } from '@conduit/admin/adapters/hono';
 *
 * const app = new Hono();
 * app.route('/admin', createHonoAdminMiddleware({ admin }));
 * ```
 */
import type { AdminCore } from "../core/index.js";
/**
 * Hono-compatible context object (minimal interface)
 */
export interface HonoContext {
    req: {
        method: string;
        path: string;
        query(key: string): string | undefined;
        header(key: string): string | undefined;
        json(): Promise<unknown>;
        param(key: string): string | undefined;
    };
    json(body: unknown, status?: number): Response;
    text(body: string, status?: number): Response;
    notFound(): Response;
}
/**
 * Hono-compatible next function
 */
export type HonoNext = () => Promise<void>;
/**
 * Hono-compatible middleware
 */
export type HonoMiddleware = (ctx: HonoContext, next: HonoNext) => Response | Promise<Response | void>;
export interface HonoAdminServerOptions {
    admin: AdminCore;
}
/**
 * Create a Hono middleware for the admin API
 */
export declare function createHonoAdminMiddleware(options: HonoAdminServerOptions): HonoMiddleware;
//# sourceMappingURL=hono.d.ts.map