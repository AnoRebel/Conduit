/**
 * @module @conduit/admin/adapters/express
 *
 * Express middleware adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import express from 'express';
 * import { createExpressAdminMiddleware } from '@conduit/admin/adapters/express';
 *
 * const app = express();
 * app.use('/admin', createExpressAdminMiddleware({ admin }));
 * ```
 */
import { createRoutes, error, unauthorized, } from "../routes/index.js";
/**
 * Create an Express middleware for the admin API
 */
export function createExpressAdminMiddleware(options) {
    const { admin } = options;
    const routes = createRoutes();
    // Compile route patterns
    const compiledRoutes = routes.map(route => ({
        ...route,
        pattern: compilePattern(route.path),
    }));
    return async (req, res, next) => {
        const method = req.method.toUpperCase();
        const path = req.path;
        // Find matching route
        const match = findRoute(compiledRoutes, method, path);
        if (!match) {
            // Pass to next middleware if no route matches
            next();
            return;
        }
        const { route, params } = match;
        // Handle authentication
        let authResult = { valid: false, error: "Not authenticated" };
        if (route.requiresAuth) {
            authResult = admin.auth.authenticateRequest(req.headers);
            if (!authResult.valid) {
                sendResponse(res, unauthorized(authResult.error));
                return;
            }
        }
        else {
            authResult = { valid: true };
        }
        // Create context
        const ctx = {
            admin,
            auth: authResult,
            params: { ...req.params, ...params },
            query: req.query,
            body: req.body,
        };
        // Execute handler
        try {
            const response = await route.handler(ctx);
            sendResponse(res, response);
        }
        catch (err) {
            console.error("Route handler error:", err);
            sendResponse(res, error("Internal server error", 500));
        }
    };
}
function compilePattern(path) {
    const paramNames = [];
    const regexStr = path.replace(/:([^/]+)/g, (_, paramName) => {
        paramNames.push(paramName);
        return "([^/]+)";
    });
    return {
        regex: new RegExp(`^${regexStr}$`),
        paramNames,
    };
}
function findRoute(routes, method, path) {
    for (const route of routes) {
        if (route.method !== method) {
            continue;
        }
        const match = path.match(route.pattern.regex);
        if (match) {
            const params = {};
            for (let i = 0; i < route.pattern.paramNames.length; i++) {
                const paramName = route.pattern.paramNames[i];
                const paramValue = match[i + 1];
                if (paramName && paramValue) {
                    params[paramName] = paramValue;
                }
            }
            return { route, params };
        }
    }
    return null;
}
function sendResponse(res, response) {
    const { status, body, headers } = response;
    res.status(status);
    if (headers) {
        res.set(headers);
    }
    if (body !== undefined) {
        res.json(body);
    }
    else {
        res.end();
    }
}
//# sourceMappingURL=express.js.map