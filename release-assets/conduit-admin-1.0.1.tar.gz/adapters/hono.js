/**
 * @module @conduit/admin/adapters/hono
 *
 * Hono middleware adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import { Hono } from 'hono';
 * import { createHonoAdminMiddleware } from '@conduit/admin/adapters/hono';
 *
 * const app = new Hono();
 * app.route('/admin', createHonoAdminMiddleware({ admin }));
 * ```
 */
import { createRoutes, error, unauthorized, } from "../routes/index.js";
/**
 * Create a Hono middleware for the admin API
 */
export function createHonoAdminMiddleware(options) {
    const { admin } = options;
    const routes = createRoutes();
    // Compile route patterns
    const compiledRoutes = routes.map(route => ({
        ...route,
        pattern: compilePattern(route.path),
    }));
    return async (ctx, next) => {
        const method = ctx.req.method.toUpperCase();
        const path = ctx.req.path;
        // Find matching route
        const match = findRoute(compiledRoutes, method, path);
        if (!match) {
            // Pass to next middleware if no route matches
            await next();
            return;
        }
        const { route, params } = match;
        // Build headers object for auth
        const headers = {};
        for (const key of ["authorization", "x-api-key"]) {
            headers[key] = ctx.req.header(key);
        }
        // Handle authentication
        let authResult = { valid: false, error: "Not authenticated" };
        if (route.requiresAuth) {
            authResult = admin.auth.authenticateRequest(headers);
            if (!authResult.valid) {
                return toHonoResponse(ctx, unauthorized(authResult.error));
            }
        }
        else {
            authResult = { valid: true };
        }
        // Build query object
        const query = {};
        const queryKeys = ["limit", "user", "action", "start", "end", "duration"];
        for (const key of queryKeys) {
            const value = ctx.req.query(key);
            if (value) {
                query[key] = value;
            }
        }
        // Parse body for POST/PUT/PATCH
        let body;
        if (["POST", "PUT", "PATCH"].includes(method)) {
            try {
                body = await ctx.req.json();
            }
            catch {
                // Body might be empty or not JSON
            }
        }
        // Merge route params with request params
        const allParams = { ...params };
        for (const key of Object.keys(params)) {
            const reqParam = ctx.req.param(key);
            if (reqParam) {
                allParams[key] = reqParam;
            }
        }
        // Create context
        const routeCtx = {
            admin,
            auth: authResult,
            params: allParams,
            query,
            body,
        };
        // Execute handler
        try {
            const response = await route.handler(routeCtx);
            return toHonoResponse(ctx, response);
        }
        catch (err) {
            console.error("Route handler error:", err);
            return toHonoResponse(ctx, error("Internal server error", 500));
        }
    };
}
function compilePattern(path) {
    const paramNames = [];
    const regexStr = path.replace(/:([^/]+)/g, (_, paramName) => {
        paramNames.push(paramName);
        return "([^/]+)";
    });
    return {
        regex: new RegExp(`^${regexStr}$`),
        paramNames,
    };
}
function findRoute(routes, method, path) {
    for (const route of routes) {
        if (route.method !== method) {
            continue;
        }
        const match = path.match(route.pattern.regex);
        if (match) {
            const params = {};
            for (let i = 0; i < route.pattern.paramNames.length; i++) {
                const paramName = route.pattern.paramNames[i];
                const paramValue = match[i + 1];
                if (paramName && paramValue) {
                    params[paramName] = paramValue;
                }
            }
            return { route, params };
        }
    }
    return null;
}
function toHonoResponse(ctx, response) {
    return ctx.json(response.body, response.status);
}
//# sourceMappingURL=hono.js.map