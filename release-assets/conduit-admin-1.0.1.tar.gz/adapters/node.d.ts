/**
 * @module @conduit/admin/adapters/node
 *
 * Node.js HTTP adapter for the Conduit Admin API. Creates a standalone admin
 * server with REST endpoints, SSE streams, and WebSocket support.
 *
 * @example
 * ```typescript
 * import { createNodeAdminServer } from '@conduit/admin/adapters/node';
 * import { createAdminCore } from '@conduit/admin';
 *
 * const admin = createAdminCore({ config: createAdminConfig() });
 * const server = createNodeAdminServer({ admin });
 * server.listen(9001);
 * ```
 */
import type { IncomingMessage, ServerResponse } from "node:http";
import type { AdminCore } from "../core/index.js";
export interface NodeAdminServerOptions {
    admin: AdminCore;
    /** Allowed CORS origins. Use "*" for any origin, or provide specific origins. */
    corsOrigins?: string | string[];
}
export interface NodeAdminServer {
    handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void>;
    readonly basePath: string;
}
/**
 * Create a Node.js HTTP request handler for the admin API
 */
export declare function createNodeAdminServer(options: NodeAdminServerOptions): NodeAdminServer;
//# sourceMappingURL=node.d.ts.map