/**
 * @module @conduit/admin/adapters/fastify
 *
 * Fastify plugin adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import Fastify from 'fastify';
 * import { createFastifyAdminPlugin } from '@conduit/admin/adapters/fastify';
 *
 * const fastify = Fastify();
 * fastify.register(createFastifyAdminPlugin({ admin }));
 * ```
 */
import { createRoutes, error, unauthorized, } from "../routes/index.js";
/**
 * Create a Fastify plugin for the admin API
 */
export function createFastifyAdminPlugin(options) {
    const { admin } = options;
    const routes = createRoutes();
    return (fastify, _opts, done) => {
        // Register routes
        for (const route of routes) {
            const handler = createRouteHandler(admin, route);
            const method = route.method.toLowerCase();
            // Convert :param to Fastify's :param format (same format, just register)
            fastify[method](route.path, handler);
        }
        done();
    };
}
function createRouteHandler(admin, route) {
    return async (request, reply) => {
        // Handle authentication
        let authResult = { valid: false, error: "Not authenticated" };
        if (route.requiresAuth) {
            authResult = admin.auth.authenticateRequest(request.headers);
            if (!authResult.valid) {
                sendResponse(reply, unauthorized(authResult.error));
                return;
            }
        }
        else {
            authResult = { valid: true };
        }
        // Create context
        const ctx = {
            admin,
            auth: authResult,
            params: request.params ?? {},
            query: request.query,
            body: request.body,
        };
        // Execute handler
        try {
            const response = await route.handler(ctx);
            sendResponse(reply, response);
        }
        catch (err) {
            console.error("Route handler error:", err);
            sendResponse(reply, error("Internal server error", 500));
        }
    };
}
function sendResponse(reply, response) {
    const { status, body, headers } = response;
    reply.code(status);
    if (headers) {
        reply.headers(headers);
    }
    reply.send(body);
}
//# sourceMappingURL=fastify.js.map