import { ApiKeyAuth } from "./apiKey.js";
import { BasicAuth } from "./basic.js";
import { JWTAuth } from "./jwt.js";
import { SessionManager } from "./session.js";
/** Create an {@link AuthManager} from the given {@link AuthConfig}. */
export function createAuthManager(config) {
    const apiKeyAuth = new ApiKeyAuth(config.apiKey);
    const jwtAuth = config.jwtSecret ? new JWTAuth(config.jwtSecret, config.jwtExpiresIn) : null;
    const basicAuth = config.basicCredentials
        ? new BasicAuth(config.basicCredentials.username, config.basicCredentials.password)
        : null;
    const sessionManager = new SessionManager(config.sessionTimeout ?? 3600000);
    function validateApiKey(key) {
        if (!config.methods.includes("apiKey")) {
            return { valid: false, error: "API key authentication not enabled" };
        }
        return apiKeyAuth.validate(key);
    }
    function validateJWT(token) {
        if (!config.methods.includes("jwt") || !jwtAuth) {
            return { valid: false, error: "JWT authentication not enabled" };
        }
        return jwtAuth.validate(token);
    }
    function validateBasicAuth(credentials) {
        if (!config.methods.includes("basic") || !basicAuth) {
            return { valid: false, error: "Basic authentication not enabled" };
        }
        return basicAuth.validate(credentials);
    }
    function createSession(userId, ip) {
        return sessionManager.create(userId, ip);
    }
    function validateSession(sessionId) {
        return sessionManager.validate(sessionId);
    }
    function revokeSession(sessionId) {
        return sessionManager.revoke(sessionId);
    }
    function generateJWT(userId, role) {
        if (!jwtAuth)
            return null;
        return jwtAuth.generate(userId, role);
    }
    function authenticateRequest(headers) {
        // Try Authorization header
        const authHeader = headers.authorization || headers.Authorization;
        const authValue = Array.isArray(authHeader) ? authHeader[0] : authHeader;
        if (authValue) {
            // Check for Bearer token (JWT)
            if (authValue.startsWith("Bearer ")) {
                const token = authValue.slice(7);
                const result = validateJWT(token);
                if (result.valid)
                    return result;
            }
            // Check for Basic auth
            if (authValue.startsWith("Basic ")) {
                const credentials = authValue.slice(6);
                const result = validateBasicAuth(credentials);
                if (result.valid)
                    return { ...result, role: result.role ?? "admin" };
            }
        }
        // Try X-API-Key header
        const apiKeyHeader = headers["x-api-key"] || headers["X-API-Key"];
        const apiKeyValue = Array.isArray(apiKeyHeader) ? apiKeyHeader[0] : apiKeyHeader;
        if (apiKeyValue) {
            const result = validateApiKey(apiKeyValue);
            if (result.valid)
                return { ...result, role: result.role ?? "admin" };
        }
        // Try session cookie
        const cookieHeader = headers.cookie || headers.Cookie;
        const cookieValue = Array.isArray(cookieHeader) ? cookieHeader[0] : cookieHeader;
        if (cookieValue) {
            const sessionMatch = cookieValue.match(/admin_session=([^;]+)/);
            if (sessionMatch?.[1]) {
                const result = validateSession(sessionMatch[1]);
                if (result.valid)
                    return { ...result, role: result.role ?? "admin" };
            }
        }
        return { valid: false, error: "No valid authentication provided" };
    }
    return {
        validateApiKey,
        validateJWT,
        validateBasicAuth,
        createSession,
        validateSession,
        revokeSession,
        generateJWT,
        authenticateRequest,
    };
}
export { ApiKeyAuth } from "./apiKey.js";
export { BasicAuth } from "./basic.js";
export { JWTAuth } from "./jwt.js";
export { SessionManager } from "./session.js";
//# sourceMappingURL=index.js.map