import type { JWTPayload } from "../types.js";
import type { AuthResult } from "./index.js";
/** Authenticator for JWT-based authentication with token generation and validation. */
export declare class JWTAuth {
    private readonly _secret;
    private readonly _expiresIn;
    constructor(secret: string, expiresIn?: number);
    validate(token: string): AuthResult;
    generate(userId: string, role?: "admin" | "viewer"): string;
    decode(token: string): JWTPayload | null;
}
//# sourceMappingURL=jwt.d.ts.map