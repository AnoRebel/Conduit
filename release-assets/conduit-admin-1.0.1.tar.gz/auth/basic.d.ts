import type { AuthResult } from "./index.js";
/** Authenticator for HTTP Basic authentication with constant-time credential comparison. */
export declare class BasicAuth {
    private readonly _username;
    private readonly _expectedBuffer;
    constructor(username: string, password: string);
    validate(credentials: string): AuthResult;
    /**
     * Create base64 encoded credentials for testing
     */
    static encode(username: string, password: string): string;
}
//# sourceMappingURL=basic.d.ts.map