import { randomBytes } from "node:crypto";
/** In-memory session manager with automatic expiry and cleanup. */
export class SessionManager {
    _sessions = new Map();
    _timeout;
    _cleanupInterval = null;
    constructor(timeout = 3600000) {
        this._timeout = timeout;
        this._startCleanup();
    }
    create(userId, ip) {
        const session = {
            id: this._generateSessionId(),
            userId,
            createdAt: Date.now(),
            expiresAt: Date.now() + this._timeout,
            ip,
        };
        this._sessions.set(session.id, session);
        return session;
    }
    validate(sessionId) {
        if (!sessionId || typeof sessionId !== "string") {
            return { valid: false, error: "Invalid session ID" };
        }
        const session = this._sessions.get(sessionId);
        if (!session) {
            return { valid: false, error: "Session not found" };
        }
        if (Date.now() > session.expiresAt) {
            this._sessions.delete(sessionId);
            return { valid: false, error: "Session expired" };
        }
        // Extend session on successful validation
        session.expiresAt = Date.now() + this._timeout;
        return {
            valid: true,
            userId: session.userId,
            session,
        };
    }
    revoke(sessionId) {
        return this._sessions.delete(sessionId);
    }
    revokeAllForUser(userId) {
        let count = 0;
        for (const [id, session] of this._sessions) {
            if (session.userId === userId) {
                this._sessions.delete(id);
                count++;
            }
        }
        return count;
    }
    get(sessionId) {
        return this._sessions.get(sessionId);
    }
    getActiveSessions() {
        const now = Date.now();
        return Array.from(this._sessions.values()).filter(s => s.expiresAt > now);
    }
    getSessionCount() {
        return this._sessions.size;
    }
    clear() {
        this._sessions.clear();
    }
    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
        this._sessions.clear();
    }
    _generateSessionId() {
        return randomBytes(32).toString("base64url");
    }
    _startCleanup() {
        // Clean up expired sessions every minute
        this._cleanupInterval = setInterval(() => {
            const now = Date.now();
            for (const [id, session] of this._sessions) {
                if (session.expiresAt < now) {
                    this._sessions.delete(id);
                }
            }
        }, 60000);
        // Don't prevent Node from exiting
        if (this._cleanupInterval.unref) {
            this._cleanupInterval.unref();
        }
    }
}
//# sourceMappingURL=session.js.map