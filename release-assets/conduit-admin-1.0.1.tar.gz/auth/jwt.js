import jwt from "jsonwebtoken";
/** Authenticator for JWT-based authentication with token generation and validation. */
export class JWTAuth {
    _secret;
    _expiresIn;
    constructor(secret, expiresIn = 3600) {
        this._secret = secret;
        this._expiresIn = expiresIn;
    }
    validate(token) {
        if (!token || typeof token !== "string") {
            return { valid: false, error: "Invalid token format" };
        }
        try {
            const decoded = jwt.verify(token, this._secret);
            return {
                valid: true,
                userId: decoded.sub,
                role: decoded.role ?? "admin",
            };
        }
        catch (error) {
            if (error instanceof jwt.TokenExpiredError) {
                return { valid: false, error: "Token expired" };
            }
            if (error instanceof jwt.JsonWebTokenError) {
                return { valid: false, error: "Invalid token" };
            }
            return { valid: false, error: "Token verification failed" };
        }
    }
    generate(userId, role = "admin") {
        const payload = {
            sub: userId,
            iat: Math.floor(Date.now() / 1000),
            exp: Math.floor(Date.now() / 1000) + this._expiresIn,
            role,
        };
        return jwt.sign(payload, this._secret);
    }
    decode(token) {
        try {
            return jwt.decode(token);
        }
        catch {
            return null;
        }
    }
}
//# sourceMappingURL=jwt.js.map