import type { AuthResult } from "./index.js";
/** Authenticator that validates requests against a static API key using constant-time comparison. */
export declare class ApiKeyAuth {
    private readonly _apiKey;
    private readonly _apiKeyBuffer;
    constructor(apiKey?: string);
    validate(key: string): AuthResult;
}
//# sourceMappingURL=apiKey.d.ts.map