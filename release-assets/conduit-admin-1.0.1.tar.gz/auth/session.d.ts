import type { AuthSession } from "../types.js";
import type { AuthResult } from "./index.js";
/** In-memory session manager with automatic expiry and cleanup. */
export declare class SessionManager {
    private readonly _sessions;
    private readonly _timeout;
    private _cleanupInterval;
    constructor(timeout?: number);
    create(userId: string, ip?: string): AuthSession;
    validate(sessionId: string): AuthResult;
    revoke(sessionId: string): boolean;
    revokeAllForUser(userId: string): number;
    get(sessionId: string): AuthSession | undefined;
    getActiveSessions(): AuthSession[];
    getSessionCount(): number;
    clear(): void;
    destroy(): void;
    private _generateSessionId;
    private _startCleanup;
}
//# sourceMappingURL=session.d.ts.map