import type { AuthConfig } from "../config.js";
import type { AuthSession } from "../types.js";
/** Outcome of an authentication attempt. */
export interface AuthResult {
    /** Whether authentication succeeded. */
    valid: boolean;
    /** Authenticated user identifier (when valid). */
    userId?: string;
    /** Role assigned to the authenticated user. */
    role?: "admin" | "viewer";
    /** Associated session, if session-based auth was used. */
    session?: AuthSession;
    /** Error message on failure. */
    error?: string;
}
export interface AuthManager {
    /** Validate an API key */
    validateApiKey(key: string): AuthResult;
    /** Validate a JWT token */
    validateJWT(token: string): AuthResult;
    /** Validate basic auth credentials */
    validateBasicAuth(credentials: string): AuthResult;
    /** Create a new session */
    createSession(userId: string, ip?: string): AuthSession;
    /** Validate an existing session */
    validateSession(sessionId: string): AuthResult;
    /** Revoke a session */
    revokeSession(sessionId: string): boolean;
    /** Generate a JWT token */
    generateJWT(userId: string, role?: "admin" | "viewer"): string | null;
    /** Authenticate from request headers */
    authenticateRequest(headers: Record<string, string | string[] | undefined>): AuthResult;
}
/** Create an {@link AuthManager} from the given {@link AuthConfig}. */
export declare function createAuthManager(config: AuthConfig): AuthManager;
export { ApiKeyAuth } from "./apiKey.js";
export { BasicAuth } from "./basic.js";
export { JWTAuth } from "./jwt.js";
export { SessionManager } from "./session.js";
//# sourceMappingURL=index.d.ts.map