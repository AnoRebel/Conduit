import type { ClientMetrics, MemoryUsage, MessageMetrics, MetricsSnapshot, ServerStatus } from "../types.js";
import type { RemoteServer } from "./connection.js";
export interface AggregatedMetrics {
    timestamp: number;
    serverCount: number;
    connectedServers: number;
    clients: ClientMetrics;
    messages: MessageMetrics;
    memory: MemoryUsage;
    byServer: Record<string, MetricsSnapshot>;
}
export interface AggregatedStatus {
    timestamp: number;
    servers: Array<{
        id: string;
        name?: string;
        status: RemoteServer["status"];
        serverStatus: ServerStatus | null;
    }>;
    totals: {
        running: number;
        clients: number;
        peakClients: number;
        messagesRelayed: number;
    };
}
/**
 * Aggregate metrics from multiple servers
 */
export declare function aggregateMetrics(servers: RemoteServer[]): AggregatedMetrics;
/**
 * Aggregate status from multiple servers
 */
export declare function aggregateStatus(servers: RemoteServer[]): AggregatedStatus;
//# sourceMappingURL=aggregator.d.ts.map