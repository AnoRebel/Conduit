import type { MetricsSnapshot, ServerConnection, ServerStatus } from "../types.js";
export interface RemoteServer {
    readonly config: ServerConnection;
    readonly status: "connecting" | "connected" | "disconnected" | "error";
    readonly lastStatus: ServerStatus | null;
    readonly lastMetrics: MetricsSnapshot | null;
    readonly lastError: string | null;
    readonly lastUpdate: number;
    connect(): Promise<void>;
    disconnect(): void;
    fetchStatus(): Promise<ServerStatus>;
    fetchMetrics(): Promise<MetricsSnapshot>;
    executeAction(action: string, params: Record<string, unknown>): Promise<unknown>;
}
export interface RemoteServerOptions {
    config: ServerConnection;
    onStatusChange?: (server: RemoteServer) => void;
    onMetricsUpdate?: (server: RemoteServer, metrics: MetricsSnapshot) => void;
    onError?: (server: RemoteServer, error: Error) => void;
}
/**
 * Create a connection to a remote Conduit server's admin API
 */
export declare function createRemoteServer(options: RemoteServerOptions): RemoteServer;
//# sourceMappingURL=connection.d.ts.map