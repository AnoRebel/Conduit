/**
 * @module @conduit/admin/standalone
 *
 * Standalone admin mode for managing multiple Conduit servers remotely.
 * Connects to multiple server instances and aggregates metrics and status.
 *
 * @example
 * ```typescript
 * import { createStandaloneAdmin } from '@conduit/admin/standalone';
 *
 * const admin = createStandaloneAdmin({
 *   servers: [{ url: 'http://server1:9000' }, { url: 'http://server2:9000' }],
 * });
 * await admin.start();
 * ```
 */
import { createAdminConfig } from "../config.js";
import { aggregateMetrics, aggregateStatus, } from "./aggregator.js";
import { createRemoteServer } from "./connection.js";
/**
 * Create a standalone admin that can connect to multiple Conduit servers
 */
export function createStandaloneAdmin(options = {}) {
    const config = createAdminConfig(options.config);
    const servers = new Map();
    // Event callbacks
    const metricsCallbacks = new Set();
    const statusCallbacks = new Set();
    // Polling interval for servers without WebSocket
    let pollingInterval = null;
    function addServer(connection) {
        if (servers.has(connection.id)) {
            throw new Error(`Server with id '${connection.id}' already exists`);
        }
        const server = createRemoteServer({
            config: connection,
            onStatusChange: _s => {
                for (const callback of statusCallbacks) {
                    callback(connection.id, _s.status);
                }
            },
            onMetricsUpdate: (_s, metrics) => {
                for (const callback of metricsCallbacks) {
                    callback(connection.id, metrics);
                }
            },
            onError: (_s, error) => {
                console.error(`Server ${connection.id} error:`, error.message);
            },
        });
        servers.set(connection.id, server);
        return server;
    }
    function removeServer(id) {
        const server = servers.get(id);
        if (server) {
            server.disconnect();
            return servers.delete(id);
        }
        return false;
    }
    function getServer(id) {
        return servers.get(id);
    }
    async function connectAll() {
        const promises = Array.from(servers.values()).map(server => server.connect().catch(err => {
            console.error(`Failed to connect to ${server.config.id}:`, err.message);
        }));
        await Promise.all(promises);
        // Start polling for servers that don't use WebSocket
        startPolling();
    }
    function disconnectAll() {
        stopPolling();
        for (const server of servers.values()) {
            server.disconnect();
        }
    }
    function destroy() {
        disconnectAll();
        servers.clear();
        metricsCallbacks.clear();
        statusCallbacks.clear();
    }
    function startPolling() {
        if (pollingInterval) {
            return;
        }
        pollingInterval = setInterval(async () => {
            for (const server of servers.values()) {
                if (server.status === "connected") {
                    try {
                        const metrics = await server.fetchMetrics();
                        for (const callback of metricsCallbacks) {
                            callback(server.config.id, metrics);
                        }
                    }
                    catch {
                        // Server may have become unavailable
                    }
                }
            }
        }, config.metrics.snapshotIntervalMs);
        if (pollingInterval.unref) {
            pollingInterval.unref();
        }
    }
    function stopPolling() {
        if (pollingInterval) {
            clearInterval(pollingInterval);
            pollingInterval = null;
        }
    }
    function getAggregatedMetrics() {
        return aggregateMetrics(Array.from(servers.values()));
    }
    function getAggregatedStatus() {
        return aggregateStatus(Array.from(servers.values()));
    }
    function onMetricsUpdate(callback) {
        metricsCallbacks.add(callback);
        return () => metricsCallbacks.delete(callback);
    }
    function onStatusChange(callback) {
        statusCallbacks.add(callback);
        return () => statusCallbacks.delete(callback);
    }
    // Add initial servers
    if (options.servers) {
        for (const connection of options.servers) {
            addServer(connection);
        }
    }
    return {
        config,
        servers,
        addServer,
        removeServer,
        getServer,
        connectAll,
        disconnectAll,
        destroy,
        getAggregatedMetrics,
        getAggregatedStatus,
        onMetricsUpdate,
        onStatusChange,
    };
}
export { aggregateMetrics, aggregateStatus, } from "./aggregator.js";
export { createRemoteServer } from "./connection.js";
//# sourceMappingURL=index.js.map