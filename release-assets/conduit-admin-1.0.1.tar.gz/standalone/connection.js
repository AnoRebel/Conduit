/**
 * Create a connection to a remote Conduit server's admin API
 */
export function createRemoteServer(options) {
    const { config, onStatusChange, onMetricsUpdate, onError } = options;
    let status = "disconnected";
    let lastStatus = null;
    let lastMetrics = null;
    let lastError = null;
    let lastUpdate = 0;
    let ws = null;
    let reconnectTimer = null;
    function buildHeaders() {
        const headers = {
            "Content-Type": "application/json",
        };
        if (config.adminKey) {
            headers["X-API-Key"] = config.adminKey;
        }
        return headers;
    }
    async function connect() {
        if (status === "connected" || status === "connecting") {
            return;
        }
        setStatus("connecting");
        try {
            // Try HTTP first to verify connectivity
            await fetchStatus();
            setStatus("connected");
            // If WebSocket URL is available, connect for real-time updates
            if (config.url.startsWith("ws://") || config.url.startsWith("wss://")) {
                connectWebSocket();
            }
        }
        catch (error) {
            setStatus("error");
            lastError = error instanceof Error ? error.message : "Connection failed";
            onError?.(server, error instanceof Error ? error : new Error(lastError));
            throw error;
        }
    }
    function connectWebSocket() {
        const wsUrl = new URL(config.url);
        if (config.adminKey) {
            wsUrl.searchParams.set("apiKey", config.adminKey);
        }
        ws = new WebSocket(wsUrl.toString());
        ws.onopen = () => {
            setStatus("connected");
            // Subscribe to events
            ws?.send(JSON.stringify({
                type: "subscribe",
                data: { events: ["metrics:update", "client:connected", "client:disconnected"] },
            }));
        };
        ws.onmessage = event => {
            try {
                const message = JSON.parse(event.data);
                if (message.type === "metrics:update") {
                    lastMetrics = message.data;
                    lastUpdate = Date.now();
                    onMetricsUpdate?.(server, message.data);
                }
            }
            catch {
                // Ignore parse errors
            }
        };
        ws.onclose = () => {
            setStatus("disconnected");
            scheduleReconnect();
        };
        ws.onerror = () => {
            setStatus("error");
            lastError = "WebSocket error";
        };
    }
    function scheduleReconnect() {
        if (reconnectTimer) {
            return;
        }
        reconnectTimer = setTimeout(() => {
            reconnectTimer = null;
            if (status === "disconnected") {
                connect().catch(() => {
                    // Reconnection failed, will try again
                    scheduleReconnect();
                });
            }
        }, 5000);
    }
    function disconnect() {
        if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
        }
        if (ws) {
            ws.close();
            ws = null;
        }
        setStatus("disconnected");
    }
    function setStatus(newStatus) {
        if (status !== newStatus) {
            status = newStatus;
            onStatusChange?.(server);
        }
    }
    async function fetchStatus() {
        const httpUrl = config.url.replace(/^ws/, "http");
        const response = await fetch(`${httpUrl}/status`, {
            headers: buildHeaders(),
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = (await response.json());
        lastStatus = data;
        lastUpdate = Date.now();
        return data;
    }
    async function fetchMetrics() {
        const httpUrl = config.url.replace(/^ws/, "http");
        const response = await fetch(`${httpUrl}/metrics`, {
            headers: buildHeaders(),
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = (await response.json());
        lastMetrics = data;
        lastUpdate = Date.now();
        return data;
    }
    async function executeAction(action, params) {
        const httpUrl = config.url.replace(/^ws/, "http");
        const response = await fetch(`${httpUrl}/${action}`, {
            method: "POST",
            headers: buildHeaders(),
            body: JSON.stringify(params),
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    }
    const server = {
        config,
        get status() {
            return status;
        },
        get lastStatus() {
            return lastStatus;
        },
        get lastMetrics() {
            return lastMetrics;
        },
        get lastError() {
            return lastError;
        },
        get lastUpdate() {
            return lastUpdate;
        },
        connect,
        disconnect,
        fetchStatus,
        fetchMetrics,
        executeAction,
    };
    return server;
}
//# sourceMappingURL=connection.js.map