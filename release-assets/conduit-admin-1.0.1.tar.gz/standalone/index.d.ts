/**
 * @module @conduit/admin/standalone
 *
 * Standalone admin mode for managing multiple Conduit servers remotely.
 * Connects to multiple server instances and aggregates metrics and status.
 *
 * @example
 * ```typescript
 * import { createStandaloneAdmin } from '@conduit/admin/standalone';
 *
 * const admin = createStandaloneAdmin({
 *   servers: [{ url: 'http://server1:9000' }, { url: 'http://server2:9000' }],
 * });
 * await admin.start();
 * ```
 */
import type { AdminConfig } from "../config.js";
import { type AdminConfigOptions } from "../config.js";
import type { MetricsSnapshot, ServerConnection } from "../types.js";
import { type AggregatedMetrics, type AggregatedStatus } from "./aggregator.js";
import { type RemoteServer } from "./connection.js";
export interface StandaloneAdmin {
    readonly config: AdminConfig;
    readonly servers: ReadonlyMap<string, RemoteServer>;
    addServer(connection: ServerConnection): RemoteServer;
    removeServer(id: string): boolean;
    getServer(id: string): RemoteServer | undefined;
    connectAll(): Promise<void>;
    disconnectAll(): void;
    destroy(): void;
    getAggregatedMetrics(): AggregatedMetrics;
    getAggregatedStatus(): AggregatedStatus;
    onMetricsUpdate(callback: (serverId: string, metrics: MetricsSnapshot) => void): () => void;
    onStatusChange(callback: (serverId: string, status: RemoteServer["status"]) => void): () => void;
}
export interface StandaloneAdminOptions {
    config?: Partial<AdminConfigOptions>;
    servers?: ServerConnection[];
}
/**
 * Create a standalone admin that can connect to multiple Conduit servers
 */
export declare function createStandaloneAdmin(options?: StandaloneAdminOptions): StandaloneAdmin;
export { type AggregatedMetrics, type AggregatedStatus, aggregateMetrics, aggregateStatus, } from "./aggregator.js";
export { createRemoteServer, type RemoteServer, type RemoteServerOptions } from "./connection.js";
//# sourceMappingURL=index.d.ts.map