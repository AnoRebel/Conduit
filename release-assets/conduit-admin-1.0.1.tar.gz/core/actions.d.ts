import type { IMessage } from "@conduit/shared";
import type { InstrumentableServerCore } from "../metrics/instrumentation.js";
import type { RateLimitConfig } from "../types.js";
import type { AuditLogger } from "./audit.js";
import type { BanManager } from "./bans.js";
/** Server core interface extended with realm access for admin actions. */
export interface ActionableServerCore extends InstrumentableServerCore {
    readonly realm: {
        getClientIds(): string[];
        getClient(id: string): ActionableClient | undefined;
        removeClient(id: string): boolean;
    };
    readonly config: {
        rateLimit?: {
            enabled?: boolean;
            maxTokens?: number;
            refillRate?: number;
        };
    };
}
/** Minimal client interface with socket access for admin operations. */
export interface ActionableClient {
    id: string;
    token: string;
    socket: {
        close: () => void;
        send: (data: string) => void;
    } | null;
    send(message: IMessage): void;
}
/** Administrative action methods for managing clients, bans, and server features. */
export interface AdminActions {
    disconnectClient(clientId: string, userId: string): boolean;
    disconnectAllClients(userId: string): number;
    clearClientQueue(clientId: string, userId: string): boolean;
    banClient(clientId: string, reason: string | undefined, userId: string): boolean;
    unbanClient(clientId: string, userId: string): boolean;
    banIP(ip: string, reason: string | undefined, userId: string): boolean;
    unbanIP(ip: string, userId: string): boolean;
    broadcastMessage(message: IMessage, userId: string): number;
    updateRateLimits(config: Partial<RateLimitConfig>, userId: string): void;
    toggleFeature(feature: "discovery" | "relay", enabled: boolean, userId: string): void;
}
/** Options for {@link createAdminActions}. */
export interface AdminActionsOptions {
    serverCore: ActionableServerCore;
    banManager: BanManager;
    auditLogger: AuditLogger;
}
/** Create an {@link AdminActions} implementation backed by the given server core, ban manager, and audit logger. */
export declare function createAdminActions(options: AdminActionsOptions): AdminActions;
//# sourceMappingURL=actions.d.ts.map