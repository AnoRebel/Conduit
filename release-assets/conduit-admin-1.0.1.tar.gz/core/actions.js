/** Create an {@link AdminActions} implementation backed by the given server core, ban manager, and audit logger. */
export function createAdminActions(options) {
    const { serverCore, banManager, auditLogger } = options;
    function disconnectClient(clientId, userId) {
        const client = serverCore.realm.getClient(clientId);
        if (!client) {
            return false;
        }
        auditLogger.log("disconnect_client", userId, { clientId });
        if (client.socket) {
            client.socket.close();
        }
        serverCore.realm.removeClient(clientId);
        return true;
    }
    function disconnectAllClients(userId) {
        const clientIds = serverCore.realm.getClientIds();
        auditLogger.log("disconnect_all", userId, { count: clientIds.length });
        let count = 0;
        for (const clientId of clientIds) {
            const client = serverCore.realm.getClient(clientId);
            if (client) {
                if (client.socket) {
                    client.socket.close();
                }
                serverCore.realm.removeClient(clientId);
                count++;
            }
        }
        return count;
    }
    function clearClientQueue(clientId, userId) {
        // Note: This would need access to the message queue
        // For now, we log the action but the actual implementation
        // depends on the server core exposing the message queue
        auditLogger.log("clear_queue", userId, { clientId });
        // Placeholder - actual implementation needs message queue access
        return true;
    }
    function banClient(clientId, reason, userId) {
        const entry = banManager.banClient(clientId, reason);
        auditLogger.log("ban_client", userId, { clientId, reason });
        // Also disconnect if currently connected
        const client = serverCore.realm.getClient(clientId);
        if (client?.socket) {
            client.socket.close();
            serverCore.realm.removeClient(clientId);
        }
        return !!entry;
    }
    function unbanClient(clientId, userId) {
        const result = banManager.unbanClient(clientId);
        if (result) {
            auditLogger.log("unban_client", userId, { clientId });
        }
        return result;
    }
    function banIP(ip, reason, userId) {
        const entry = banManager.banIP(ip, reason);
        auditLogger.log("ban_ip", userId, { ip, reason });
        // Note: Disconnecting all clients from this IP would require
        // tracking IP addresses in the client - not currently available
        return !!entry;
    }
    function unbanIP(ip, userId) {
        const result = banManager.unbanIP(ip);
        if (result) {
            auditLogger.log("unban_ip", userId, { ip });
        }
        return result;
    }
    function broadcastMessage(message, userId) {
        const clientIds = serverCore.realm.getClientIds();
        auditLogger.log("broadcast", userId, {
            messageType: message.type,
            recipientCount: clientIds.length,
        });
        let sent = 0;
        for (const clientId of clientIds) {
            const client = serverCore.realm.getClient(clientId);
            if (client?.socket) {
                try {
                    client.send(message);
                    sent++;
                }
                catch {
                    // Client may have disconnected
                }
            }
        }
        return sent;
    }
    function updateRateLimits(config, userId) {
        auditLogger.log("update_rate_limits", userId, { config });
        // Note: Actual rate limit updates would need to be implemented
        // in the server core. This logs the intent.
        // The server core would need to expose a method to update rate limits.
    }
    function toggleFeature(feature, enabled, userId) {
        auditLogger.log("toggle_feature", userId, { feature, enabled });
        // Note: Feature toggling would need server core support
        // This logs the intent for now.
    }
    return {
        disconnectClient,
        disconnectAllClients,
        clearClientQueue,
        banClient,
        unbanClient,
        banIP,
        unbanIP,
        broadcastMessage,
        updateRateLimits,
        toggleFeature,
    };
}
//# sourceMappingURL=actions.js.map