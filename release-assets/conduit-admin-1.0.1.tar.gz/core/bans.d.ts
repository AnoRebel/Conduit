import type { PersistenceStore } from "../persistence/index.js";
import type { BanEntry } from "../types.js";
/** Manager for client and IP bans with optional persistent storage. */
export interface BanManager {
    banClient(clientId: string, reason?: string): BanEntry;
    unbanClient(clientId: string): boolean;
    banIP(ip: string, reason?: string): BanEntry;
    unbanIP(ip: string): boolean;
    isClientBanned(clientId: string): boolean;
    isIPBanned(ip: string): boolean;
    getBans(): BanEntry[];
    getClientBans(): BanEntry[];
    getIPBans(): BanEntry[];
    getBan(id: string): BanEntry | undefined;
    clear(): void;
}
/** Options for {@link createBanManager}. */
export interface BanManagerOptions {
    store?: PersistenceStore;
}
/** Create a {@link BanManager} with optional persistence backing. */
export declare function createBanManager(options?: BanManagerOptions): BanManager;
//# sourceMappingURL=bans.d.ts.map