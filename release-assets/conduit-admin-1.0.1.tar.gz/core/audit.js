/** Create an {@link AuditLogger} with optional persistence backing. */
export function createAuditLogger(options = {}) {
    const { enabled = true, maxEntries = 1000, store } = options;
    // In-memory buffer for fast access (even with persistence, we keep a cache)
    const entries = [];
    // Hydrate from persistence store on creation
    if (store) {
        const persisted = store.getAuditEntries(maxEntries);
        // persisted is newest-first, reverse for our oldest-first array
        entries.push(...persisted.reverse());
    }
    function log(action, userId, details) {
        const entry = {
            id: generateId(),
            timestamp: Date.now(),
            action,
            userId,
            details,
        };
        if (enabled) {
            entries.push(entry);
            store?.saveAuditEntry(entry);
            // Trim old entries from memory
            while (entries.length > maxEntries) {
                entries.shift();
            }
        }
        return entry;
    }
    function getEntries(limit) {
        // Prefer store for full history, fall back to in-memory
        if (store) {
            return store.getAuditEntries(limit);
        }
        if (!limit) {
            return [...entries].reverse();
        }
        return entries.slice(-limit).reverse();
    }
    function getEntriesByUser(userId, limit) {
        if (store) {
            return store.getAuditEntriesByUser(userId, limit);
        }
        const filtered = entries.filter(e => e.userId === userId);
        if (!limit) {
            return [...filtered].reverse();
        }
        return filtered.slice(-limit).reverse();
    }
    function getEntriesByAction(action, limit) {
        if (store) {
            return store.getAuditEntriesByAction(action, limit);
        }
        const filtered = entries.filter(e => e.action === action);
        if (!limit) {
            return [...filtered].reverse();
        }
        return filtered.slice(-limit).reverse();
    }
    function getEntriesInRange(startTime, endTime) {
        if (store) {
            return store.getAuditEntriesInRange(startTime, endTime);
        }
        return entries.filter(e => e.timestamp >= startTime && e.timestamp <= endTime).reverse();
    }
    function clear() {
        entries.length = 0;
        store?.clearAudit();
    }
    function generateId() {
        return `audit_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    }
    return {
        log,
        getEntries,
        getEntriesByUser,
        getEntriesByAction,
        getEntriesInRange,
        clear,
        get enabled() {
            return enabled;
        },
        get size() {
            if (store) {
                return store.getAuditSize();
            }
            return entries.length;
        },
    };
}
//# sourceMappingURL=audit.js.map