/** Create a {@link BanManager} with optional persistence backing. */
export function createBanManager(options = {}) {
    const { store } = options;
    const bans = new Map();
    // Hydrate from persistence store on creation
    if (store) {
        for (const ban of store.getBans()) {
            bans.set(`${ban.type}:${ban.id}`, ban);
        }
    }
    function banClient(clientId, reason) {
        const entry = {
            id: clientId,
            type: "client",
            reason,
            bannedAt: Date.now(),
        };
        bans.set(`client:${clientId}`, entry);
        store?.saveBan(entry);
        return entry;
    }
    function unbanClient(clientId) {
        const removed = bans.delete(`client:${clientId}`);
        if (removed) {
            store?.removeBan("client", clientId);
        }
        return removed;
    }
    function banIP(ip, reason) {
        const entry = {
            id: ip,
            type: "ip",
            reason,
            bannedAt: Date.now(),
        };
        bans.set(`ip:${ip}`, entry);
        store?.saveBan(entry);
        return entry;
    }
    function unbanIP(ip) {
        const removed = bans.delete(`ip:${ip}`);
        if (removed) {
            store?.removeBan("ip", ip);
        }
        return removed;
    }
    function isClientBanned(clientId) {
        return bans.has(`client:${clientId}`);
    }
    function isIPBanned(ip) {
        return bans.has(`ip:${ip}`);
    }
    function getBans() {
        return Array.from(bans.values());
    }
    function getClientBans() {
        return getBans().filter(b => b.type === "client");
    }
    function getIPBans() {
        return getBans().filter(b => b.type === "ip");
    }
    function getBan(id) {
        return bans.get(`client:${id}`) ?? bans.get(`ip:${id}`);
    }
    function clear() {
        bans.clear();
        store?.clearBans();
    }
    return {
        banClient,
        unbanClient,
        banIP,
        unbanIP,
        isClientBanned,
        isIPBanned,
        getBans,
        getClientBans,
        getIPBans,
        getBan,
        clear,
    };
}
//# sourceMappingURL=bans.js.map