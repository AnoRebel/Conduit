import type { PersistenceStore } from "../persistence/index.js";
import type { AuditAction, AuditEntry } from "../types.js";
/** Audit logger for recording and querying admin operations. */
export interface AuditLogger {
    log(action: AuditAction, userId: string, details?: Record<string, unknown>): AuditEntry;
    getEntries(limit?: number): AuditEntry[];
    getEntriesByUser(userId: string, limit?: number): AuditEntry[];
    getEntriesByAction(action: AuditAction, limit?: number): AuditEntry[];
    getEntriesInRange(startTime: number, endTime: number): AuditEntry[];
    clear(): void;
    readonly enabled: boolean;
    readonly size: number;
}
/** Options for {@link createAuditLogger}. */
export interface AuditLoggerOptions {
    enabled?: boolean;
    maxEntries?: number;
    store?: PersistenceStore;
}
/** Create an {@link AuditLogger} with optional persistence backing. */
export declare function createAuditLogger(options?: AuditLoggerOptions): AuditLogger;
//# sourceMappingURL=audit.d.ts.map