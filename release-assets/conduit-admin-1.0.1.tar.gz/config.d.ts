import type { PersistenceConfig } from "./persistence/index.js";
import type { ServerConnection } from "./types.js";
export interface AuthConfig {
    /** Authentication methods to enable */
    methods: ("apiKey" | "jwt" | "basic")[];
    /** API key for simple authentication */
    apiKey?: string;
    /** JWT secret for token-based authentication */
    jwtSecret?: string;
    /** JWT expiration time in seconds (default: 3600 = 1 hour) */
    jwtExpiresIn?: number;
    /** Basic auth credentials */
    basicCredentials?: {
        username: string;
        password: string;
    };
    /** Session timeout in milliseconds (default: 3600000 = 1 hour) */
    sessionTimeout?: number;
}
export interface AdminRateLimitConfig {
    /** Enable rate limiting for admin endpoints (default: true) */
    enabled: boolean;
    /** Maximum requests per window (default: 100) */
    maxRequests: number;
    /** Window duration in milliseconds (default: 60000 = 1 minute) */
    windowMs: number;
}
export interface MetricsConfig {
    /** How long to retain historical metrics in milliseconds (default: 86400000 = 24 hours) */
    retentionMs: number;
    /** Interval for taking metrics snapshots in milliseconds (default: 1000 = 1 second) */
    snapshotIntervalMs: number;
    /** Maximum number of snapshots to retain (default: 3600 = 1 hour at 1/sec) */
    maxSnapshots: number;
}
export interface AuditConfig {
    /** Enable audit logging (default: true) */
    enabled: boolean;
    /** Maximum number of audit entries to retain (default: 10000) */
    maxEntries: number;
    /** Log level: 'actions' for admin actions only, 'all' for all requests */
    logLevel: "actions" | "all";
}
export interface AdminWebSocketConfig {
    /** Enable WebSocket endpoint for real-time updates (default: true) */
    enabled: boolean;
    /** WebSocket path (default: "/ws") */
    path: string;
    /** Heartbeat interval in milliseconds (default: 30000) */
    heartbeatInterval: number;
}
export interface SSEConfig {
    /** Enable SSE endpoints (default: true) */
    enabled: boolean;
    /** Keep-alive interval in milliseconds (default: 15000) */
    keepAliveInterval: number;
}
export interface AdminConfig {
    /** Base path for admin API (default: "/admin") */
    path: string;
    /** API version prefix (default: "v1") */
    apiVersion: string;
    /** Authentication configuration */
    auth: AuthConfig;
    /** Rate limiting for admin endpoints */
    rateLimit: AdminRateLimitConfig;
    /** Metrics collection configuration */
    metrics: MetricsConfig;
    /** Audit logging configuration */
    audit: AuditConfig;
    /** WebSocket configuration */
    websocket: AdminWebSocketConfig;
    /** SSE configuration */
    sse: SSEConfig;
    /** Persistence configuration (default: in-memory, no durability) */
    persistence?: PersistenceConfig;
    /** Standalone mode configuration (when not attached to a server) */
    standalone?: {
        servers: ServerConnection[];
    };
}
/** Default admin configuration values. */
export declare const defaultAdminConfig: AdminConfig;
/** Partial overrides accepted by {@link createAdminConfig}. */
export type AdminConfigOptions = Partial<AdminConfig>;
/** Create a full {@link AdminConfig} by merging partial overrides with defaults. */
export declare function createAdminConfig(options?: AdminConfigOptions): AdminConfig;
/** Validate an {@link AdminConfig} and return any configuration errors. */
export declare function validateAdminConfig(config: AdminConfig): {
    valid: boolean;
    errors: string[];
};
//# sourceMappingURL=config.d.ts.map