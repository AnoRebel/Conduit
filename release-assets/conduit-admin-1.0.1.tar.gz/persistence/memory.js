/**
 * In-memory persistence store — default no-op implementation.
 * All data is lost on restart. Use SQLiteStore for durable persistence.
 */
export class MemoryStore {
    bans = new Map();
    auditEntries = [];
    saveBan(entry) {
        this.bans.set(`${entry.type}:${entry.id}`, entry);
    }
    removeBan(type, id) {
        return this.bans.delete(`${type}:${id}`);
    }
    getBans() {
        return Array.from(this.bans.values());
    }
    getBan(type, id) {
        return this.bans.get(`${type}:${id}`);
    }
    clearBans() {
        this.bans.clear();
    }
    saveAuditEntry(entry) {
        this.auditEntries.push(entry);
    }
    getAuditEntries(limit) {
        if (!limit)
            return [...this.auditEntries].reverse();
        return this.auditEntries.slice(-limit).reverse();
    }
    getAuditEntriesByUser(userId, limit) {
        const filtered = this.auditEntries.filter(e => e.userId === userId);
        if (!limit)
            return [...filtered].reverse();
        return filtered.slice(-limit).reverse();
    }
    getAuditEntriesByAction(action, limit) {
        const filtered = this.auditEntries.filter(e => e.action === action);
        if (!limit)
            return [...filtered].reverse();
        return filtered.slice(-limit).reverse();
    }
    getAuditEntriesInRange(startTime, endTime) {
        return this.auditEntries
            .filter(e => e.timestamp >= startTime && e.timestamp <= endTime)
            .reverse();
    }
    clearAudit() {
        this.auditEntries.length = 0;
    }
    getAuditSize() {
        return this.auditEntries.length;
    }
    close() {
        // No-op for memory store
    }
}
//# sourceMappingURL=memory.js.map