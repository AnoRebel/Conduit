import type { AuditAction, AuditEntry, BanEntry } from "../types.js";
import type { PersistenceStore } from "./index.js";
/**
 * In-memory persistence store — default no-op implementation.
 * All data is lost on restart. Use SQLiteStore for durable persistence.
 */
export declare class MemoryStore implements PersistenceStore {
    private bans;
    private auditEntries;
    saveBan(entry: BanEntry): void;
    removeBan(type: "client" | "ip", id: string): boolean;
    getBans(): BanEntry[];
    getBan(type: "client" | "ip", id: string): BanEntry | undefined;
    clearBans(): void;
    saveAuditEntry(entry: AuditEntry): void;
    getAuditEntries(limit?: number): AuditEntry[];
    getAuditEntriesByUser(userId: string, limit?: number): AuditEntry[];
    getAuditEntriesByAction(action: AuditAction, limit?: number): AuditEntry[];
    getAuditEntriesInRange(startTime: number, endTime: number): AuditEntry[];
    clearAudit(): void;
    getAuditSize(): number;
    close(): void;
}
//# sourceMappingURL=memory.d.ts.map