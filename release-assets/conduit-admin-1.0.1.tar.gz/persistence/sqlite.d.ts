import type { AuditAction, AuditEntry, BanEntry } from "../types.js";
import type { PersistenceStore } from "./index.js";
/**
 * SQLite persistence store using bun:sqlite (built into Bun, zero deps).
 * Provides durable storage for bans and audit logs that survives restarts.
 */
export declare class SQLiteStore implements PersistenceStore {
    private db;
    constructor(dbPath: string);
    private initTables;
    saveBan(entry: BanEntry): void;
    removeBan(type: "client" | "ip", id: string): boolean;
    getBans(): BanEntry[];
    getBan(type: "client" | "ip", id: string): BanEntry | undefined;
    clearBans(): void;
    saveAuditEntry(entry: AuditEntry): void;
    getAuditEntries(limit?: number): AuditEntry[];
    getAuditEntriesByUser(userId: string, limit?: number): AuditEntry[];
    getAuditEntriesByAction(action: AuditAction, limit?: number): AuditEntry[];
    getAuditEntriesInRange(startTime: number, endTime: number): AuditEntry[];
    clearAudit(): void;
    getAuditSize(): number;
    close(): void;
}
//# sourceMappingURL=sqlite.d.ts.map