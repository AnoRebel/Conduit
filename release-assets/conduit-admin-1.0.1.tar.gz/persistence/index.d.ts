import type { AuditAction, AuditEntry, BanEntry } from "../types.js";
/** Configuration for selecting the persistence backend. */
export interface PersistenceConfig {
    /** Storage type: "memory" (default) or "sqlite" */
    type: "memory" | "sqlite";
    /** Path to SQLite database file (only for type: "sqlite") */
    dbPath?: string;
}
/** Abstract data store for persisting bans and audit entries. */
export interface PersistenceStore {
    saveBan(entry: BanEntry): void;
    removeBan(type: "client" | "ip", id: string): boolean;
    getBans(): BanEntry[];
    getBan(type: "client" | "ip", id: string): BanEntry | undefined;
    clearBans(): void;
    saveAuditEntry(entry: AuditEntry): void;
    getAuditEntries(limit?: number): AuditEntry[];
    getAuditEntriesByUser(userId: string, limit?: number): AuditEntry[];
    getAuditEntriesByAction(action: AuditAction, limit?: number): AuditEntry[];
    getAuditEntriesInRange(startTime: number, endTime: number): AuditEntry[];
    clearAudit(): void;
    getAuditSize(): number;
    close(): void;
}
/** Create a {@link PersistenceStore} based on the given configuration. */
export declare function createPersistenceStore(config?: PersistenceConfig): PersistenceStore;
export { MemoryStore } from "./memory.js";
export { SQLiteStore } from "./sqlite.js";
//# sourceMappingURL=index.d.ts.map