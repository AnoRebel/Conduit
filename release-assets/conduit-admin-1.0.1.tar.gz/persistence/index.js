// ============================================================================
// Persistence Store Interface
// ============================================================================
import { MemoryStore } from "./memory.js";
import { SQLiteStore } from "./sqlite.js";
// ============================================================================
// Factory
// ============================================================================
/** Create a {@link PersistenceStore} based on the given configuration. */
export function createPersistenceStore(config = { type: "memory" }) {
    if (config.type === "sqlite") {
        return new SQLiteStore(config.dbPath || "conduit-admin.db");
    }
    return new MemoryStore();
}
export { MemoryStore } from "./memory.js";
export { SQLiteStore } from "./sqlite.js";
//# sourceMappingURL=index.js.map