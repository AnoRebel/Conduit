import type { MetricsCollector } from "./collector.js";
/**
 * Minimal interface for what we need from ConduitServerCore
 * This avoids a hard dependency on @conduit/server
 */
export interface InstrumentableServerCore {
    readonly realm: {
        getClientIds(): string[];
        getClient(id: string): {
            id: string;
        } | undefined;
    };
    readonly config: {
        rateLimit?: {
            enabled?: boolean;
        };
    };
    handleConnection: (...args: unknown[]) => unknown;
    handleMessage: (...args: unknown[]) => void;
    handleDisconnect: (...args: unknown[]) => void;
}
/** Callback hooks invoked by instrumented server core methods for custom side-effects. */
export interface InstrumentationHooks {
    onConnectionOpened?: (clientId: string) => void;
    onConnectionClosed?: (clientId: string) => void;
    onMessageRelayed?: (clientId: string) => void;
    onMessageQueued?: () => void;
    onRateLimitHit?: () => void;
    onRateLimitRejection?: () => void;
    onError?: (type: string) => void;
}
/**
 * Instrument a ConduitServerCore to collect metrics
 * Uses method wrapping to non-invasively collect data
 */
export declare function instrumentServerCore(core: InstrumentableServerCore, collector: MetricsCollector, hooks?: InstrumentationHooks): () => void;
/**
 * Create a metrics-aware proxy of ConduitServerCore
 * Alternative to direct instrumentation - creates a wrapper object
 */
export declare function createMetricsProxy<T extends InstrumentableServerCore>(core: T, collector: MetricsCollector, hooks?: InstrumentationHooks): T;
/**
 * Sync current realm state to metrics
 * Useful for initial synchronization when attaching to an existing server
 */
export declare function syncRealmToMetrics(core: InstrumentableServerCore, collector: MetricsCollector): void;
//# sourceMappingURL=instrumentation.d.ts.map