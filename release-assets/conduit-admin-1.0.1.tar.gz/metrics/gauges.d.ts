/**
 * Gauge for tracking values that can go up and down
 */
export declare class Gauge {
    private _value;
    private _min;
    private _max;
    get value(): number;
    get min(): number;
    get max(): number;
    set(value: number): void;
    increment(amount?: number): void;
    decrement(amount?: number): void;
    reset(): void;
    /**
     * Reset min/max tracking while keeping current value
     */
    resetMinMax(): void;
}
/**
 * Map of named gauges for tracking categorized values
 */
export declare class GaugeMap {
    private readonly _gauges;
    private _getOrCreate;
    set(key: string, value: number): void;
    increment(key: string, amount?: number): void;
    decrement(key: string, amount?: number): void;
    get(key: string): number;
    getGauge(key: string): Gauge | undefined;
    getAll(): Record<string, number>;
    keys(): string[];
    reset(): void;
    delete(key: string): boolean;
}
//# sourceMappingURL=gauges.d.ts.map