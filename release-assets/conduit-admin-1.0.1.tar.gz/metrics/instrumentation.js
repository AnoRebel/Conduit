/**
 * Instrument a ConduitServerCore to collect metrics
 * Uses method wrapping to non-invasively collect data
 */
export function instrumentServerCore(core, collector, hooks) {
    // Store original methods
    const originalHandleConnection = core.handleConnection.bind(core);
    const originalHandleMessage = core.handleMessage.bind(core);
    const originalHandleDisconnect = core.handleDisconnect.bind(core);
    // Wrap handleConnection
    core.handleConnection = (...args) => {
        const result = originalHandleConnection(...args);
        if (result) {
            // Connection succeeded
            collector.connectionsOpened.increment();
            collector.activeConnections.increment();
            hooks?.onConnectionOpened?.(result.id ?? "unknown");
        }
        return result;
    };
    // Wrap handleMessage
    core.handleMessage = (...args) => {
        const startTime = performance.now();
        const client = args[0];
        try {
            originalHandleMessage(...args);
            // Message was processed (relayed or queued)
            collector.messagesRelayed.increment();
            hooks?.onMessageRelayed?.(client?.id ?? "unknown");
            // Record latency
            const latencyMs = performance.now() - startTime;
            collector.latency.record(latencyMs);
        }
        catch (error) {
            collector.recordError("message_handling");
            hooks?.onError?.("message_handling");
            throw error;
        }
    };
    // Wrap handleDisconnect
    core.handleDisconnect = (...args) => {
        const client = args[0];
        originalHandleDisconnect(...args);
        collector.connectionsClosed.increment();
        collector.activeConnections.decrement();
        hooks?.onConnectionClosed?.(client?.id ?? "unknown");
    };
    // Return cleanup function to restore original methods
    return function uninstrument() {
        core.handleConnection =
            originalHandleConnection;
        core.handleMessage = originalHandleMessage;
        core.handleDisconnect =
            originalHandleDisconnect;
    };
}
/**
 * Create a metrics-aware proxy of ConduitServerCore
 * Alternative to direct instrumentation - creates a wrapper object
 */
export function createMetricsProxy(core, collector, hooks) {
    return new Proxy(core, {
        get(target, prop, receiver) {
            const value = Reflect.get(target, prop, receiver);
            if (prop === "handleConnection" && typeof value === "function") {
                return (...args) => {
                    const result = value.apply(target, args);
                    if (result) {
                        collector.connectionsOpened.increment();
                        collector.activeConnections.increment();
                        hooks?.onConnectionOpened?.(result.id ?? "unknown");
                    }
                    return result;
                };
            }
            if (prop === "handleMessage" && typeof value === "function") {
                return (...args) => {
                    const startTime = performance.now();
                    const client = args[0];
                    try {
                        value.apply(target, args);
                        collector.messagesRelayed.increment();
                        hooks?.onMessageRelayed?.(client?.id ?? "unknown");
                        const latencyMs = performance.now() - startTime;
                        collector.latency.record(latencyMs);
                    }
                    catch (error) {
                        collector.recordError("message_handling");
                        hooks?.onError?.("message_handling");
                        throw error;
                    }
                };
            }
            if (prop === "handleDisconnect" && typeof value === "function") {
                return (...args) => {
                    const client = args[0];
                    value.apply(target, args);
                    collector.connectionsClosed.increment();
                    collector.activeConnections.decrement();
                    hooks?.onConnectionClosed?.(client?.id ?? "unknown");
                };
            }
            return value;
        },
    });
}
/**
 * Sync current realm state to metrics
 * Useful for initial synchronization when attaching to an existing server
 */
export function syncRealmToMetrics(core, collector) {
    const clientCount = core.realm.getClientIds().length;
    collector.activeConnections.set(clientCount);
}
//# sourceMappingURL=instrumentation.js.map