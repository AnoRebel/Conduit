/**
 * Simple monotonically increasing counter
 */
export declare class Counter {
    private _value;
    get value(): number;
    increment(amount?: number): void;
    reset(): void;
}
/**
 * Map of named counters for tracking categorized counts
 */
export declare class CounterMap {
    private readonly _counters;
    increment(key: string, amount?: number): void;
    get(key: string): number;
    getAll(): Record<string, number>;
    keys(): string[];
    total(): number;
    reset(): void;
    delete(key: string): boolean;
}
//# sourceMappingURL=counters.d.ts.map