/**
 * Simple monotonically increasing counter
 */
export class Counter {
    _value = 0;
    get value() {
        return this._value;
    }
    increment(amount = 1) {
        if (amount < 0) {
            throw new Error("Counter can only be incremented by positive values");
        }
        this._value += amount;
    }
    reset() {
        this._value = 0;
    }
}
/**
 * Map of named counters for tracking categorized counts
 */
export class CounterMap {
    _counters = new Map();
    increment(key, amount = 1) {
        if (amount < 0) {
            throw new Error("Counter can only be incremented by positive values");
        }
        const current = this._counters.get(key) ?? 0;
        this._counters.set(key, current + amount);
    }
    get(key) {
        return this._counters.get(key) ?? 0;
    }
    getAll() {
        const result = {};
        for (const [key, value] of this._counters) {
            result[key] = value;
        }
        return result;
    }
    keys() {
        return Array.from(this._counters.keys());
    }
    total() {
        let sum = 0;
        for (const value of this._counters.values()) {
            sum += value;
        }
        return sum;
    }
    reset() {
        this._counters.clear();
    }
    delete(key) {
        return this._counters.delete(key);
    }
}
//# sourceMappingURL=counters.js.map