/**
 * Gauge for tracking values that can go up and down
 */
export class Gauge {
    _value = 0;
    _min = 0;
    _max = 0;
    get value() {
        return this._value;
    }
    get min() {
        return this._min;
    }
    get max() {
        return this._max;
    }
    set(value) {
        this._value = value;
        if (value < this._min) {
            this._min = value;
        }
        if (value > this._max) {
            this._max = value;
        }
    }
    increment(amount = 1) {
        this.set(this._value + amount);
    }
    decrement(amount = 1) {
        this.set(this._value - amount);
    }
    reset() {
        this._value = 0;
        this._min = 0;
        this._max = 0;
    }
    /**
     * Reset min/max tracking while keeping current value
     */
    resetMinMax() {
        this._min = this._value;
        this._max = this._value;
    }
}
/**
 * Map of named gauges for tracking categorized values
 */
export class GaugeMap {
    _gauges = new Map();
    _getOrCreate(key) {
        let gauge = this._gauges.get(key);
        if (!gauge) {
            gauge = new Gauge();
            this._gauges.set(key, gauge);
        }
        return gauge;
    }
    set(key, value) {
        this._getOrCreate(key).set(value);
    }
    increment(key, amount = 1) {
        this._getOrCreate(key).increment(amount);
    }
    decrement(key, amount = 1) {
        this._getOrCreate(key).decrement(amount);
    }
    get(key) {
        return this._gauges.get(key)?.value ?? 0;
    }
    getGauge(key) {
        return this._gauges.get(key);
    }
    getAll() {
        const result = {};
        for (const [key, gauge] of this._gauges) {
            result[key] = gauge.value;
        }
        return result;
    }
    keys() {
        return Array.from(this._gauges.keys());
    }
    reset() {
        this._gauges.clear();
    }
    delete(key) {
        return this._gauges.delete(key);
    }
}
//# sourceMappingURL=gauges.js.map