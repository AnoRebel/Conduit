/** A single data point in a time series. */
export interface TimeSeriesPoint {
    timestamp: number;
    value: number;
}
/**
 * Circular buffer for efficient time series storage
 * Automatically overwrites oldest entries when capacity is reached
 */
export declare class CircularTimeSeries {
    private readonly _buffer;
    private readonly _capacity;
    private _head;
    private _size;
    constructor(capacity: number);
    get size(): number;
    get capacity(): number;
    /**
     * Record a value at the current timestamp
     */
    record(value: number, timestamp?: number): void;
    /**
     * Get all points in chronological order
     */
    getAll(): TimeSeriesPoint[];
    /**
     * Get points within a time range
     */
    getRange(startTime: number, endTime: number): TimeSeriesPoint[];
    /**
     * Get the most recent N points
     */
    getRecent(count: number): TimeSeriesPoint[];
    /**
     * Get the most recent point
     */
    getLast(): TimeSeriesPoint | undefined;
    /**
     * Calculate statistics over the current data
     */
    getStats(): TimeSeriesStats;
    /**
     * Calculate rate of change (per second) between first and last points
     */
    getRatePerSecond(): number;
    /**
     * Clear all data
     */
    clear(): void;
}
/** Aggregate statistics computed over a {@link CircularTimeSeries}. */
export interface TimeSeriesStats {
    count: number;
    min: number;
    max: number;
    avg: number;
    sum: number;
    first: TimeSeriesPoint | undefined;
    last: TimeSeriesPoint | undefined;
}
/**
 * Named collection of time series
 */
export declare class TimeSeriesMap {
    private readonly _series;
    private readonly _defaultCapacity;
    constructor(defaultCapacity?: number);
    private _getOrCreate;
    record(key: string, value: number, timestamp?: number): void;
    get(key: string): CircularTimeSeries | undefined;
    getAll(key: string): TimeSeriesPoint[];
    getStats(key: string): TimeSeriesStats | undefined;
    keys(): string[];
    clear(): void;
    clearSeries(key: string): void;
    delete(key: string): boolean;
}
//# sourceMappingURL=timeseries.d.ts.map