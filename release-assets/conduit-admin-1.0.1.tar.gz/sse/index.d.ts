import type { ServerResponse } from "node:http";
import type { AdminCore } from "../core/index.js";
import type { AdminEventType, ServerToClientEvents } from "../websocket/events.js";
/** A connected SSE (Server-Sent Events) client. */
export interface SSEClient {
    id: string;
    response: ServerResponse;
    subscriptions: Set<AdminEventType>;
}
/** SSE server that pushes real-time admin events to connected clients. */
export interface SSEServer {
    addClient(response: ServerResponse, subscriptions?: AdminEventType[]): SSEClient;
    removeClient(clientId: string): boolean;
    broadcast<T extends AdminEventType>(type: T, data: ServerToClientEvents[T]): number;
    broadcastToSubscribers<T extends AdminEventType>(type: T, data: ServerToClientEvents[T]): number;
    getClients(): SSEClient[];
    getClientCount(): number;
    close(): void;
}
/** Options for creating an {@link SSEServer}. */
export interface SSEServerOptions {
    admin: AdminCore;
    metricsInterval?: number;
    heartbeatInterval?: number;
}
/**
 * Create an SSE server for real-time admin updates
 */
export declare function createSSEServer(options: SSEServerOptions): SSEServer;
/** SSE route handlers returned by {@link createSSERoutes}. */
export interface SSERoutes {
    /** Subscribe to real-time events via SSE, optionally filtering by event type. */
    events(response: ServerResponse, subscriptions?: AdminEventType[]): SSEClient;
    /** Subscribe to audit and error log events via SSE. */
    logs(response: ServerResponse): SSEClient;
}
/** Create SSE route handlers for the admin API. */
export declare function createSSERoutes(sse: SSEServer): SSERoutes;
//# sourceMappingURL=index.d.ts.map