/**
 * Create an SSE server for real-time admin updates
 */
export function createSSEServer(options) {
    const { admin, metricsInterval = 5000, heartbeatInterval = 30000 } = options;
    const clients = new Map();
    let clientIdCounter = 0;
    let metricsTimer = null;
    let heartbeatTimer = null;
    // Start periodic tasks
    startMetricsInterval();
    startHeartbeatInterval();
    function addClient(response, subscriptions = ["metrics:update"]) {
        const clientId = `sse_${++clientIdCounter}_${Date.now()}`;
        // Set SSE headers
        response.writeHead(200, {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
            "X-Accel-Buffering": "no", // Disable nginx buffering
        });
        const client = {
            id: clientId,
            response,
            subscriptions: new Set(subscriptions),
        };
        clients.set(clientId, client);
        // Send initial connection event
        sendEvent(client, "connected", { clientId, subscriptions });
        // Handle client disconnect
        response.on("close", () => {
            clients.delete(clientId);
        });
        return client;
    }
    function removeClient(clientId) {
        const client = clients.get(clientId);
        if (client) {
            try {
                client.response.end();
            }
            catch {
                // Response may already be closed
            }
            return clients.delete(clientId);
        }
        return false;
    }
    function sendEvent(client, type, data) {
        try {
            const payload = JSON.stringify(data);
            client.response.write(`event: ${type}\n`);
            client.response.write(`data: ${payload}\n\n`);
            return true;
        }
        catch {
            // Client may have disconnected
            clients.delete(client.id);
            return false;
        }
    }
    function broadcast(type, data) {
        let count = 0;
        for (const client of clients.values()) {
            if (sendEvent(client, type, data)) {
                count++;
            }
        }
        return count;
    }
    function broadcastToSubscribers(type, data) {
        let count = 0;
        for (const client of clients.values()) {
            if (client.subscriptions.has(type)) {
                if (sendEvent(client, type, data)) {
                    count++;
                }
            }
        }
        return count;
    }
    function getClients() {
        return Array.from(clients.values());
    }
    function getClientCount() {
        return clients.size;
    }
    function close() {
        if (metricsTimer) {
            clearInterval(metricsTimer);
            metricsTimer = null;
        }
        if (heartbeatTimer) {
            clearInterval(heartbeatTimer);
            heartbeatTimer = null;
        }
        for (const client of clients.values()) {
            try {
                client.response.end();
            }
            catch {
                // Response may already be closed
            }
        }
        clients.clear();
    }
    function startMetricsInterval() {
        metricsTimer = setInterval(() => {
            const snapshot = admin.getMetricsSnapshot();
            broadcastToSubscribers("metrics:update", snapshot);
        }, metricsInterval);
        if (metricsTimer.unref) {
            metricsTimer.unref();
        }
    }
    function startHeartbeatInterval() {
        heartbeatTimer = setInterval(() => {
            for (const client of clients.values()) {
                try {
                    // Send comment as heartbeat (SSE spec)
                    client.response.write(": heartbeat\n\n");
                }
                catch {
                    clients.delete(client.id);
                }
            }
        }, heartbeatInterval);
        if (heartbeatTimer.unref) {
            heartbeatTimer.unref();
        }
    }
    return {
        addClient,
        removeClient,
        broadcast,
        broadcastToSubscribers,
        getClients,
        getClientCount,
        close,
    };
}
/** Create SSE route handlers for the admin API. */
export function createSSERoutes(sse) {
    return {
        events: (response, subscriptions) => {
            return sse.addClient(response, subscriptions);
        },
        logs: (response) => {
            return sse.addClient(response, ["audit:entry", "error:occurred"]);
        },
    };
}
//# sourceMappingURL=index.js.map