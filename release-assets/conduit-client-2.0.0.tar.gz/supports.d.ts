/** Detected browser/runtime capabilities relevant to Conduit. */
export interface BrowserSupport {
    /** Whether the runtime is a browser (vs. Node.js). */
    browser: boolean;
    /** Whether WebRTC APIs are available. */
    webRTC: boolean;
    /** Whether getUserMedia (audio/video capture) is available. */
    audioVideo: boolean;
    /** Whether RTCDataChannel is available. */
    data: boolean;
    /** Whether binary Blob creation is supported. */
    binaryBlob: boolean;
    /** Whether reliable (ordered) data channels are available. */
    reliable: boolean;
    /** Whether the WebSocket API is available. */
    webSocket: boolean;
}
/** Detect the current runtime's WebRTC and related capabilities. */
export declare function detectSupport(): BrowserSupport;
/** Cached result of {@link detectSupport}, evaluated once at module load. */
export declare const supports: BrowserSupport;
//# sourceMappingURL=supports.d.ts.map