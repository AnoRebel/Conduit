/** Verbosity level for the Conduit client logger. */
export declare enum LogLevel {
    /** No logging output. */
    Disabled = 0,
    /** Log only errors. */
    Errors = 1,
    /** Log errors and warnings. */
    Warnings = 2,
    /** Log everything (debug). */
    All = 3
}
/** Logger with configurable verbosity for the Conduit client. */
export declare class Logger {
    /** Current verbosity level. */
    private _logLevel;
    /** Get the current logging verbosity level. */
    get logLevel(): LogLevel;
    /** Set the logging verbosity level. */
    set logLevel(level: LogLevel);
    /** Log a debug message (only shown when level is {@link LogLevel.All}). */
    log(...args: unknown[]): void;
    /** Log a warning message (shown when level ≥ {@link LogLevel.Warnings}). */
    warn(...args: unknown[]): void;
    /** Log an error message (shown when level ≥ {@link LogLevel.Errors}). */
    error(...args: unknown[]): void;
    /** Replace the default logging function with a custom implementation. */
    setLogFunction(fn: (level: LogLevel, ...args: unknown[]) => void): void;
    /** Default print implementation, writes to the console. */
    private _print;
}
/** Singleton logger instance used throughout the Conduit client. */
export declare const logger: Logger;
//# sourceMappingURL=logger.d.ts.map