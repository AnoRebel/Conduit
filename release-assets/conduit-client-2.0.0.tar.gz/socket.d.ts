import type { MessageType, ServerMessage } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
import type { ConduitOptions } from "./conduit.js";
/** Events emitted by the signaling {@link Socket}. */
export interface SocketEvents {
    /** Fired when a parsed server message is received. */
    message: (data: ServerMessage) => void;
    /** Fired when a WebSocket error occurs. */
    error: (error: Error) => void;
    /** Fired when the WebSocket is explicitly closed. */
    close: () => void;
    /** Fired when the connection is lost (after reconnection attempts). */
    disconnected: () => void;
}
/**
 * WebSocket wrapper for the Conduit signaling protocol.
 * Handles connection, reconnection, message parsing, and queuing.
 */
export declare class Socket extends EventEmitter<SocketEvents> {
    /** Conduit options used to build the WebSocket URL. */
    private readonly _options;
    /** The active WebSocket instance. */
    private _ws;
    /** Whether the socket has been intentionally disconnected. */
    private _disconnected;
    /** The peer ID associated with this socket session. */
    private _id;
    /** Messages queued while the socket is not yet open. */
    private _messagesQueue;
    /** Number of reconnection attempts so far. */
    private _reconnectAttempts;
    /** Maximum reconnection attempts before giving up. */
    private _maxReconnectAttempts;
    /** Timer ID for the next reconnection attempt. */
    private _reconnectTimeout;
    constructor(
    /** Conduit options used to build the WebSocket URL. */
    _options: ConduitOptions);
    /** Open a WebSocket connection to the signaling server for the given peer ID. */
    start(id: string, token: string): void;
    /** Build the WebSocket URL from connection options. */
    private _buildUrl;
    /** Attempt to reconnect after an unexpected close, with exponential backoff. */
    private _tryReconnect;
    /** Send a signaling message, or queue it if the socket is not yet open. */
    send(data: {
        type: MessageType;
        payload?: unknown;
    }): void;
    /** Flush all queued messages through the now-open socket. */
    private _sendQueuedMessages;
    /** Close the WebSocket connection and cancel any pending reconnection. */
    close(): void;
    /** Whether the underlying WebSocket is currently open and ready. */
    get isOpen(): boolean;
}
//# sourceMappingURL=socket.d.ts.map