import type { ConduitOptions } from "./conduit.js";
/** HTTP client for the Conduit signaling server REST endpoints. */
export declare class API {
    /** Conduit options used to build request URLs. */
    private readonly _options;
    /** Create an API client with the given connection options. */
    constructor(options: ConduitOptions);
    /** Construct a full URL for the given API path. */
    private _buildUrl;
    /** Request a new peer ID from the signaling server. */
    retrieveId(): Promise<string>;
    /** Fetch a list of all connected peer IDs from the signaling server (discovery). */
    listAllConduits(): Promise<string[]>;
}
//# sourceMappingURL=api.d.ts.map