/**
 * Load polyfills for older browsers if needed.
 * This is called automatically but can be called explicitly.
 */
export declare function loadPolyfills(): Promise<void>;
//# sourceMappingURL=index.d.ts.map