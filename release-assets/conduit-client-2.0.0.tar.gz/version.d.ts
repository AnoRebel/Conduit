export { VERSION as version } from "@conduit/shared";
//# sourceMappingURL=version.d.ts.map