import type { ConduitErrorType } from "@conduit/shared";
/**
 * Custom error class for Conduit-specific errors.
 * Extends the standard `Error` with a typed `type` field
 * from {@link ConduitErrorType}.
 */
export declare class ConduitError extends Error {
    /** The specific Conduit error type. */
    readonly type: ConduitErrorType;
    constructor(
    /** The specific Conduit error type. */
    type: ConduitErrorType, message: string);
}
//# sourceMappingURL=conduitError.d.ts.map