import { ConnectionType, type ServerMessage } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
import type { BaseConnectionOptions } from "./baseconnection.js";
import type { Conduit } from "./conduit.js";
import { type NegotiableConnection } from "./negotiator.js";
/** Events emitted by a {@link MediaConnection}. */
export interface MediaConnectionEvents {
    /** Fired when a remote media stream is received. */
    stream: (stream: MediaStream) => void;
    /** Fired when the media connection is ready. */
    open: () => void;
    /** Fired when the media connection is closed. */
    close: () => void;
    /** Fired when an error occurs on the media connection. */
    error: (error: Error) => void;
    /** Fired when the ICE connection state changes. */
    iceStateChanged: (state: RTCIceConnectionState) => void;
}
/** Options for creating a {@link MediaConnection}. */
export interface MediaConnectionOptions extends BaseConnectionOptions {
    /** The local media stream to send to the remote peer. */
    _stream?: MediaStream;
}
/**
 * A WebRTC media connection to a remote peer for audio/video streaming.
 * Use {@link Conduit.call} to initiate a call, or listen for the `"call"` event to answer one.
 */
export declare class MediaConnection extends EventEmitter<MediaConnectionEvents> implements NegotiableConnection {
    /** Connection type discriminator, always `ConnectionType.Media`. */
    readonly type = ConnectionType.Media;
    /** The remote peer ID this media connection is with. */
    readonly remote: string;
    /** The {@link Conduit} instance that owns this connection. */
    readonly provider: Conduit;
    /** Unique identifier for this specific media connection. */
    readonly connectionId: string;
    /** Human-readable label for the connection. */
    readonly label: string;
    /** Arbitrary metadata associated with this connection. */
    readonly metadata: unknown;
    /** Configuration options for this media connection. */
    readonly options: MediaConnectionOptions;
    /** Whether the media connection is currently open. */
    protected _open: boolean;
    /** The underlying RTCPeerConnection instance. */
    protected _peerConnection: RTCPeerConnection | null;
    /** The local media stream being sent to the remote peer. */
    private _localStream;
    /** The remote media stream received from the peer. */
    private _remoteStream;
    /** WebRTC negotiation helper. */
    private _negotiator;
    constructor(remoteId: string, provider: Conduit, options?: MediaConnectionOptions);
    /**
     * Set the RTCPeerConnection instance (called by Negotiator)
     */
    setPeerConnection(pc: RTCPeerConnection): void;
    /** Whether the media connection is currently open. */
    get open(): boolean;
    /** The underlying `RTCPeerConnection`, or `null` before initialization. */
    get peerConnection(): RTCPeerConnection | null;
    /** The local media stream being sent to the remote peer, or `null`. */
    get localStream(): MediaStream | null;
    /** The remote media stream received from the peer, or `null`. */
    get remoteStream(): MediaStream | null;
    /** Initialize the WebRTC peer connection for media exchange. */
    initialize(originator: boolean): Promise<void>;
    /** Add all local stream tracks to the RTCPeerConnection. */
    private _addTracksToConnection;
    /** Listen for remote tracks on the peer connection. */
    private _setupTrackListener;
    /**
     * Answer an incoming media call with the given stream
     */
    answer(stream?: MediaStream): void;
    /** Handle an incoming signaling message (offer, answer, or ICE candidate). */
    handleMessage(message: ServerMessage): void;
    /** Close the media connection, stopping all tracks and releasing resources. */
    close(): void;
    /**
     * Replace a track in the local stream
     */
    replaceTrack(oldTrack: MediaStreamTrack, newTrack: MediaStreamTrack): Promise<void>;
    /**
     * Get stats for the connection
     */
    getStats(): Promise<RTCStatsReport | undefined>;
}
//# sourceMappingURL=mediaconnection.d.ts.map