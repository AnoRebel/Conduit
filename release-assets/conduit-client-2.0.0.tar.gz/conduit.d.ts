import { SerializationType, TransportType } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
import { ConduitError } from "./conduitError.js";
import { AutoConnection, DataConnection, WebSocketConnection } from "./dataconnection/index.js";
import { LogLevel } from "./logger.js";
import { MediaConnection } from "./mediaconnection.js";
import { Socket } from "./socket.js";
/** Events emitted by the {@link Conduit} peer instance. */
export interface ConduitEvents {
    /** Fired when the connection to the signaling server is established and an ID is obtained. */
    open: (id: string) => void;
    /** Fired when a new incoming data connection is received from a remote peer. */
    connection: (connection: DataConnection | AutoConnection | WebSocketConnection) => void;
    /** Fired when an incoming media call is received from a remote peer. */
    call: (mediaConnection: MediaConnection) => void;
    /** Fired when the peer is destroyed and can no longer accept or create connections. */
    close: () => void;
    /** Fired when the peer is disconnected from the signaling server (can reconnect). */
    disconnected: () => void;
    /** Fired when a fatal error occurs. */
    error: (error: ConduitError) => void;
}
/** Configuration options for creating a {@link Conduit} peer instance. */
export interface ConduitOptions {
    /** API key for the signaling server (default: `"conduit"`). */
    key?: string;
    /** Signaling server hostname. */
    host?: string;
    /** Signaling server port. */
    port?: number;
    /** Signaling server path prefix (default: `"/"`). */
    path?: string;
    /** Whether to use a secure (TLS) connection to the signaling server. */
    secure?: boolean;
    /** Authentication token for the signaling server. */
    token?: string;
    /** Custom RTCPeerConnection configuration (ICE servers, etc.). */
    config?: RTCConfiguration;
    /** Logging verbosity level. */
    debug?: LogLevel;
    /** Referrer policy for HTTP requests to the signaling server. */
    referrerPolicy?: ReferrerPolicy;
    /** Preferred transport type for data connections. */
    transport?: TransportType;
    /** Default serialization format for data connections. */
    serialization?: SerializationType;
}
/** Options for establishing a data connection to a remote peer via {@link Conduit.connect}. */
export interface ConnectOptions {
    /** A human-readable label for the connection. */
    label?: string;
    /** Arbitrary metadata to associate with the connection. */
    metadata?: unknown;
    /** Serialization format for data sent over this connection. */
    serialization?: SerializationType;
    /** Whether the data channel should guarantee ordered, reliable delivery. */
    reliable?: boolean;
    /** Transport type override for this specific connection. */
    transport?: TransportType;
    /** Timeout in ms before falling back from WebRTC to WebSocket (default: 10 000). */
    webrtcTimeout?: number;
}
/** Options for initiating a media call to a remote peer via {@link Conduit.call}. */
export interface CallOptions {
    /** Arbitrary metadata to associate with the call. */
    metadata?: unknown;
    /** Optional transform applied to the SDP before sending the offer. */
    sdpTransform?: (sdp: string) => string;
}
/**
 * The main Conduit peer client.
 *
 * Creates a connection to the signaling server and provides methods to connect
 * to remote peers for data exchange and media calls.
 *
 * @example
 * ```typescript
 * const peer = new Conduit('my-id', { host: 'localhost', port: 9000 });
 * peer.on('open', (id) => {
 *   const conn = peer.connect('remote-id');
 *   conn.on('open', () => conn.send('hello'));
 * });
 * ```
 */
export declare class Conduit extends EventEmitter<ConduitEvents> {
    /** Current peer ID, `null` until the server assigns one. */
    private _id;
    /** Last server-assigned ID, used for reconnection. */
    private _lastServerId;
    /** Whether {@link destroy} has been called. */
    private _destroyed;
    /** Whether the peer is disconnected from the signaling server. */
    private _disconnected;
    /** Whether the signaling server connection is open. */
    private _open;
    /** Map of remote peer IDs to their active connections. */
    private _connections;
    /** Messages received before the target connection was created. */
    private _lostMessages;
    /** Resolved configuration options for this peer. */
    readonly options: ConduitOptions;
    /** The underlying WebSocket connection to the signaling server. */
    readonly socket: Socket;
    /** HTTP API client for ID retrieval and discovery. */
    private readonly _api;
    constructor(options?: ConduitOptions);
    constructor(id: string, options?: ConduitOptions);
    /** The unique peer ID assigned by the signaling server, or `null` if not yet connected. */
    get id(): string | null;
    /** Whether the connection to the signaling server is open. */
    get open(): boolean;
    /** Whether this peer has been permanently destroyed. */
    get destroyed(): boolean;
    /** Whether the peer is currently disconnected from the signaling server. */
    get disconnected(): boolean;
    /** Map of remote peer IDs to their active connections. */
    get connections(): Map<string, Array<DataConnection | AutoConnection | WebSocketConnection | MediaConnection>>;
    /** Request a new peer ID from the signaling server. */
    private _retrieveId;
    /** Initialize the peer with the given ID and start the socket. */
    private _initialize;
    /** Wire up event handlers on the signaling socket. */
    private _setupSocketListeners;
    /** Dispatch an incoming server message to the appropriate handler. */
    private _handleMessage;
    /** Handle an incoming OFFER message and create the appropriate connection. */
    private _handleOffer;
    /** Route a connection-level message (ANSWER, CANDIDATE, RELAY) to the right connection. */
    private _handleConnectionMessage;
    /** Buffer a message whose target connection does not exist yet. */
    private _storeLostMessage;
    /** Deliver previously buffered messages to a newly created connection. */
    private _deliverLostMessages;
    /** Register a new connection and deliver any buffered messages for it. */
    private _addConnection;
    /** Close and remove all connections for a remote peer. */
    private _cleanupRemote;
    /**
     * Connect to a remote conduit with a data connection
     */
    connect(remoteId: string, options?: ConnectOptions): DataConnection | AutoConnection | WebSocketConnection;
    /**
     * Call a remote conduit with a media stream
     */
    call(remoteId: string, stream: MediaStream, options?: CallOptions): MediaConnection;
    /**
     * Disconnect from the signaling server
     */
    disconnect(): void;
    /**
     * Reconnect to the signaling server
     */
    reconnect(): void;
    /**
     * Destroy the conduit and close all connections
     */
    destroy(): void;
    /**
     * Get a list of all connected conduits (discovery)
     */
    listAllConduits(): Promise<string[]>;
    /** Emit a fatal error and destroy the peer. */
    private _abort;
    /** Construct a {@link ConduitError} and emit it on the `"error"` event. */
    private _emitError;
}
//# sourceMappingURL=conduit.d.ts.map