/**
 * Global export for UMD/browser usage
 * This file exposes Conduit on the window object
 */
export * from "./index.js";
//# sourceMappingURL=global.d.ts.map