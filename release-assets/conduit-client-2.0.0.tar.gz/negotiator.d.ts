import { type ConnectionType } from "@conduit/shared";
import type { Conduit } from "./conduit.js";
/**
 * Interface for connections that can be negotiated.
 * Both DataConnection and MediaConnection implement this interface.
 */
export interface NegotiableConnection {
    /** The connection type (data or media). */
    readonly type: ConnectionType;
    /** The remote peer ID. */
    readonly remote: string;
    /** The owning Conduit instance. */
    readonly provider: Conduit;
    /** Unique connection identifier. */
    readonly connectionId: string;
    /** Human-readable label. */
    readonly label: string;
    /** Arbitrary metadata. */
    readonly metadata: unknown;
    /** Connection-specific options. */
    readonly options: {
        /** Serialization format name. */
        serialization?: string;
        /** Whether reliable delivery is requested. */
        reliable?: boolean;
    };
    /** The underlying RTCPeerConnection, or `null`. */
    peerConnection: RTCPeerConnection | null;
    /** Assign an RTCPeerConnection to the connection. */
    setPeerConnection(pc: RTCPeerConnection): void;
    /** Emit an event on the connection. */
    emit(event: string, ...args: unknown[]): boolean;
    /** Close the connection. */
    close(): void;
}
/** Options passed to {@link Negotiator.startConnection}. */
export interface NegotiatorOptions {
    /** Whether this peer is the connection originator (caller). */
    originator?: boolean;
    /** Optional transform applied to the SDP before sending. */
    sdpTransform?: (sdp: string) => string;
}
/**
 * Manages WebRTC session negotiation (offer/answer/ICE) using the perfect-negotiation pattern.
 */
export declare class Negotiator {
    /** The connection being negotiated. */
    private readonly _connection;
    /** The Conduit instance used for signaling. */
    private readonly _conduit;
    /** Whether an offer is currently being created. */
    private _makingOffer;
    /** Whether to ignore a colliding offer. */
    private _ignoreOffer;
    /** Create a Negotiator for the given connection. */
    constructor(connection: NegotiableConnection);
    /** Create an RTCPeerConnection and begin negotiation. */
    startConnection(options?: NegotiatorOptions): Promise<void>;
    /** Create and configure a new RTCPeerConnection. */
    private _createPeerConnection;
    /** Attach ICE, signaling, and negotiation listeners to the peer connection. */
    private _setupListeners;
    /** Process an incoming SDP offer and send back an answer. */
    handleOffer(offer: RTCSessionDescriptionInit): Promise<void>;
    /** Apply an incoming SDP answer to the peer connection. */
    handleAnswer(answer: RTCSessionDescriptionInit): Promise<void>;
    /** Add an incoming ICE candidate to the peer connection. */
    handleCandidate(candidate: RTCIceCandidateInit): Promise<void>;
    /** Remove all event listeners from the peer connection. */
    cleanup(): void;
}
//# sourceMappingURL=negotiator.d.ts.map