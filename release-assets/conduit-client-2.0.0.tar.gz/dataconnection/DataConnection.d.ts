import { ConnectionType, SerializationType, type ServerMessage } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
import type { BaseConnectionOptions } from "../baseconnection.js";
import type { Conduit } from "../conduit.js";
import { type NegotiableConnection } from "../negotiator.js";
/** Events emitted by a {@link DataConnection}. */
export interface DataConnectionEvents {
    /** Fired when the WebRTC data channel is open and ready. */
    open: () => void;
    /** Fired when data is received from the remote peer. */
    data: (data: unknown) => void;
    /** Fired when the data channel is closed. */
    close: () => void;
    /** Fired when an error occurs on the data channel. */
    error: (error: Error) => void;
    /** Fired when the ICE connection state changes. */
    iceStateChanged: (state: RTCIceConnectionState) => void;
}
/** Options for creating a {@link DataConnection}. */
export interface DataConnectionOptions extends BaseConnectionOptions {
    /** Serialization format for data sent over this connection. */
    serialization?: SerializationType;
    /** Whether the data channel should guarantee ordered delivery. */
    reliable?: boolean;
    /** Maximum buffer size in bytes (default: 64 KB). Messages are dropped if exceeded. */
    maxBufferSize?: number;
}
/**
 * A WebRTC data channel connection to a remote peer.
 * Supports binary, JSON, and raw serialization modes.
 */
export declare class DataConnection extends EventEmitter<DataConnectionEvents> implements NegotiableConnection {
    /** Connection type discriminator, always `ConnectionType.Data`. */
    readonly type = ConnectionType.Data;
    /** The remote peer ID this connection is with. */
    readonly remote: string;
    /** The {@link Conduit} instance that owns this connection. */
    readonly provider: Conduit;
    /** Unique identifier for this specific data connection. */
    readonly connectionId: string;
    /** Human-readable label for the data channel. */
    readonly label: string;
    /** Arbitrary metadata associated with this connection. */
    readonly metadata: unknown;
    /** The serialization format used for encoding/decoding data. */
    readonly serialization: SerializationType;
    /** Whether the data channel guarantees ordered, reliable delivery. */
    readonly reliable: boolean;
    /** Configuration options for this data connection. */
    readonly options: DataConnectionOptions;
    /** Whether the data channel is currently open. */
    protected _open: boolean;
    /** The underlying RTCPeerConnection instance. */
    protected _peerConnection: RTCPeerConnection | null;
    /** The underlying RTCDataChannel instance. */
    private _dataChannel;
    /** WebRTC negotiation helper. */
    private _negotiator;
    /** Outgoing message buffer used before the channel opens. */
    private _buffer;
    /** Current estimated size of the outgoing buffer in bytes. */
    private _bufferSize;
    /** Maximum allowed buffer size in bytes. */
    private _maxBufferSize;
    /** Partially received chunked transfers keyed by chunk ID. */
    private _chunkedData;
    constructor(remoteId: string, provider: Conduit, options?: DataConnectionOptions);
    /**
     * Set the RTCPeerConnection instance (called by Negotiator)
     */
    setPeerConnection(pc: RTCPeerConnection): void;
    /** Whether the data channel is currently open and ready. */
    get open(): boolean;
    /** The underlying `RTCPeerConnection`, or `null` before initialization. */
    get peerConnection(): RTCPeerConnection | null;
    /** The underlying `RTCDataChannel`, or `null` before initialization. */
    get dataChannel(): RTCDataChannel | null;
    /** Current size of the outgoing message buffer in bytes. */
    get bufferSize(): number;
    /** Initialize the WebRTC connection and data channel. */
    initialize(originator: boolean): Promise<void>;
    /** Configure event handlers on the given data channel. */
    private _setupDataChannel;
    /** Deserialize and process an incoming data channel message. */
    private _handleDataMessage;
    /** Type guard for chunked transfer metadata. */
    private _isChunkedData;
    /** Accumulate a single chunk; emit the reassembled blob when all chunks arrive. */
    private _handleChunk;
    /** Send data to the remote peer over the data channel. Buffers if not yet open. */
    send(data: unknown): Promise<void>;
    /** Send all buffered messages now that the channel is open. */
    private _drainBuffer;
    /** Handle an incoming signaling message (answer or ICE candidate). */
    handleMessage(message: ServerMessage): void;
    /** Assign an existing RTCDataChannel to this connection (used for incoming connections). */
    setDataChannel(dataChannel: RTCDataChannel): void;
    /** Estimate the byte size of arbitrary data for buffer-limit checking. */
    private _estimateSize;
    /** Close the data channel and peer connection, releasing all resources. */
    close(): void;
}
//# sourceMappingURL=DataConnection.d.ts.map