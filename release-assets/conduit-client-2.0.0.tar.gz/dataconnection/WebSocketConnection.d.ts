import { ConnectionType, type ServerMessage, TransportType } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
import type { Conduit } from "../conduit.js";
/** Events emitted by a {@link WebSocketConnection}. */
export interface WebSocketConnectionEvents {
    /** Fired when the relay connection is open and ready. */
    open: () => void;
    /** Fired when data is received via the server relay. */
    data: (data: unknown) => void;
    /** Fired when the relay connection is closed. */
    close: () => void;
    /** Fired when an error occurs. */
    error: (error: Error) => void;
}
/** Options for creating a {@link WebSocketConnection}. */
export interface WebSocketConnectionOptions {
    /** Unique identifier for this connection. Auto-generated if omitted. */
    connectionId?: string;
    /** Human-readable label for the connection. */
    label?: string;
    /** Arbitrary metadata attached to the connection. */
    metadata?: unknown;
}
/**
 * WebSocketConnection provides a WebSocket-based fallback transport
 * when WebRTC is not available or fails to connect.
 * Data is relayed through the signaling server.
 */
export declare class WebSocketConnection extends EventEmitter<WebSocketConnectionEvents> {
    /** Connection type discriminator, always `ConnectionType.Data`. */
    readonly type = ConnectionType.Data;
    /** Transport type, always `TransportType.WebSocket`. */
    readonly transport = TransportType.WebSocket;
    /** The remote peer ID this connection relays data to. */
    readonly remote: string;
    /** The {@link Conduit} instance that owns this connection. */
    readonly provider: Conduit;
    /** Unique identifier for this specific connection. */
    readonly connectionId: string;
    /** Human-readable label for the connection. */
    readonly label: string;
    /** Arbitrary metadata associated with this connection. */
    readonly metadata: unknown;
    /** Configuration options for this WebSocket connection. */
    readonly options: WebSocketConnectionOptions;
    /** Whether the relay connection is currently open. */
    private _open;
    constructor(remoteId: string, provider: Conduit, options?: WebSocketConnectionOptions);
    /** Whether the relay connection is currently open. */
    get open(): boolean;
    /**
     * Initialize the WebSocket connection by sending a RELAY_OPEN message
     */
    initialize(): void;
    /**
     * Handle incoming messages from the server
     */
    handleMessage(message: ServerMessage): void;
    /**
     * Send data through the WebSocket relay
     */
    send(data: unknown): void;
    /**
     * Close the WebSocket connection
     */
    close(): void;
    /** Mark the connection as closed and emit the close event. */
    private _handleClose;
}
//# sourceMappingURL=WebSocketConnection.d.ts.map