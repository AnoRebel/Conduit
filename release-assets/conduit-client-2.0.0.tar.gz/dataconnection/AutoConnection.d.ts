import { ConnectionType, type ServerMessage, TransportType } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
import type { Conduit } from "../conduit.js";
import { DataConnection, type DataConnectionOptions } from "./DataConnection.js";
import { WebSocketConnection, type WebSocketConnectionOptions } from "./WebSocketConnection.js";
/** Events emitted by an {@link AutoConnection}. */
export interface AutoConnectionEvents {
    /** Fired when the connection is open and ready. */
    open: () => void;
    /** Fired when data is received from the remote peer. */
    data: (data: unknown) => void;
    /** Fired when the connection is closed. */
    close: () => void;
    /** Fired when an error occurs. */
    error: (error: Error) => void;
    /** Fired when the transport is changed (e.g. WebRTC → WebSocket fallback). */
    transportChanged: (transport: TransportType) => void;
}
/** Options for creating an {@link AutoConnection}. */
export interface AutoConnectionOptions extends DataConnectionOptions, WebSocketConnectionOptions {
    /** Preferred transport; set to force a specific one instead of auto-selecting. */
    preferredTransport?: TransportType;
    /** Timeout in ms before falling back from WebRTC to WebSocket (default: 10 000). */
    webrtcTimeout?: number;
}
/**
 * AutoConnection automatically selects the best transport:
 * 1. Tries WebRTC first (if supported)
 * 2. Falls back to WebSocket relay if WebRTC fails or times out
 */
export declare class AutoConnection extends EventEmitter<AutoConnectionEvents> {
    /** Connection type discriminator, always `ConnectionType.Data`. */
    readonly type = ConnectionType.Data;
    /** The remote peer ID this connection is with. */
    readonly remote: string;
    /** The {@link Conduit} instance that owns this connection. */
    readonly provider: Conduit;
    /** Unique identifier for this specific connection. */
    readonly connectionId: string;
    /** Human-readable label for the connection. */
    readonly label: string;
    /** Arbitrary metadata associated with this connection. */
    readonly metadata: unknown;
    /** Configuration options for this auto connection. */
    readonly options: AutoConnectionOptions;
    /** The currently active underlying connection (WebRTC or WebSocket). */
    private _activeConnection;
    /** The transport type currently in use. */
    private _transport;
    /** Whether the connection is currently open. */
    private _open;
    /** Timer ID for the WebRTC-to-WebSocket fallback timeout. */
    private _webrtcTimeoutId;
    constructor(remoteId: string, provider: Conduit, options?: AutoConnectionOptions);
    /** Whether the connection is currently open and ready for data. */
    get open(): boolean;
    /** The currently active transport type (WebRTC, WebSocket, or Auto during negotiation). */
    get transport(): TransportType;
    /** The underlying connection instance, or `null` before initialization. */
    get activeConnection(): DataConnection | WebSocketConnection | null;
    /**
     * Initialize the connection, trying WebRTC first then falling back to WebSocket
     */
    initialize(originator: boolean): Promise<void>;
    /** Start a WebRTC data connection without fallback. */
    private _initializeWebRTC;
    /** Start a WebRTC data connection with a timed fallback to WebSocket. */
    private _initializeWebRTCWithFallback;
    /** Start a WebSocket relay connection. */
    private _initializeWebSocket;
    /** Close the WebRTC attempt and switch to WebSocket relay. */
    private _fallbackToWebSocket;
    /** Forward events from a WebRTC DataConnection to this AutoConnection. */
    private _setupDataConnectionListeners;
    /** Forward events from a WebSocketConnection to this AutoConnection. */
    private _setupWebSocketListeners;
    /**
     * Handle incoming messages and route to the appropriate connection
     */
    handleMessage(message: ServerMessage): void;
    /**
     * Send data through the active connection
     */
    send(data: unknown): void;
    /**
     * Close the connection
     */
    close(): void;
}
//# sourceMappingURL=AutoConnection.d.ts.map