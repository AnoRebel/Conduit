/**
 * @module @conduit/client/msgpack
 *
 * MsgPack serialization adapter for Conduit.
 *
 * Usage:
 * ```typescript
 * import { Conduit, SerializationType } from '@conduit/client';
 * import '@conduit/client/msgpack'; // Register MsgPack serializer
 *
 * const conduit = new Conduit({
 *   serialization: SerializationType.MsgPack
 * });
 * ```
 */
import { decode, encode } from "@msgpack/msgpack";
/** Serializer registry entry shape used by the DataConnection serialization layer. */
interface Serializer {
    /** Encode arbitrary data to binary. */
    serialize: (data: unknown) => Uint8Array;
    /** Decode binary data back to a JavaScript value. */
    deserialize: (data: ArrayBuffer | Uint8Array) => unknown;
}
declare const serializer: Serializer;
export { decode, encode };
export default serializer;
//# sourceMappingURL=msgpack.d.ts.map