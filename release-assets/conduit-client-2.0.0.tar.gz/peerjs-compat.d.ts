/**
 * @module @conduit/client/peerjs-compat
 *
 * PeerJS Compatibility Layer.
 * Provides drop-in compatibility for projects migrating from PeerJS to Conduit.
 *
 * Usage:
 * Replace your PeerJS import:
 *   import { Peer } from 'peerjs';
 *
 * With:
 *   import { Peer } from '@conduit/client/peerjs-compat';
 *
 * Or simply update your import to use the new names:
 *   import { Conduit, ConduitError, ConduitErrorType } from '@conduit/client';
 */
export { ConduitErrorType as PeerErrorType, ConnectionType, MessageType, SerializationType, type ServerMessage, TransportType, } from "@conduit/shared";
export { type CallOptions, Conduit as Peer, type ConduitEvents as PeerEvents, type ConduitOptions as PeerOptions, type ConnectOptions, } from "./conduit.js";
export { ConduitError as PeerError } from "./conduitError.js";
export { AutoConnection, type AutoConnectionEvents, type AutoConnectionOptions, } from "./dataconnection/AutoConnection.js";
export { DataConnection, type DataConnectionEvents, type DataConnectionOptions, } from "./dataconnection/DataConnection.js";
export { WebSocketConnection, type WebSocketConnectionEvents, type WebSocketConnectionOptions, } from "./dataconnection/WebSocketConnection.js";
export { LogLevel, logger } from "./logger.js";
export { MediaConnection, type MediaConnectionEvents, type MediaConnectionOptions, } from "./mediaconnection.js";
export { type BrowserSupport, supports } from "./supports.js";
export { util } from "./util.js";
//# sourceMappingURL=peerjs-compat.d.ts.map