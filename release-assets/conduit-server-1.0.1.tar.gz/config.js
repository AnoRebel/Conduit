/** Default server configuration values. */
export const defaultConfig = {
    port: 9000,
    host: "0.0.0.0",
    path: "/",
    key: "conduit",
    auth: {
        mode: "key",
    },
    expireTimeout: 5000,
    aliveTimeout: 60000,
    concurrentLimit: 5000,
    allowDiscovery: false,
    cleanupOutMsgs: 1000,
    corsOrigin: true,
    allowedOrigins: undefined, // Allow all by default - set to array for whitelist
    proxied: false,
    requireSecure: false, // Set to true in production to enforce HTTPS/WSS
    relay: {
        enabled: true,
        maxMessageSize: 65536, // 64KB
    },
    rateLimit: {
        enabled: true,
        maxTokens: 100, // Burst capacity
        refillRate: 50, // Messages per second sustained
    },
    logging: {
        level: "info",
        pretty: false,
    },
};
/** Create a full {@link ServerConfig} by merging partial overrides with {@link defaultConfig}. */
export function createConfig(options = {}) {
    return {
        ...defaultConfig,
        ...options,
        auth: {
            ...defaultConfig.auth,
            ...options.auth,
        },
        relay: {
            ...defaultConfig.relay,
            ...options.relay,
        },
        rateLimit: {
            ...defaultConfig.rateLimit,
            ...options.rateLimit,
        },
        logging: {
            ...defaultConfig.logging,
            ...options.logging,
        },
    };
}
//# sourceMappingURL=config.js.map