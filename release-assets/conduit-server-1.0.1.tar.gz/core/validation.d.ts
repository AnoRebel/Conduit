/** Maximum allowed client ID length. */
export declare const MAX_ID_LENGTH = 64;
/** Maximum allowed connection token length. */
export declare const MAX_TOKEN_LENGTH = 64;
/** Maximum allowed API key length. */
export declare const MAX_KEY_LENGTH = 64;
/** Default maximum message size in bytes (64 KB). */
export declare const MAX_MESSAGE_SIZE: number;
/** Maximum allowed nesting depth for message payloads. */
export declare const MAX_PAYLOAD_DEPTH = 10;
/** Result of a validation check — `valid: true` or `valid: false` with an error message. */
export interface ValidationResult {
    /** Whether validation passed. */
    valid: boolean;
    /** Human-readable error message when `valid` is `false`. */
    error?: string;
}
/**
 * Validate a client ID
 */
export declare function validateId(id: unknown): ValidationResult;
/**
 * Validate a connection token
 */
export declare function validateToken(token: unknown): ValidationResult;
/**
 * Validate an API key
 */
export declare function validateKey(key: unknown): ValidationResult;
/**
 * Validate a message structure
 */
export declare function validateMessage(message: unknown, _maxSize?: number): ValidationResult;
/**
 * Validate message payload has required destination
 */
export declare function validatePayloadDestination(payload: unknown): ValidationResult;
/**
 * Safely parse JSON with size limits
 */
export declare function safeJsonParse(text: string, maxSize?: number): {
    success: true;
    data: unknown;
} | {
    success: false;
    error: string;
};
//# sourceMappingURL=validation.d.ts.map