import type { ServerConfig } from "../../config.js";
import type { IRealm } from "../realm.js";
export declare class MessagesExpire {
    private readonly realm;
    private readonly config;
    private _intervalId;
    constructor(realm: IRealm, config: ServerConfig);
    start(): void;
    stop(): void;
    pruneExpiredMessages(): void;
}
//# sourceMappingURL=messagesExpire.d.ts.map