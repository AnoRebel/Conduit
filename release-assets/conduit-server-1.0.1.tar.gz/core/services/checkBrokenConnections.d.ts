import type { ServerConfig } from "../../config.js";
import type { IRealm } from "../realm.js";
export interface CheckBrokenConnectionsOptions {
    onClose?: (clientId: string) => void;
}
export declare class CheckBrokenConnections {
    private readonly realm;
    private readonly config;
    private readonly options;
    private _intervalId;
    constructor(realm: IRealm, config: ServerConfig, options?: CheckBrokenConnectionsOptions);
    start(): void;
    stop(): void;
    checkConnections(): void;
}
//# sourceMappingURL=checkBrokenConnections.d.ts.map