export class CheckBrokenConnections {
    realm;
    config;
    options;
    _intervalId = null;
    constructor(realm, config, options = {}) {
        this.realm = realm;
        this.config = config;
        this.options = options;
    }
    start() {
        if (this._intervalId) {
            return;
        }
        this._intervalId = setInterval(() => {
            this.checkConnections();
        }, this.config.aliveTimeout);
    }
    stop() {
        if (this._intervalId) {
            clearInterval(this._intervalId);
            this._intervalId = null;
        }
    }
    checkConnections() {
        const now = Date.now();
        const clientIds = this.realm.getClientIds();
        for (const clientId of clientIds) {
            const client = this.realm.getClient(clientId);
            if (!client) {
                continue;
            }
            const timeSinceLastPing = now - client.lastPing;
            if (timeSinceLastPing > this.config.aliveTimeout) {
                // Client has not sent a heartbeat in too long
                const socket = client.socket;
                if (socket) {
                    try {
                        socket.close();
                    }
                    catch {
                        // Ignore close errors
                    }
                }
                this.realm.removeClient(clientId);
                this.options.onClose?.(clientId);
            }
        }
    }
}
//# sourceMappingURL=checkBrokenConnections.js.map