/**
 * Token bucket rate limiter for per-client message limiting
 */
export interface RateLimiterConfig {
    /** Maximum tokens (burst capacity) */
    maxTokens: number;
    /** Tokens added per second */
    refillRate: number;
}
export interface IRateLimiter {
    /** Try to consume a token. Returns true if allowed, false if rate limited */
    tryConsume(clientId: string): boolean;
    /** Remove a client from the rate limiter */
    removeClient(clientId: string): void;
    /** Clear all clients */
    clear(): void;
}
export declare class RateLimiter implements IRateLimiter {
    private readonly _buckets;
    private readonly _maxTokens;
    private readonly _refillRate;
    constructor(config: RateLimiterConfig);
    tryConsume(clientId: string): boolean;
    removeClient(clientId: string): void;
    clear(): void;
}
export declare const DEFAULT_RATE_LIMIT_CONFIG: RateLimiterConfig;
//# sourceMappingURL=rateLimiter.d.ts.map