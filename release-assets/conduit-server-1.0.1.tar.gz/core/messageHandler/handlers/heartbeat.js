export function handleHeartbeat(client) {
    client.updateLastPing();
}
//# sourceMappingURL=heartbeat.js.map