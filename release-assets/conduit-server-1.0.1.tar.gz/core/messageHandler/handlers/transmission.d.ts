import { type IMessage } from "@conduit/shared";
import type { IClient } from "../../client.js";
import type { IRealm } from "../../realm.js";
export interface TransmissionPayload {
    type?: string;
    connectionId?: string;
    sdp?: unknown;
    candidate?: unknown;
    label?: string;
    metadata?: unknown;
    serialization?: string;
    reliable?: boolean;
}
export declare function handleTransmission(client: IClient, message: IMessage, realm: IRealm): void;
export declare function handleOffer(client: IClient, message: IMessage, realm: IRealm): void;
export declare function handleAnswer(client: IClient, message: IMessage, realm: IRealm): void;
export declare function handleCandidate(client: IClient, message: IMessage, realm: IRealm): void;
export declare function handleLeave(client: IClient, message: IMessage, realm: IRealm): void;
//# sourceMappingURL=transmission.d.ts.map