import { type IMessage } from "@conduit/shared";
import type { ServerConfig } from "../../../config.js";
import type { IClient } from "../../client.js";
import type { IRealm } from "../../realm.js";
export interface RelayPayload {
    connectionId?: string;
    data?: unknown;
    label?: string;
    metadata?: unknown;
}
/**
 * Handle WebSocket relay messages for fallback transport
 */
export declare function handleRelay(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig): void;
/**
 * Handle relay connection open
 */
export declare function handleRelayOpen(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig): void;
/**
 * Handle relay connection close
 */
export declare function handleRelayClose(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig): void;
//# sourceMappingURL=relay.d.ts.map