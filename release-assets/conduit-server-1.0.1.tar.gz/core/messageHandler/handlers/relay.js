import { MessageType } from "@conduit/shared";
/**
 * Handle WebSocket relay messages for fallback transport
 */
export function handleRelay(client, message, realm, config) {
    if (!config.relay.enabled) {
        return;
    }
    const { dst, payload } = message;
    if (!dst) {
        return;
    }
    const relayPayload = payload;
    // Check message size limit
    if (relayPayload?.data) {
        const dataSize = JSON.stringify(relayPayload.data).length;
        if (dataSize > config.relay.maxMessageSize) {
            client.send({
                type: MessageType.ERROR,
                payload: { msg: `Relay message size exceeds limit (${config.relay.maxMessageSize} bytes)` },
            });
            return;
        }
    }
    const destinationClient = realm.getClient(dst);
    if (destinationClient) {
        const relayMessage = {
            type: MessageType.RELAY,
            src: client.id,
            dst,
            payload: relayPayload,
        };
        destinationClient.send(relayMessage);
    }
    else {
        // Destination not found
        client.send({
            type: MessageType.ERROR,
            payload: { msg: `Relay target peer ${dst} not found` },
        });
    }
}
/**
 * Handle relay connection open
 */
export function handleRelayOpen(client, message, realm, config) {
    if (!config.relay.enabled) {
        return;
    }
    const { dst, payload } = message;
    if (!dst) {
        return;
    }
    const destinationClient = realm.getClient(dst);
    if (destinationClient) {
        // Notify destination about incoming relay connection
        const openMessage = {
            type: MessageType.RELAY_OPEN,
            src: client.id,
            dst,
            payload,
        };
        destinationClient.send(openMessage);
        // Notify sender that relay is ready
        client.send({
            type: MessageType.RELAY_OPEN,
            src: dst,
            dst: client.id,
            payload,
        });
    }
    else {
        // Destination not found
        client.send({
            type: MessageType.ERROR,
            payload: { msg: `Relay target peer ${dst} not found` },
        });
    }
}
/**
 * Handle relay connection close
 */
export function handleRelayClose(client, message, realm, config) {
    if (!config.relay.enabled) {
        return;
    }
    const { dst, payload } = message;
    if (!dst) {
        return;
    }
    const destinationClient = realm.getClient(dst);
    if (destinationClient) {
        const closeMessage = {
            type: MessageType.RELAY_CLOSE,
            src: client.id,
            dst,
            payload,
        };
        destinationClient.send(closeMessage);
    }
}
//# sourceMappingURL=relay.js.map