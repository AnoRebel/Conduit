import type { IClient } from "../../client.js";
export declare function handleHeartbeat(client: IClient): void;
//# sourceMappingURL=heartbeat.d.ts.map