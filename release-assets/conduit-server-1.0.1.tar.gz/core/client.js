/** Default {@link IClient} implementation backed by a WebSocket. */
export class Client {
    id;
    token;
    _socket = null;
    _lastPing = Date.now();
    constructor(id, token) {
        this.id = id;
        this.token = token;
    }
    get socket() {
        return this._socket;
    }
    get lastPing() {
        return this._lastPing;
    }
    setSocket(socket) {
        this._socket = socket;
    }
    send(message) {
        if (!this._socket || this._socket.readyState !== 1) {
            return false;
        }
        try {
            this._socket.send(JSON.stringify(message));
            return true;
        }
        catch {
            return false;
        }
    }
    updateLastPing() {
        this._lastPing = Date.now();
    }
}
//# sourceMappingURL=client.js.map