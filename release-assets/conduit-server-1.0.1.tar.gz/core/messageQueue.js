/** In-memory implementation of {@link IMessageQueue}. */
export class MessageQueue {
    _queues = new Map();
    _lastReadAt = new Map();
    getMessages(id) {
        const queue = this._queues.get(id);
        if (!queue) {
            return [];
        }
        // Return and clear messages
        const messages = [...queue];
        this._queues.delete(id);
        this._lastReadAt.set(id, Date.now());
        return messages;
    }
    addMessage(id, message) {
        let queue = this._queues.get(id);
        if (!queue) {
            queue = [];
            this._queues.set(id, queue);
        }
        queue.push(message);
    }
    clearMessages(id) {
        this._queues.delete(id);
        this._lastReadAt.delete(id);
    }
    getLastReadAt(id) {
        return this._lastReadAt.get(id) || 0;
    }
}
//# sourceMappingURL=messageQueue.js.map