export class RateLimiter {
    _buckets = new Map();
    _maxTokens;
    _refillRate;
    constructor(config) {
        this._maxTokens = config.maxTokens;
        this._refillRate = config.refillRate;
    }
    tryConsume(clientId) {
        const now = Date.now();
        let bucket = this._buckets.get(clientId);
        if (!bucket) {
            // New client starts with full bucket
            bucket = {
                tokens: this._maxTokens,
                lastRefill: now,
            };
            this._buckets.set(clientId, bucket);
        }
        // Refill tokens based on time elapsed
        const elapsed = (now - bucket.lastRefill) / 1000; // Convert to seconds
        const refill = elapsed * this._refillRate;
        bucket.tokens = Math.min(this._maxTokens, bucket.tokens + refill);
        bucket.lastRefill = now;
        // Try to consume a token
        if (bucket.tokens >= 1) {
            bucket.tokens -= 1;
            return true;
        }
        return false;
    }
    removeClient(clientId) {
        this._buckets.delete(clientId);
    }
    clear() {
        this._buckets.clear();
    }
}
// Default rate limit: 100 messages per second burst, 50 messages per second sustained
export const DEFAULT_RATE_LIMIT_CONFIG = {
    maxTokens: 100,
    refillRate: 50,
};
//# sourceMappingURL=rateLimiter.js.map