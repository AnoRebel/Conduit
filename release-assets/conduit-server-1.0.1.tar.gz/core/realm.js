import { randomBytes } from "node:crypto";
import { MessageQueue } from "./messageQueue.js";
/** In-memory implementation of {@link IRealm}. */
export class Realm {
    _clients = new Map();
    _messageQueue = new MessageQueue();
    getClient(id) {
        return this._clients.get(id);
    }
    getClientIds() {
        return Array.from(this._clients.keys());
    }
    setClient(client) {
        this._clients.set(client.id, client);
    }
    removeClient(id) {
        const client = this._clients.get(id);
        if (client) {
            this._clients.delete(id);
        }
        return client;
    }
    getMessageQueue() {
        return this._messageQueue;
    }
    generateClientId() {
        let id;
        do {
            id = this._randomId();
        } while (this._clients.has(id));
        return id;
    }
    clientExists(id) {
        return this._clients.has(id);
    }
    _randomId() {
        // Use cryptographically secure random bytes
        return randomBytes(12).toString("base64url");
    }
}
//# sourceMappingURL=realm.js.map