/**
 * @module @conduit/server/adapters/express
 *
 * Express middleware adapter for Conduit Server.
 *
 * ```typescript
 * import express from 'express';
 * import { ExpressConduitServer } from '@conduit/server/adapters/express';
 *
 * const app = express();
 * const server = app.listen(9000);
 * const conduitServer = ExpressConduitServer(server, { path: '/conduit' });
 *
 * app.use('/conduit', conduitServer);
 * ```
 */
import type { Server } from "node:http";
import { type CreateConduitServerCoreOptions } from "../core/index.js";
interface Request {
    url?: string;
    method?: string;
}
interface Response {
    setHeader(name: string, value: string): void;
    writeHead(statusCode: number, headers?: Record<string, string>): void;
    json(data: unknown): void;
    send(data: string): void;
    status(code: number): Response;
    end(data?: string): void;
}
type NextFunction = () => void;
type ExpressMiddleware = (req: Request, res: Response, next: NextFunction) => void;
export interface ExpressAdapterOptions extends CreateConduitServerCoreOptions {
}
export interface ExpressConduitInstance extends ExpressMiddleware {
    close: () => void;
}
export declare function ExpressConduitServer(server: Server, options?: ExpressAdapterOptions): ExpressMiddleware;
export default ExpressConduitServer;
//# sourceMappingURL=express.d.ts.map