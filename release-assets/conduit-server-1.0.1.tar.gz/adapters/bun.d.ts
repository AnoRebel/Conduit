/**
 * @module @conduit/server/adapters/bun
 *
 * Bun.serve adapter for Conduit Server.
 *
 * ```typescript
 * import { createConduitServer } from '@conduit/server/adapters/bun';
 *
 * const server = createConduitServer({ config: { port: 9000 } });
 * ```
 */
import { type ConduitServerCore, type CreateConduitServerCoreOptions, type IClient } from "../core/index.js";
interface BunWebSocket<T = unknown> {
    readonly data: T;
    readonly readyState: number;
    send(data: string | ArrayBuffer | Uint8Array): void;
    close(code?: number, reason?: string): void;
}
interface BunServer {
    readonly port: number;
    readonly hostname: string;
    stop(closeActiveConnections?: boolean): void;
}
export interface BunAdapterOptions extends CreateConduitServerCoreOptions {
}
export interface BunConduitServer {
    readonly core: ConduitServerCore;
    serve(): BunServer;
    getServeOptions(): BunServeOptions;
    close(): void;
}
interface BunServeOptions {
    port: number;
    hostname: string;
    fetch: (request: Request, server: BunServer) => Response | Promise<Response>;
    websocket: {
        open: (ws: BunWebSocket<WebSocketData>) => void;
        message: (ws: BunWebSocket<WebSocketData>, message: string | ArrayBuffer) => void;
        close: (ws: BunWebSocket<WebSocketData>) => void;
    };
}
interface WebSocketData {
    client?: IClient;
    id: string;
    token: string;
    key: string;
}
export declare function createConduitServer(options?: BunAdapterOptions): BunConduitServer;
export default createConduitServer;
//# sourceMappingURL=bun.d.ts.map