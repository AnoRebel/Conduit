/**
 * @module @conduit/server/adapters/node
 *
 * Node.js HTTP adapter for Conduit Server. Creates a standalone HTTP + WebSocket
 * server using the `ws` library.
 *
 * @example
 * ```typescript
 * import { createConduitServer } from '@conduit/server/adapters/node';
 *
 * const server = createConduitServer({ config: { port: 9000 } });
 * server.listen();
 * ```
 */
import { type Server } from "node:http";
import { WebSocketServer } from "ws";
import { type ConduitServerCore, type CreateConduitServerCoreOptions } from "../core/index.js";
import type { ILogger } from "../logger.js";
export interface NodeAdapterOptions extends CreateConduitServerCoreOptions {
    server?: Server;
}
export interface ConduitServer {
    readonly server: Server;
    readonly wss: WebSocketServer;
    readonly core: ConduitServerCore;
    readonly logger: ILogger;
    listen(port?: number, host?: string, callback?: () => void): void;
    close(callback?: (err?: Error) => void): void;
}
export declare function createConduitServer(options?: NodeAdapterOptions): ConduitServer;
export default createConduitServer;
//# sourceMappingURL=node.d.ts.map