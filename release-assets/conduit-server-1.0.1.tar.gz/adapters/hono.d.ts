/**
 * @module @conduit/server/adapters/hono
 *
 * Hono middleware adapter for Conduit Server.
 *
 * ```typescript
 * import { Hono } from 'hono';
 * import { createConduitMiddleware } from '@conduit/server/adapters/hono';
 *
 * const app = new Hono();
 * const { middleware, upgradeWebSocket } = createConduitMiddleware();
 *
 * app.use('/conduit/*', middleware);
 * app.get('/conduit/ws', upgradeWebSocket);
 * ```
 */
import { type ConduitServerCore, type CreateConduitServerCoreOptions } from "../core/index.js";
interface HonoContext {
    req: {
        url: string;
        method: string;
        query: (key: string) => string | undefined;
        header: (key: string) => string | undefined;
    };
    json: (data: unknown, status?: number) => Response;
    text: (data: string, status?: number) => Response;
    header: (key: string, value: string) => void;
}
type HonoMiddleware = (c: HonoContext, next: () => Promise<void>) => Promise<Response | void>;
export interface HonoAdapterOptions extends CreateConduitServerCoreOptions {
}
export interface HonoConduitServer {
    readonly core: ConduitServerCore;
    readonly middleware: HonoMiddleware;
    getRoutes(): {
        path: string;
        method: string;
        handler: (c: HonoContext) => Response | Promise<Response>;
    }[];
    destroy(): void;
}
export declare function createConduitMiddleware(options?: HonoAdapterOptions): HonoConduitServer;
export default createConduitMiddleware;
//# sourceMappingURL=hono.d.ts.map