/**
 * @module @conduit/server/adapters/express
 *
 * Express middleware adapter for Conduit Server.
 *
 * ```typescript
 * import express from 'express';
 * import { ExpressConduitServer } from '@conduit/server/adapters/express';
 *
 * const app = express();
 * const server = app.listen(9000);
 * const conduitServer = ExpressConduitServer(server, { path: '/conduit' });
 *
 * app.use('/conduit', conduitServer);
 * ```
 */
import { parse as parseUrl } from "node:url";
import { MessageType, VERSION } from "@conduit/shared";
import { WebSocketServer } from "ws";
import { createConduitServerCore } from "../core/index.js";
// Helper to check if request is secure
function isSecureRequest(req) {
    const forwardedProto = req.headers["x-forwarded-proto"];
    if (forwardedProto === "https")
        return true;
    const socket = req.socket;
    if (socket.encrypted)
        return true;
    return false;
}
export function ExpressConduitServer(server, options = {}) {
    const core = createConduitServerCore(options);
    const config = core.config;
    const wss = new WebSocketServer({ noServer: true });
    core.start();
    // WebSocket upgrade handler
    server.on("upgrade", (request, socket, head) => {
        const url = parseUrl(request.url || "", true);
        const pathname = url.pathname || "";
        // Check if this is a Conduit WebSocket request
        const basePath = config.path.endsWith("/") ? config.path.slice(0, -1) : config.path;
        if (pathname !== `${basePath}/conduit`) {
            return;
        }
        // HTTPS/WSS enforcement check
        if (config.requireSecure && !isSecureRequest(request)) {
            socket.write("HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain\r\n\r\nWSS required");
            socket.destroy();
            return;
        }
        // Validate origin if allowedOrigins is configured
        if (config.allowedOrigins && config.allowedOrigins.length > 0) {
            const origin = request.headers.origin;
            if (!origin || !config.allowedOrigins.includes(origin)) {
                socket.write("HTTP/1.1 403 Forbidden\r\n\r\n");
                socket.destroy();
                return;
            }
        }
        const { key, id, token } = url.query;
        // key is required when auth mode is "key", optional when "none"
        if ((!key && config.auth.mode === "key") || !id || !token) {
            socket.destroy();
            return;
        }
        wss.handleUpgrade(request, socket, head, (ws) => {
            const client = core.handleConnection(ws, id, token, key || config.key);
            if (!client) {
                return;
            }
            ws.on("message", data => {
                core.handleMessage(client, data);
            });
            ws.on("close", () => {
                core.handleDisconnect(client);
            });
            ws.on("error", () => {
                core.handleDisconnect(client);
            });
        });
    });
    // Express middleware
    const middleware = (req, res, next) => {
        const url = parseUrl(req.url || "", true);
        const pathname = url.pathname || "";
        // HTTPS enforcement check
        if (config.requireSecure) {
            // In Express, check x-forwarded-proto header
            const proto = req.headers
                ? req.headers["x-forwarded-proto"]
                : undefined;
            if (proto !== "https") {
                res.status(403).json({ error: "HTTPS required" });
                return;
            }
        }
        // Set CORS headers
        setCorsHeaders(res, config);
        // Handle preflight
        if (req.method === "OPTIONS") {
            res.writeHead(200);
            res.end();
            return;
        }
        // Whether auth-less routes are available
        const noAuth = config.auth.mode === "none";
        // Route requests
        if (pathname === "/" || pathname === "") {
            res.json({ name: "Conduit Server", version: VERSION });
            return;
        }
        if (pathname === `/${config.key}/id` || (noAuth && pathname === "/id")) {
            res.send(core.generateClientId());
            return;
        }
        if (pathname === `/${config.key}/conduits` || (noAuth && pathname === "/conduits")) {
            if (config.allowDiscovery) {
                res.json(core.realm.getClientIds());
            }
            else {
                res.status(401).json({ error: "Conduit discovery is disabled" });
            }
            return;
        }
        next();
    };
    // Attach cleanup method
    middleware.close = () => {
        // Send GOAWAY message to all clients before closing
        const goawayMessage = JSON.stringify({
            type: MessageType.GOAWAY,
            payload: { msg: "Server is shutting down" },
        });
        for (const client of wss.clients) {
            try {
                client.send(goawayMessage);
            }
            catch {
                // Ignore send errors during shutdown
            }
        }
        // Give clients a moment to receive the message before closing
        setTimeout(() => {
            core.stop();
            for (const client of wss.clients) {
                client.close(1001, "Server shutdown");
            }
            wss.close();
        }, 100);
    };
    return middleware;
}
function setCorsHeaders(res, config) {
    if (config.corsOrigin === false) {
        return;
    }
    if (config.corsOrigin === true) {
        res.setHeader("Access-Control-Allow-Origin", "*");
    }
    else if (typeof config.corsOrigin === "string") {
        res.setHeader("Access-Control-Allow-Origin", config.corsOrigin);
    }
    else if (Array.isArray(config.corsOrigin)) {
        res.setHeader("Access-Control-Allow-Origin", config.corsOrigin.join(", "));
    }
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}
export default ExpressConduitServer;
//# sourceMappingURL=express.js.map