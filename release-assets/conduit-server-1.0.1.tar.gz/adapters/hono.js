/**
 * @module @conduit/server/adapters/hono
 *
 * Hono middleware adapter for Conduit Server.
 *
 * ```typescript
 * import { Hono } from 'hono';
 * import { createConduitMiddleware } from '@conduit/server/adapters/hono';
 *
 * const app = new Hono();
 * const { middleware, upgradeWebSocket } = createConduitMiddleware();
 *
 * app.use('/conduit/*', middleware);
 * app.get('/conduit/ws', upgradeWebSocket);
 * ```
 */
import { VERSION } from "@conduit/shared";
import { createConduitServerCore, } from "../core/index.js";
export function createConduitMiddleware(options = {}) {
    const core = createConduitServerCore(options);
    const config = core.config;
    core.start();
    const middleware = async (c, next) => {
        const url = new URL(c.req.url);
        const pathname = url.pathname;
        // HTTPS enforcement check
        if (config.requireSecure) {
            const proto = c.req.header("x-forwarded-proto");
            const isSecure = proto === "https" || url.protocol === "https:";
            if (!isSecure) {
                return c.json({ error: "HTTPS required" }, 403);
            }
        }
        // Set CORS headers
        setCorsHeaders(c, config);
        // Handle preflight
        if (c.req.method === "OPTIONS") {
            return c.text("", 200);
        }
        // Whether auth-less routes are available
        const noAuth = config.auth.mode === "none";
        // Route requests
        const basePath = config.path.endsWith("/") ? config.path.slice(0, -1) : config.path;
        if (pathname === basePath || pathname === `${basePath}/`) {
            return c.json({ name: "Conduit Server", version: VERSION });
        }
        if (pathname === `${basePath}/${config.key}/id` || (noAuth && pathname === `${basePath}/id`)) {
            return c.text(core.generateClientId());
        }
        if (pathname === `${basePath}/${config.key}/conduits` ||
            (noAuth && pathname === `${basePath}/conduits`)) {
            if (config.allowDiscovery) {
                return c.json(core.realm.getClientIds());
            }
            return c.json({ error: "Conduit discovery is disabled" }, 401);
        }
        return next();
    };
    function getRoutes() {
        const basePath = config.path.endsWith("/") ? config.path.slice(0, -1) : config.path;
        const noAuth = config.auth.mode === "none";
        const routes = [
            {
                path: basePath,
                method: "GET",
                handler: (c) => c.json({ name: "Conduit Server", version: VERSION }),
            },
            {
                path: `${basePath}/${config.key}/id`,
                method: "GET",
                handler: (c) => c.text(core.generateClientId()),
            },
            {
                path: `${basePath}/${config.key}/conduits`,
                method: "GET",
                handler: (c) => {
                    if (config.allowDiscovery) {
                        return c.json(core.realm.getClientIds());
                    }
                    return c.json({ error: "Conduit discovery is disabled" }, 401);
                },
            },
        ];
        // When auth mode is "none", also expose routes without key prefix
        if (noAuth) {
            routes.push({
                path: `${basePath}/id`,
                method: "GET",
                handler: (c) => c.text(core.generateClientId()),
            }, {
                path: `${basePath}/conduits`,
                method: "GET",
                handler: (c) => {
                    if (config.allowDiscovery) {
                        return c.json(core.realm.getClientIds());
                    }
                    return c.json({ error: "Conduit discovery is disabled" }, 401);
                },
            });
        }
        return routes;
    }
    function destroy() {
        core.stop();
    }
    return {
        core,
        middleware,
        getRoutes,
        destroy,
    };
}
function setCorsHeaders(c, config) {
    if (config.corsOrigin === false) {
        return;
    }
    if (config.corsOrigin === true) {
        c.header("Access-Control-Allow-Origin", "*");
    }
    else if (typeof config.corsOrigin === "string") {
        c.header("Access-Control-Allow-Origin", config.corsOrigin);
    }
    else if (Array.isArray(config.corsOrigin)) {
        c.header("Access-Control-Allow-Origin", config.corsOrigin.join(", "));
    }
    c.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    c.header("Access-Control-Allow-Headers", "Content-Type");
}
export default createConduitMiddleware;
//# sourceMappingURL=hono.js.map