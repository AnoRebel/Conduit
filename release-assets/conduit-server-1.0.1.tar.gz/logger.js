import pino, {} from "pino";
const defaultConfig = {
    level: "info",
    pretty: false,
    timestamp: true,
};
let loggerInstance = null;
/**
 * Create or get the logger instance
 */
export function createLogger(config = {}) {
    const mergedConfig = { ...defaultConfig, ...config };
    const options = {
        level: mergedConfig.level || "info",
        ...(mergedConfig.timestamp && {
            timestamp: pino.stdTimeFunctions.isoTime,
        }),
        ...mergedConfig.pinoOptions,
    };
    // Use pino-pretty for development if pretty is enabled
    if (mergedConfig.pretty) {
        options.transport = {
            target: "pino-pretty",
            options: {
                colorize: true,
                translateTime: "SYS:standard",
                ignore: "pid,hostname",
            },
        };
    }
    loggerInstance = pino(options);
    return loggerInstance;
}
/**
 * Get the current logger instance or create a default one
 */
export function getLogger() {
    if (!loggerInstance) {
        loggerInstance = createLogger();
    }
    return loggerInstance;
}
/**
 * Create a child logger with additional context
 */
export function createChildLogger(bindings) {
    return getLogger().child(bindings);
}
/**
 * Wrap pino logger to match ILogger interface
 */
export function wrapLogger(pinoLogger) {
    return {
        fatal: (msg, ...args) => pinoLogger.fatal(args.length ? { data: args } : {}, msg),
        error: (msg, ...args) => pinoLogger.error(args.length ? { data: args } : {}, msg),
        warn: (msg, ...args) => pinoLogger.warn(args.length ? { data: args } : {}, msg),
        info: (msg, ...args) => pinoLogger.info(args.length ? { data: args } : {}, msg),
        debug: (msg, ...args) => pinoLogger.debug(args.length ? { data: args } : {}, msg),
        trace: (msg, ...args) => pinoLogger.trace(args.length ? { data: args } : {}, msg),
        child: bindings => wrapLogger(pinoLogger.child(bindings)),
    };
}
/** Convenience namespace bundling all logger factory functions. */
export const logger = {
    create: createLogger,
    get: getLogger,
    child: createChildLogger,
    wrap: wrapLogger,
};
export default logger;
//# sourceMappingURL=logger.js.map