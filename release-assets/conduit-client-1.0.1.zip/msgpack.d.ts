import { decode } from '@msgpack/msgpack';
import { encode } from '@msgpack/msgpack';

export { decode }

export { encode }

declare interface Serializer {
    serialize: (data: unknown) => Uint8Array;
    deserialize: (data: ArrayBuffer | Uint8Array) => unknown;
}

declare const serializer: Serializer;
export default serializer;

export { }
