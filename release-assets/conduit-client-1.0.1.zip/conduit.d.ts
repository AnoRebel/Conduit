import { ConduitErrorType } from '@conduit/shared';
import { ConnectionType } from '@conduit/shared';
import { EventEmitter } from 'eventemitter3';
import { MessageType } from '@conduit/shared';
import { SerializationType } from '@conduit/shared';
import { ServerMessage } from '@conduit/shared';
import { TransportType } from '@conduit/shared';

/**
 * AutoConnection automatically selects the best transport:
 * 1. Tries WebRTC first (if supported)
 * 2. Falls back to WebSocket relay if WebRTC fails or times out
 */
declare class AutoConnection extends EventEmitter<AutoConnectionEvents> {
    readonly type = ConnectionType.Data;
    readonly remote: string;
    readonly provider: Conduit;
    readonly connectionId: string;
    readonly label: string;
    readonly metadata: unknown;
    readonly options: AutoConnectionOptions;
    private _activeConnection;
    private _transport;
    private _open;
    private _webrtcTimeoutId;
    constructor(remoteId: string, provider: Conduit, options?: AutoConnectionOptions);
    get open(): boolean;
    get transport(): TransportType;
    get activeConnection(): DataConnection | WebSocketConnection | null;
    /**
     * Initialize the connection, trying WebRTC first then falling back to WebSocket
     */
    initialize(originator: boolean): Promise<void>;
    private _initializeWebRTC;
    private _initializeWebRTCWithFallback;
    private _initializeWebSocket;
    private _fallbackToWebSocket;
    private _setupDataConnectionListeners;
    private _setupWebSocketListeners;
    /**
     * Handle incoming messages and route to the appropriate connection
     */
    handleMessage(message: ServerMessage): void;
    /**
     * Send data through the active connection
     */
    send(data: unknown): void;
    /**
     * Close the connection
     */
    close(): void;
}

/** Events emitted by an {@link AutoConnection}. */
declare interface AutoConnectionEvents {
    /** Fired when the connection is open and ready. */
    open: () => void;
    /** Fired when data is received from the remote peer. */
    data: (data: unknown) => void;
    /** Fired when the connection is closed. */
    close: () => void;
    /** Fired when an error occurs. */
    error: (error: Error) => void;
    /** Fired when the transport is changed (e.g. WebRTC → WebSocket fallback). */
    transportChanged: (transport: TransportType) => void;
}

/** Options for creating an {@link AutoConnection}. */
declare interface AutoConnectionOptions extends DataConnectionOptions, WebSocketConnectionOptions {
    /** Preferred transport; set to force a specific one instead of auto-selecting. */
    preferredTransport?: TransportType;
    /** Timeout in ms before falling back from WebRTC to WebSocket (default: 10 000). */
    webrtcTimeout?: number;
}

/** Common options shared by all connection types. */
declare interface BaseConnectionOptions {
    /** Unique identifier for this connection. Auto-generated if omitted. */
    connectionId?: string;
    /** Human-readable label for the connection. */
    label?: string;
    /** Arbitrary metadata attached to the connection. */
    metadata?: unknown;
    /** Whether the underlying channel guarantees ordered, reliable delivery. */
    reliable?: boolean;
    /** Serialization format for the connection. */
    serialization?: string;
}

/** Options for initiating a media call to a remote peer via {@link Conduit.call}. */
export declare interface CallOptions {
    /** Arbitrary metadata to associate with the call. */
    metadata?: unknown;
    /** Optional transform applied to the SDP before sending the offer. */
    sdpTransform?: (sdp: string) => string;
}

/**
 * The main Conduit peer client.
 *
 * Creates a connection to the signaling server and provides methods to connect
 * to remote peers for data exchange and media calls.
 *
 * @example
 * ```typescript
 * const peer = new Conduit('my-id', { host: 'localhost', port: 9000 });
 * peer.on('open', (id) => {
 *   const conn = peer.connect('remote-id');
 *   conn.on('open', () => conn.send('hello'));
 * });
 * ```
 */
export declare class Conduit extends EventEmitter<ConduitEvents> {
    private _id;
    private _lastServerId;
    private _destroyed;
    private _disconnected;
    private _open;
    private _connections;
    private _lostMessages;
    readonly options: ConduitOptions;
    readonly socket: Socket;
    private readonly _api;
    constructor(options?: ConduitOptions);
    constructor(id: string, options?: ConduitOptions);
    get id(): string | null;
    get open(): boolean;
    get destroyed(): boolean;
    get disconnected(): boolean;
    get connections(): Map<string, Array<DataConnection | AutoConnection | WebSocketConnection | MediaConnection>>;
    private _retrieveId;
    private _initialize;
    private _setupSocketListeners;
    private _handleMessage;
    private _handleOffer;
    private _handleConnectionMessage;
    private _storeLostMessage;
    private _deliverLostMessages;
    private _addConnection;
    private _cleanupRemote;
    /**
     * Connect to a remote conduit with a data connection
     */
    connect(remoteId: string, options?: ConnectOptions): DataConnection | AutoConnection | WebSocketConnection;
    /**
     * Call a remote conduit with a media stream
     */
    call(remoteId: string, stream: MediaStream, options?: CallOptions): MediaConnection;
    /**
     * Disconnect from the signaling server
     */
    disconnect(): void;
    /**
     * Reconnect to the signaling server
     */
    reconnect(): void;
    /**
     * Destroy the conduit and close all connections
     */
    destroy(): void;
    /**
     * Get a list of all connected conduits (discovery)
     */
    listAllConduits(): Promise<string[]>;
    private _abort;
    private _emitError;
}

/**
 * Custom error class for Conduit-specific errors.
 * Extends the standard `Error` with a typed `type` field
 * from {@link ConduitErrorType}.
 */
declare class ConduitError extends Error {
    /** The specific Conduit error type. */
    readonly type: ConduitErrorType;
    constructor(
    /** The specific Conduit error type. */
    type: ConduitErrorType, message: string);
}

/** Events emitted by the {@link Conduit} peer instance. */
export declare interface ConduitEvents {
    /** Fired when the connection to the signaling server is established and an ID is obtained. */
    open: (id: string) => void;
    /** Fired when a new incoming data connection is received from a remote peer. */
    connection: (connection: DataConnection | AutoConnection | WebSocketConnection) => void;
    /** Fired when an incoming media call is received from a remote peer. */
    call: (mediaConnection: MediaConnection) => void;
    /** Fired when the peer is destroyed and can no longer accept or create connections. */
    close: () => void;
    /** Fired when the peer is disconnected from the signaling server (can reconnect). */
    disconnected: () => void;
    /** Fired when a fatal error occurs. */
    error: (error: ConduitError) => void;
}

/** Configuration options for creating a {@link Conduit} peer instance. */
export declare interface ConduitOptions {
    /** API key for the signaling server (default: `"conduit"`). */
    key?: string;
    /** Signaling server hostname. */
    host?: string;
    /** Signaling server port. */
    port?: number;
    /** Signaling server path prefix (default: `"/"`). */
    path?: string;
    /** Whether to use a secure (TLS) connection to the signaling server. */
    secure?: boolean;
    /** Authentication token for the signaling server. */
    token?: string;
    /** Custom RTCPeerConnection configuration (ICE servers, etc.). */
    config?: RTCConfiguration;
    /** Logging verbosity level. */
    debug?: LogLevel;
    /** Referrer policy for HTTP requests to the signaling server. */
    referrerPolicy?: ReferrerPolicy;
    /** Preferred transport type for data connections. */
    transport?: TransportType;
    /** Default serialization format for data connections. */
    serialization?: SerializationType;
}

/** Options for establishing a data connection to a remote peer via {@link Conduit.connect}. */
export declare interface ConnectOptions {
    /** A human-readable label for the connection. */
    label?: string;
    /** Arbitrary metadata to associate with the connection. */
    metadata?: unknown;
    /** Serialization format for data sent over this connection. */
    serialization?: SerializationType;
    /** Whether the data channel should guarantee ordered, reliable delivery. */
    reliable?: boolean;
    /** Transport type override for this specific connection. */
    transport?: TransportType;
    /** Timeout in ms before falling back from WebRTC to WebSocket (default: 10 000). */
    webrtcTimeout?: number;
}

/**
 * A WebRTC data channel connection to a remote peer.
 * Supports binary, JSON, and raw serialization modes.
 */
declare class DataConnection extends EventEmitter<DataConnectionEvents> implements NegotiableConnection {
    readonly type = ConnectionType.Data;
    readonly remote: string;
    readonly provider: Conduit;
    readonly connectionId: string;
    readonly label: string;
    readonly metadata: unknown;
    readonly serialization: SerializationType;
    readonly reliable: boolean;
    readonly options: DataConnectionOptions;
    protected _open: boolean;
    protected _peerConnection: RTCPeerConnection | null;
    private _dataChannel;
    private _negotiator;
    private _buffer;
    private _bufferSize;
    private _maxBufferSize;
    private _chunkedData;
    constructor(remoteId: string, provider: Conduit, options?: DataConnectionOptions);
    /**
     * Set the RTCPeerConnection instance (called by Negotiator)
     */
    setPeerConnection(pc: RTCPeerConnection): void;
    get open(): boolean;
    get peerConnection(): RTCPeerConnection | null;
    get dataChannel(): RTCDataChannel | null;
    get bufferSize(): number;
    initialize(originator: boolean): Promise<void>;
    private _setupDataChannel;
    private _handleDataMessage;
    private _isChunkedData;
    private _handleChunk;
    send(data: unknown): Promise<void>;
    private _drainBuffer;
    handleMessage(message: ServerMessage): void;
    setDataChannel(dataChannel: RTCDataChannel): void;
    /**
     * Estimate the size of data for buffer limit checking
     */
    private _estimateSize;
    close(): void;
}

/** Events emitted by a {@link DataConnection}. */
declare interface DataConnectionEvents {
    /** Fired when the WebRTC data channel is open and ready. */
    open: () => void;
    /** Fired when data is received from the remote peer. */
    data: (data: unknown) => void;
    /** Fired when the data channel is closed. */
    close: () => void;
    /** Fired when an error occurs on the data channel. */
    error: (error: Error) => void;
    /** Fired when the ICE connection state changes. */
    iceStateChanged: (state: RTCIceConnectionState) => void;
}

/** Options for creating a {@link DataConnection}. */
declare interface DataConnectionOptions extends BaseConnectionOptions {
    /** Serialization format for data sent over this connection. */
    serialization?: SerializationType;
    /** Whether the data channel should guarantee ordered delivery. */
    reliable?: boolean;
    /** Maximum buffer size in bytes (default: 64 KB). Messages are dropped if exceeded. */
    maxBufferSize?: number;
}

/** Verbosity level for the Conduit client logger. */
declare enum LogLevel {
    /** No logging output. */
    Disabled = 0,
    /** Log only errors. */
    Errors = 1,
    /** Log errors and warnings. */
    Warnings = 2,
    /** Log everything (debug). */
    All = 3
}

/**
 * A WebRTC media connection to a remote peer for audio/video streaming.
 * Use {@link Conduit.call} to initiate a call, or listen for the `"call"` event to answer one.
 */
declare class MediaConnection extends EventEmitter<MediaConnectionEvents> implements NegotiableConnection {
    readonly type = ConnectionType.Media;
    readonly remote: string;
    readonly provider: Conduit;
    readonly connectionId: string;
    readonly label: string;
    readonly metadata: unknown;
    readonly options: MediaConnectionOptions;
    protected _open: boolean;
    protected _peerConnection: RTCPeerConnection | null;
    private _localStream;
    private _remoteStream;
    private _negotiator;
    constructor(remoteId: string, provider: Conduit, options?: MediaConnectionOptions);
    /**
     * Set the RTCPeerConnection instance (called by Negotiator)
     */
    setPeerConnection(pc: RTCPeerConnection): void;
    get open(): boolean;
    get peerConnection(): RTCPeerConnection | null;
    get localStream(): MediaStream | null;
    get remoteStream(): MediaStream | null;
    initialize(originator: boolean): Promise<void>;
    private _addTracksToConnection;
    private _setupTrackListener;
    /**
     * Answer an incoming media call with the given stream
     */
    answer(stream?: MediaStream): void;
    handleMessage(message: ServerMessage): void;
    close(): void;
    /**
     * Replace a track in the local stream
     */
    replaceTrack(oldTrack: MediaStreamTrack, newTrack: MediaStreamTrack): Promise<void>;
    /**
     * Get stats for the connection
     */
    getStats(): Promise<RTCStatsReport | undefined>;
}

/** Events emitted by a {@link MediaConnection}. */
declare interface MediaConnectionEvents {
    /** Fired when a remote media stream is received. */
    stream: (stream: MediaStream) => void;
    /** Fired when the media connection is ready. */
    open: () => void;
    /** Fired when the media connection is closed. */
    close: () => void;
    /** Fired when an error occurs on the media connection. */
    error: (error: Error) => void;
    /** Fired when the ICE connection state changes. */
    iceStateChanged: (state: RTCIceConnectionState) => void;
}

/** Options for creating a {@link MediaConnection}. */
declare interface MediaConnectionOptions extends BaseConnectionOptions {
    /** The local media stream to send to the remote peer. */
    _stream?: MediaStream;
}

/**
 * Interface for connections that can be negotiated.
 * Both DataConnection and MediaConnection implement this interface.
 */
declare interface NegotiableConnection {
    readonly type: ConnectionType;
    readonly remote: string;
    readonly provider: Conduit;
    readonly connectionId: string;
    readonly label: string;
    readonly metadata: unknown;
    readonly options: {
        serialization?: string;
        reliable?: boolean;
    };
    peerConnection: RTCPeerConnection | null;
    setPeerConnection(pc: RTCPeerConnection): void;
    emit(event: string, ...args: unknown[]): boolean;
    close(): void;
}

declare class Socket extends EventEmitter<SocketEvents> {
    private readonly _options;
    private _ws;
    private _disconnected;
    private _id;
    private _messagesQueue;
    private _reconnectAttempts;
    private _maxReconnectAttempts;
    private _reconnectTimeout;
    constructor(_options: ConduitOptions);
    start(id: string, token: string): void;
    private _buildUrl;
    private _tryReconnect;
    send(data: {
        type: MessageType;
        payload?: unknown;
    }): void;
    private _sendQueuedMessages;
    close(): void;
    get isOpen(): boolean;
}

declare interface SocketEvents {
    message: (data: ServerMessage) => void;
    error: (error: Error) => void;
    close: () => void;
    disconnected: () => void;
}

/**
 * WebSocketConnection provides a WebSocket-based fallback transport
 * when WebRTC is not available or fails to connect.
 * Data is relayed through the signaling server.
 */
declare class WebSocketConnection extends EventEmitter<WebSocketConnectionEvents> {
    readonly type = ConnectionType.Data;
    readonly transport = TransportType.WebSocket;
    readonly remote: string;
    readonly provider: Conduit;
    readonly connectionId: string;
    readonly label: string;
    readonly metadata: unknown;
    readonly options: WebSocketConnectionOptions;
    private _open;
    constructor(remoteId: string, provider: Conduit, options?: WebSocketConnectionOptions);
    get open(): boolean;
    /**
     * Initialize the WebSocket connection by sending a RELAY_OPEN message
     */
    initialize(): void;
    /**
     * Handle incoming messages from the server
     */
    handleMessage(message: ServerMessage): void;
    /**
     * Send data through the WebSocket relay
     */
    send(data: unknown): void;
    /**
     * Close the WebSocket connection
     */
    close(): void;
    private _handleClose;
}

/** Events emitted by a {@link WebSocketConnection}. */
declare interface WebSocketConnectionEvents {
    /** Fired when the relay connection is open and ready. */
    open: () => void;
    /** Fired when data is received via the server relay. */
    data: (data: unknown) => void;
    /** Fired when the relay connection is closed. */
    close: () => void;
    /** Fired when an error occurs. */
    error: (error: Error) => void;
}

/** Options for creating a {@link WebSocketConnection}. */
declare interface WebSocketConnectionOptions {
    /** Unique identifier for this connection. Auto-generated if omitted. */
    connectionId?: string;
    /** Human-readable label for the connection. */
    label?: string;
    /** Arbitrary metadata attached to the connection. */
    metadata?: unknown;
}

export { }
