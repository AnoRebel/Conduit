import { MessageType } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
/** Events emitted by a {@link Room} handle. */
export interface RoomEvents {
    /** Fired once the server confirms the join and sends the member list. */
    open: (members: readonly string[]) => void;
    /** Fired when another peer joins the room. */
    peerJoined: (peerId: string) => void;
    /** Fired when another peer leaves the room. */
    peerLeft: (peerId: string) => void;
    /** Fired when another member broadcasts to the room. */
    message: (data: unknown, from: string) => void;
    /** Fired when this peer has left the room. */
    close: () => void;
    /** Fired when the server refuses an operation on this room. */
    error: (error: Error) => void;
}
/** Sends a signaling message on behalf of a room handle. */
export type RoomSend = (type: MessageType, payload: unknown) => void;
/**
 * A joined room.
 *
 * The member list mirrors what the server reports. It is a convenience for
 * discovering peers to connect to, never an authority: the server decides who
 * may do what, and a client that treated this list as permission would be
 * trusting data it does not own.
 */
export declare class Room extends EventEmitter<RoomEvents> {
    /** The room's name. */
    readonly name: string;
    private readonly _send;
    /** Peers currently in the room, excluding this one. */
    private _members;
    private _open;
    private _closed;
    constructor(
    /** The room's name. */
    name: string, _send: RoomSend);
    /** Peers currently in the room, excluding this one. */
    get members(): readonly string[];
    /** Whether the server has confirmed the join. */
    get open(): boolean;
    /** Broadcast a message to the room's other members. */
    broadcast(data: unknown): void;
    /** Leave the room. */
    leave(): void;
    /** @internal Apply the membership the server reported on join. */
    _setMembers(members: readonly string[]): void;
    /** @internal A peer arrived. */
    _peerJoined(peerId: string): void;
    /** @internal A peer departed. */
    _peerLeft(peerId: string): void;
    /** @internal A broadcast arrived from another member. */
    _message(data: unknown, from: string): void;
    /** @internal The server refused an operation on this room. */
    _error(message: string): void;
    /**
     * @internal Tear the handle down.
     *
     * Listeners are removed so a handle cannot keep an application's callbacks
     * alive after the room is gone.
     */
    _close(): void;
}
//# sourceMappingURL=room.d.ts.map