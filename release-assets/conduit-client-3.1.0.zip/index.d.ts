/**
 * @module @conduit/client
 *
 * WebRTC peer-to-peer client for data, video, and audio connections.
 * Connects to a Conduit signaling server to establish direct peer connections.
 *
 * @example
 * ```typescript
 * import { Conduit } from '@conduit/client';
 *
 * const peer = new Conduit('my-peer-id', { host: 'localhost', port: 9000 });
 * peer.on('open', (id) => console.log('Connected as', id));
 *
 * const conn = peer.connect('other-peer');
 * conn.on('data', (data) => console.log('Received:', data));
 * ```
 */
import "webrtc-adapter";
import "./polyfills/index.js";
export { type AsyncResult, ConduitErrorType, type ConnectionState, ConnectionType, type DataChannelState, type IAnswerMessage, type IAnswerPayload, type ICandidateMessage, type ICandidatePayload, type ICEConnectionState, type ICEGatheringState, type IConduitConfig, type IConduitError, type IDataConnectionOptions as SharedDataConnectionOptions, type IErrorMessage, type IErrorPayload, type IMediaConnectionOptions as SharedMediaConnectionOptions, type IMessage, type INetworkError, type IOfferMessage, type IOfferPayload, type IOpenMessage, type IOpenPayload, type IPeerError, type IRelayPayload, type IServerMessage, type IWebRTCError, MessageType, type Nullable, type Optional, type Result, SerializationType, type ServerMessage, type SignalingState, TransportType, type TypedMessage, } from "@conduit/shared";
export { type CallOptions, Conduit, type ConduitEvents, type ConduitOptions, type ConnectOptions, } from "./conduit.js";
export { ConduitError } from "./conduitError.js";
export { Room, type RoomEvents, type RoomSend } from "./room.js";
export { Topic, type TopicEvents, type TopicSend } from "./topic.js";
export { BaseConnection, type BaseConnectionEvents, type BaseConnectionOptions, } from "./baseconnection.js";
export { AutoConnection, type AutoConnectionEvents, type AutoConnectionOptions, } from "./dataconnection/AutoConnection.js";
export { DataConnection, type DataConnectionEvents, type DataConnectionOptions, } from "./dataconnection/DataConnection.js";
export { WebSocketConnection, type WebSocketConnectionEvents, type WebSocketConnectionOptions, } from "./dataconnection/WebSocketConnection.js";
export { MediaConnection, type MediaConnectionEvents, type MediaConnectionOptions, } from "./mediaconnection.js";
export { LogLevel, logger } from "./logger.js";
export { type BrowserSupport, detectSupport, supports } from "./supports.js";
export { util } from "./util.js";
//# sourceMappingURL=index.d.ts.map