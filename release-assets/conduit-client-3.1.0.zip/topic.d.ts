import { MessageType } from "@conduit/shared";
import { EventEmitter } from "eventemitter3";
/** Events emitted by a {@link Topic} handle. */
export interface TopicEvents {
    /** Fired once the server confirms the subscription. */
    open: () => void;
    /** Fired for each publication matching this subscription. */
    message: (data: unknown, topic: string, from: string) => void;
    /** Fired when this peer has unsubscribed. */
    close: () => void;
    /** Fired when the server refuses an operation on this topic. */
    error: (error: Error) => void;
}
/** Sends a signaling message on behalf of a topic handle. */
export type TopicSend = (type: MessageType, payload: unknown) => void;
/**
 * A topic subscription.
 *
 * The pattern may be an exact topic name or a namespace prefix ending in `.*`;
 * the delivered `topic` is always the concrete name that was published, not the
 * pattern that matched it.
 */
export declare class Topic extends EventEmitter<TopicEvents> {
    /** The subscribed topic name or prefix pattern. */
    readonly pattern: string;
    private readonly _send;
    private _open;
    private _closed;
    constructor(
    /** The subscribed topic name or prefix pattern. */
    pattern: string, _send: TopicSend);
    /** Whether the server has confirmed the subscription. */
    get open(): boolean;
    /** Stop receiving publications on this subscription. */
    unsubscribe(): void;
    /** @internal The server confirmed the subscription. */
    _confirm(): void;
    /** @internal A matching publication arrived. */
    _message(data: unknown, topic: string, from: string): void;
    /** @internal The server refused an operation on this topic. */
    _error(message: string): void;
    /** @internal Tear the handle down, releasing listeners. */
    _close(): void;
}
//# sourceMappingURL=topic.d.ts.map