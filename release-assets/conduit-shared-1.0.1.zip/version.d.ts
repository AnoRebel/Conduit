/**
 * Single source of truth for the Conduit version.
 * Updated automatically by the versioned-release workflow.
 */
export declare const VERSION = "1.0.0";
//# sourceMappingURL=version.d.ts.map