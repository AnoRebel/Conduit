import type { ActionableServerCore } from "./actions.js";
import type { AuditLogger } from "./audit.js";
/** A room and how many peers are in it. */
export interface RoomSummary {
    name: string;
    members: number;
}
/** A room's full membership. */
export interface RoomDetail extends RoomSummary {
    /** Peer identifiers, with the node each is connected to. */
    peers: {
        peerId: string;
        nodeId: string;
    }[];
}
/** One participating server instance. */
export interface ClusterNode {
    nodeId: string;
    peers: number;
}
/** The state of the deployment's cluster. */
export interface ClusterStatus {
    /** Whether a distributed backend is configured. */
    distributed: boolean;
    /** This instance's node identifier. */
    nodeId: string;
    /** Participating nodes with their peer counts. */
    nodes: ClusterNode[];
    /** Whether the distributed backend is reachable. */
    backendReachable: boolean;
    /** Detail when the backend is unreachable. */
    backendError?: string;
}
/** Room inspection and dissolution for authorized administrative callers. */
export interface RoomAdmin {
    /** Every active room with its member count. */
    listRooms(): Promise<RoomSummary[]>;
    /** One room's full membership, or `null` when it does not exist. */
    getRoom(name: string): Promise<RoomDetail | null>;
    /** Remove every member from a room; returns how many were removed. */
    dissolveRoom(name: string, userId: string): Promise<number>;
    /**
     * Place connected peers into a room, creating it if it does not yet exist.
     *
     * Rooms are derived from membership rather than stored in their own right, so
     * there is no such thing as an empty room to create: an admin "adds a room"
     * by putting the first peer in it.
     */
    addRoomMembers(name: string, peerIds: readonly string[], userId: string): Promise<AddMembersResult>;
    /** Cluster participation and backend health. */
    getClusterStatus(): Promise<ClusterStatus>;
    /** Topic and subscription counts. */
    getTopicTotals(): Promise<{
        topics: number;
        subscriptions: number;
    }>;
}
/** Outcome of an admin-forced join. */
export interface AddMembersResult {
    /** Peers that are now members because of this call. */
    added: string[];
    /**
     * Peers that could not be added, each with the reason.
     *
     * Reported per peer rather than failing the whole call, so adding six peers
     * where one has since disconnected still moves the other five.
     */
    skipped: {
        peerId: string;
        reason: "not-connected" | "already-member" | "room-full";
    }[];
}
/** Options for {@link createRoomAdmin}. */
export interface RoomAdminOptions {
    serverCore: ActionableServerCore;
    auditLogger: AuditLogger;
}
export declare function createRoomAdmin(options: RoomAdminOptions): RoomAdmin;
//# sourceMappingURL=rooms.d.ts.map