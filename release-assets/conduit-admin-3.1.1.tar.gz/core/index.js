import { VERSION } from "@conduit/shared";
import { createAuthManager } from "../auth/index.js";
import { createMetricsCollector } from "../metrics/collector.js";
import { instrumentServerCore, syncRealmToMetrics, } from "../metrics/instrumentation.js";
import { createPersistenceStore } from "../persistence/index.js";
import { createAdminActions } from "./actions.js";
import { createAuditLogger } from "./audit.js";
import { createBanManager } from "./bans.js";
import { createRoomAdmin, } from "./rooms.js";
/** Create a new {@link AdminCore} instance with the given configuration. */
export function createAdminCore(options) {
    const { config } = options;
    // Initialize persistence store (defaults to in-memory)
    const store = createPersistenceStore(config.persistence);
    // Initialize components
    const metrics = createMetricsCollector(config.metrics);
    const auth = createAuthManager(config.auth);
    const bans = createBanManager({ store });
    const audit = createAuditLogger({
        enabled: config.audit.enabled,
        maxEntries: config.audit.maxEntries,
        store,
    });
    // Server attachment state
    let serverCore = null;
    let uninstrument = null;
    let actions = null;
    let roomAdmin = null;
    // Start time for uptime calculation
    const startTime = Date.now();
    const clientTracking = new Map();
    function getServerStatus() {
        const snapshot = metrics.getSnapshot();
        return {
            running: serverCore !== null,
            uptime: Date.now() - startTime,
            version: VERSION,
            clients: snapshot.clients,
            messages: snapshot.messages,
            memory: snapshot.memory,
        };
    }
    function trackClientConnect(clientId) {
        clientTracking.set(clientId, {
            connectedAt: Date.now(),
            messagesReceived: 0,
            messagesSent: 0,
            lastActivity: Date.now(),
        });
    }
    function trackClientDisconnect(clientId) {
        clientTracking.delete(clientId);
    }
    function trackClientMessage(clientId) {
        const data = clientTracking.get(clientId);
        if (data) {
            data.messagesReceived++;
            data.lastActivity = Date.now();
        }
    }
    function getClientList() {
        if (!serverCore) {
            return [];
        }
        const clientIds = serverCore.realm.getClientIds();
        const now = Date.now();
        return clientIds.map(id => {
            const client = serverCore?.realm.getClient(id);
            const tracking = clientTracking.get(id);
            return {
                id,
                connected: !!client,
                connectedAt: tracking?.connectedAt ?? now,
                messagesReceived: tracking?.messagesReceived ?? 0,
                messagesSent: tracking?.messagesSent ?? 0,
                lastActivity: tracking?.lastActivity ?? now,
            };
        });
    }
    function getClientDetails(id) {
        if (!serverCore) {
            return null;
        }
        const client = serverCore.realm.getClient(id);
        if (!client) {
            return null;
        }
        const tracking = clientTracking.get(id);
        const now = Date.now();
        return {
            id: client.id,
            connected: true,
            connectedAt: tracking?.connectedAt ?? now,
            messagesReceived: tracking?.messagesReceived ?? 0,
            messagesSent: tracking?.messagesSent ?? 0,
            lastActivity: tracking?.lastActivity ?? now,
            ip: undefined,
            userAgent: undefined,
            queuedMessages: 0,
        };
    }
    /**
     * Refresh the room and topic gauges from live cluster state.
     *
     * Counting rooms is asynchronous while `getSnapshot` is synchronous, so the
     * gauges are refreshed alongside each read rather than computed inside it.
     * A snapshot therefore reflects the counts as of the previous read, which is
     * accurate enough for a monitoring gauge and avoids making the whole metrics
     * surface async.
     */
    function refreshGroupGauges() {
        const cluster = serverCore?.realm?.cluster;
        if (!cluster || !roomAdmin) {
            return;
        }
        // Fan-out volume is counted where the recipient set is resolved, in the
        // server's delivery path; admin reads it rather than trying to infer it
        // from inbound messages, which would undercount every extra copy.
        const readFanOut = serverCore
            .getMulticastDeliveryCount;
        if (typeof readFanOut === "function") {
            metrics.multicastDeliveries.set(readFanOut());
        }
        void (async () => {
            const rooms = await roomAdmin.listRooms();
            metrics.activeRooms.set(rooms.length);
            const totals = await roomAdmin.getTopicTotals();
            metrics.activeTopics.set(totals.topics);
            metrics.subscriptions.set(totals.subscriptions);
        })().catch(() => {
            // A backend hiccup must not break the metrics endpoint; the gauges
            // simply keep their previous values.
        });
    }
    function getMetricsSnapshot() {
        refreshGroupGauges();
        return metrics.getSnapshot();
    }
    function getMetricsHistory(startTime, endTime) {
        return metrics.getHistory(startTime, endTime);
    }
    function getBans() {
        return bans.getBans();
    }
    function isClientBanned(clientId) {
        return bans.isClientBanned(clientId);
    }
    function isIPBanned(ip) {
        return bans.isIPBanned(ip);
    }
    function getAuditLog(limit) {
        return audit.getEntries(limit);
    }
    // Action methods - delegate to actions module
    function disconnectClient(clientId, userId) {
        if (!actions) {
            return false;
        }
        return actions.disconnectClient(clientId, userId);
    }
    function disconnectAllClients(userId) {
        if (!actions) {
            return 0;
        }
        return actions.disconnectAllClients(userId);
    }
    function clearClientQueue(clientId, userId) {
        if (!actions) {
            return false;
        }
        return actions.clearClientQueue(clientId, userId);
    }
    function banClient(clientId, reason, userId) {
        if (!actions) {
            // Can still ban even without server attached
            bans.banClient(clientId, reason);
            audit.log("ban_client", userId, { clientId, reason });
            return true;
        }
        return actions.banClient(clientId, reason, userId);
    }
    function unbanClient(clientId, userId) {
        if (!actions) {
            const result = bans.unbanClient(clientId);
            if (result) {
                audit.log("unban_client", userId, { clientId });
            }
            return result;
        }
        return actions.unbanClient(clientId, userId);
    }
    function banIP(ip, reason, userId) {
        if (!actions) {
            bans.banIP(ip, reason);
            audit.log("ban_ip", userId, { ip, reason });
            return true;
        }
        return actions.banIP(ip, reason, userId);
    }
    function unbanIP(ip, userId) {
        if (!actions) {
            const result = bans.unbanIP(ip);
            if (result) {
                audit.log("unban_ip", userId, { ip });
            }
            return result;
        }
        return actions.unbanIP(ip, userId);
    }
    function broadcastMessage(message, userId) {
        if (!actions) {
            return 0;
        }
        return actions.broadcastMessage(message, userId);
    }
    function updateRateLimits(rateLimitConfig, userId) {
        if (!actions) {
            return;
        }
        actions.updateRateLimits(rateLimitConfig, userId);
    }
    function toggleFeature(feature, enabled, userId) {
        if (!actions) {
            return;
        }
        actions.toggleFeature(feature, enabled, userId);
    }
    function attachToServer(core) {
        if (serverCore) {
            detach();
        }
        serverCore = core;
        // Sync current state
        syncRealmToMetrics(core, metrics);
        // Instrument the server with per-client tracking
        uninstrument = instrumentServerCore(core, metrics, {
            onConnectionOpened: clientId => {
                trackClientConnect(clientId);
            },
            onConnectionClosed: clientId => {
                trackClientDisconnect(clientId);
            },
            onMessageRelayed: clientId => {
                trackClientMessage(clientId);
            },
            onError: _type => {
                // Could emit WebSocket event here
            },
        });
        // Create actions with the attached server
        actions = createAdminActions({
            serverCore,
            banManager: bans,
            auditLogger: audit,
        });
        roomAdmin = createRoomAdmin({ serverCore, auditLogger: audit });
        audit.log("server_attached", "system");
    }
    function detach() {
        if (uninstrument) {
            uninstrument();
            uninstrument = null;
        }
        if (serverCore) {
            audit.log("server_detached", "system");
        }
        serverCore = null;
        actions = null;
    }
    function destroy() {
        detach();
        metrics.destroy();
        bans.clear();
        audit.clear();
        store.close();
    }
    return {
        metrics,
        config,
        auth,
        bans,
        audit,
        getServerStatus,
        getClientList,
        getClientDetails,
        getMetricsSnapshot,
        getMetricsHistory,
        getBans,
        isClientBanned,
        isIPBanned,
        getAuditLog,
        listRooms: async () => (roomAdmin ? await roomAdmin.listRooms() : []),
        getRoom: async (name) => (roomAdmin ? await roomAdmin.getRoom(name) : null),
        dissolveRoom: async (name, userId) => roomAdmin ? await roomAdmin.dissolveRoom(name, userId) : 0,
        addRoomMembers: async (name, peerIds, userId) => roomAdmin
            ? await roomAdmin.addRoomMembers(name, peerIds, userId)
            : // Not attached to a server: nothing can be added, and every peer
                // named is reported as unreachable rather than silently dropped.
                {
                    added: [],
                    skipped: peerIds.map(peerId => ({
                        peerId,
                        reason: "not-connected",
                    })),
                },
        getClusterStatus: async () => roomAdmin
            ? await roomAdmin.getClusterStatus()
            : {
                // Not attached to a server yet: report a single healthy node
                // rather than an error, since nothing is wrong.
                distributed: false,
                nodeId: "local",
                nodes: [],
                backendReachable: true,
            },
        disconnectClient,
        disconnectAllClients,
        clearClientQueue,
        banClient,
        unbanClient,
        banIP,
        unbanIP,
        broadcastMessage,
        updateRateLimits,
        toggleFeature,
        attachToServer,
        detach,
        destroy,
        get isAttached() {
            return serverCore !== null;
        },
        get serverCore() {
            return serverCore;
        },
    };
}
export { createAdminActions, } from "./actions.js";
export { createAuditLogger } from "./audit.js";
export { createBanManager } from "./bans.js";
//# sourceMappingURL=index.js.map