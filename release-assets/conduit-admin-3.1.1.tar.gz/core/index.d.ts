import { type IMessage } from "@conduit/shared";
import { type AuthManager } from "../auth/index.js";
import type { AdminConfig } from "../config.js";
import { type MetricsCollector } from "../metrics/collector.js";
import { type InstrumentableServerCore } from "../metrics/instrumentation.js";
import type { AuditEntry, BanEntry, ClientDetails, ClientInfo, MetricsSnapshot, RateLimitConfig, ServerStatus } from "../types.js";
import { type AuditLogger } from "./audit.js";
import { type BanManager } from "./bans.js";
import { type AddMembersResult, type ClusterStatus, type RoomDetail, type RoomSummary } from "./rooms.js";
/** Central admin panel controller — manages metrics, bans, audit, and server actions. */
export interface AdminCore {
    readonly metrics: MetricsCollector;
    readonly config: AdminConfig;
    readonly auth: AuthManager;
    readonly bans: BanManager;
    readonly audit: AuditLogger;
    getServerStatus(): ServerStatus;
    getClientList(): ClientInfo[];
    getClientDetails(id: string): ClientDetails | null;
    getMetricsSnapshot(): MetricsSnapshot;
    getMetricsHistory(startTime: number, endTime: number): MetricsSnapshot[];
    getBans(): BanEntry[];
    isClientBanned(clientId: string): boolean;
    isIPBanned(ip: string): boolean;
    getAuditLog(limit?: number): AuditEntry[];
    listRooms(): Promise<RoomSummary[]>;
    getRoom(name: string): Promise<RoomDetail | null>;
    dissolveRoom(name: string, userId: string): Promise<number>;
    addRoomMembers(name: string, peerIds: readonly string[], userId: string): Promise<AddMembersResult>;
    getClusterStatus(): Promise<ClusterStatus>;
    disconnectClient(clientId: string, userId: string): boolean;
    disconnectAllClients(userId: string): number;
    clearClientQueue(clientId: string, userId: string): boolean;
    banClient(clientId: string, reason: string | undefined, userId: string): boolean;
    unbanClient(clientId: string, userId: string): boolean;
    banIP(ip: string, reason: string | undefined, userId: string): boolean;
    unbanIP(ip: string, userId: string): boolean;
    broadcastMessage(message: IMessage, userId: string): number;
    updateRateLimits(config: Partial<RateLimitConfig>, userId: string): void;
    toggleFeature(feature: "discovery" | "relay", enabled: boolean, userId: string): void;
    attachToServer(core: InstrumentableServerCore): void;
    detach(): void;
    destroy(): void;
    readonly isAttached: boolean;
    readonly serverCore: InstrumentableServerCore | null;
}
/** Options for {@link createAdminCore}. */
export interface CreateAdminCoreOptions {
    /** Admin configuration. */
    config: AdminConfig;
}
/** Create a new {@link AdminCore} instance with the given configuration. */
export declare function createAdminCore(options: CreateAdminCoreOptions): AdminCore;
export { type ActionableClient, type ActionableServerCore, type AdminActions, createAdminActions, } from "./actions.js";
export { type AuditLogger, type AuditLoggerOptions, createAuditLogger } from "./audit.js";
export { type BanManager, createBanManager } from "./bans.js";
//# sourceMappingURL=index.d.ts.map