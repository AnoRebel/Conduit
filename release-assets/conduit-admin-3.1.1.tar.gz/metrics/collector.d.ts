import type { MetricsConfig } from "../config.js";
import type { MetricsSnapshot } from "../types.js";
import { Counter, CounterMap } from "./counters.js";
import { Gauge } from "./gauges.js";
import { CircularTimeSeries } from "./timeseries.js";
/** Central metrics collector with counters, gauges, and time series. */
export interface MetricsCollector {
    readonly connectionsOpened: Counter;
    readonly connectionsClosed: Counter;
    readonly messagesRelayed: Counter;
    readonly messagesQueued: Counter;
    readonly rateLimitHits: Counter;
    readonly rateLimitRejections: Counter;
    readonly errors: CounterMap;
    readonly activeConnections: Gauge;
    readonly queuedMessages: Gauge;
    readonly activeRooms: Gauge;
    readonly activeTopics: Gauge;
    readonly subscriptions: Gauge;
    /** Messages produced by multicast fan-out, read from the server core. */
    readonly multicastDeliveries: Gauge;
    readonly throughput: CircularTimeSeries;
    readonly latency: CircularTimeSeries;
    getSnapshot(): MetricsSnapshot;
    getHistory(startTime: number, endTime: number): MetricsSnapshot[];
    recordError(type: string): void;
    reset(): void;
    destroy(): void;
    readonly peakConnections: number;
}
export declare function createMetricsCollector(config: MetricsConfig): MetricsCollector;
//# sourceMappingURL=collector.d.ts.map