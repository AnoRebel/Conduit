import { Counter, CounterMap } from "./counters.js";
import { Gauge } from "./gauges.js";
import { CircularTimeSeries } from "./timeseries.js";
export function createMetricsCollector(config) {
    // Counters
    const connectionsOpened = new Counter();
    const connectionsClosed = new Counter();
    const messagesRelayed = new Counter();
    const messagesQueued = new Counter();
    const rateLimitHits = new Counter();
    const rateLimitRejections = new Counter();
    const errors = new CounterMap();
    // Gauges
    const activeConnections = new Gauge();
    const queuedMessages = new Gauge();
    const activeRooms = new Gauge();
    const activeTopics = new Gauge();
    const subscriptions = new Gauge();
    const multicastDeliveries = new Gauge();
    // Time series
    const throughput = new CircularTimeSeries(config.maxSnapshots);
    const latency = new CircularTimeSeries(config.maxSnapshots);
    // Peak tracking
    let peakConnections = 0;
    // Snapshot history
    const snapshots = [];
    let snapshotInterval = null;
    // Track throughput
    let lastMessageCount = 0;
    let lastThroughputTime = Date.now();
    function getMemoryUsage() {
        const mem = process.memoryUsage();
        return {
            heapUsed: mem.heapUsed,
            heapTotal: mem.heapTotal,
            external: mem.external,
            rss: mem.rss,
        };
    }
    function getErrorMetrics() {
        const byType = errors.getAll();
        let total = 0;
        for (const count of Object.values(byType)) {
            total += count;
        }
        return { total, byType };
    }
    function calculateThroughput() {
        const now = Date.now();
        const elapsed = (now - lastThroughputTime) / 1000;
        const currentCount = messagesRelayed.value;
        const messageDelta = currentCount - lastMessageCount;
        lastMessageCount = currentCount;
        lastThroughputTime = now;
        if (elapsed <= 0)
            return 0;
        return Math.round(messageDelta / elapsed);
    }
    function getSnapshot() {
        const currentConnections = activeConnections.value;
        if (currentConnections > peakConnections) {
            peakConnections = currentConnections;
        }
        const tps = calculateThroughput();
        throughput.record(tps);
        return {
            timestamp: Date.now(),
            clients: {
                total: connectionsOpened.value,
                connected: currentConnections,
                peak: peakConnections,
            },
            messages: {
                relayed: messagesRelayed.value,
                queued: queuedMessages.value,
                throughputPerSecond: tps,
            },
            rateLimit: {
                hits: rateLimitHits.value,
                rejections: rateLimitRejections.value,
            },
            errors: getErrorMetrics(),
            memory: getMemoryUsage(),
            groups: {
                activeRooms: activeRooms.value,
                activeTopics: activeTopics.value,
                subscriptions: subscriptions.value,
                multicastDeliveries: multicastDeliveries.value,
            },
        };
    }
    function getHistory(startTime, endTime) {
        return snapshots.filter(s => s.timestamp >= startTime && s.timestamp <= endTime);
    }
    function recordError(type) {
        errors.increment(type);
    }
    function reset() {
        connectionsOpened.reset();
        connectionsClosed.reset();
        messagesRelayed.reset();
        messagesQueued.reset();
        rateLimitHits.reset();
        rateLimitRejections.reset();
        errors.reset();
        activeConnections.set(0);
        queuedMessages.set(0);
        activeRooms.set(0);
        activeTopics.set(0);
        subscriptions.set(0);
        multicastDeliveries.set(0);
        throughput.clear();
        latency.clear();
        snapshots.length = 0;
        peakConnections = 0;
        lastMessageCount = 0;
        lastThroughputTime = Date.now();
    }
    function startSnapshotCollection() {
        snapshotInterval = setInterval(() => {
            const snapshot = getSnapshot();
            snapshots.push(snapshot);
            // Trim old snapshots
            const cutoff = Date.now() - config.retentionMs;
            while (snapshots.length > 0 && snapshots[0] && snapshots[0].timestamp < cutoff) {
                snapshots.shift();
            }
            // Also enforce max snapshots
            while (snapshots.length > config.maxSnapshots) {
                snapshots.shift();
            }
        }, config.snapshotIntervalMs);
        if (snapshotInterval.unref) {
            snapshotInterval.unref();
        }
    }
    function destroy() {
        if (snapshotInterval) {
            clearInterval(snapshotInterval);
            snapshotInterval = null;
        }
    }
    // Start collecting snapshots
    startSnapshotCollection();
    return {
        connectionsOpened,
        connectionsClosed,
        messagesRelayed,
        messagesQueued,
        rateLimitHits,
        rateLimitRejections,
        errors,
        activeConnections,
        queuedMessages,
        activeRooms,
        activeTopics,
        subscriptions,
        multicastDeliveries,
        throughput,
        latency,
        getSnapshot,
        getHistory,
        recordError,
        reset,
        destroy,
        get peakConnections() {
            return peakConnections;
        },
    };
}
//# sourceMappingURL=collector.js.map