import type { AuthResult } from "../auth/index.js";
import type { AdminCore } from "../core/index.js";
/** Context provided to each admin route handler. */
export interface RouteContext {
    admin: AdminCore;
    auth: AuthResult;
    params: Record<string, string>;
    query: Record<string, string>;
    body: unknown;
}
/** Serializable response returned from a route handler. */
export interface RouteResponse {
    status: number;
    body: unknown;
    headers?: Record<string, string>;
}
/** Async-compatible function that processes a request and returns a response. */
export type RouteHandler = (ctx: RouteContext) => RouteResponse | Promise<RouteResponse>;
/** A registered admin API route. */
export interface Route {
    method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
    path: string;
    handler: RouteHandler;
    requiresAuth: boolean;
}
/** Create a JSON response with the given data and status code. */
export declare function json(data: unknown, status?: number): RouteResponse;
/** Create an error JSON response. */
export declare function error(message: string, status?: number): RouteResponse;
/** Create a 404 Not Found response. */
export declare function notFound(message?: string): RouteResponse;
/** Create a 401 Unauthorized response. */
export declare function unauthorized(message?: string): RouteResponse;
/** Create a 403 Forbidden response. */
export declare function forbidden(message?: string): RouteResponse;
/** Build the full set of admin API routes. */
export declare function createRoutes(): Route[];
export { auditRoutes } from "./audit.js";
export { bansRoutes } from "./bans.js";
export { clientRoutes } from "./clients.js";
export { configRoutes } from "./config.js";
export { metricsRoutes } from "./metrics.js";
export { roomsRoutes } from "./rooms.js";
export { statusRoutes } from "./status.js";
//# sourceMappingURL=index.d.ts.map