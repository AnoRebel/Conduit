import type { Route } from "./index.js";
/**
 * Room inspection, dissolution, and cluster status.
 *
 * Every route requires authentication. Dissolution is state-changing, so the
 * adapters' existing CSRF protection applies to it exactly as it does to bans
 * and the other POST actions.
 */
export declare const roomsRoutes: Route[];
//# sourceMappingURL=rooms.d.ts.map