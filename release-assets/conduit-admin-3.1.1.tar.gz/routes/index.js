/** Create a JSON response with the given data and status code. */
export function json(data, status = 200) {
    return {
        status,
        body: data,
        headers: { "Content-Type": "application/json" },
    };
}
/** Create an error JSON response. */
export function error(message, status = 400) {
    return json({ error: message }, status);
}
/** Create a 404 Not Found response. */
export function notFound(message = "Not found") {
    return error(message, 404);
}
/** Create a 401 Unauthorized response. */
export function unauthorized(message = "Unauthorized") {
    return error(message, 401);
}
/** Create a 403 Forbidden response. */
export function forbidden(message = "Forbidden") {
    return error(message, 403);
}
import { auditRoutes } from "./audit.js";
import { bansRoutes } from "./bans.js";
import { clientRoutes } from "./clients.js";
import { configRoutes } from "./config.js";
import { metricsRoutes } from "./metrics.js";
import { roomsRoutes } from "./rooms.js";
// Import route handlers
import { statusRoutes } from "./status.js";
/** Build the full set of admin API routes. */
export function createRoutes() {
    return [
        ...statusRoutes,
        ...clientRoutes,
        ...metricsRoutes,
        ...bansRoutes,
        ...auditRoutes,
        ...configRoutes,
        ...roomsRoutes,
    ];
}
export { auditRoutes } from "./audit.js";
export { bansRoutes } from "./bans.js";
export { clientRoutes } from "./clients.js";
export { configRoutes } from "./config.js";
export { metricsRoutes } from "./metrics.js";
export { roomsRoutes } from "./rooms.js";
export { statusRoutes } from "./status.js";
//# sourceMappingURL=index.js.map