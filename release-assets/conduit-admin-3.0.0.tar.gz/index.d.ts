/**
 * @module @conduit/admin
 *
 * Admin API and dashboard backend for Conduit signaling servers.
 * Provides authentication, metrics collection, audit logging, ban management,
 * and REST/SSE/WebSocket endpoints for real-time server monitoring.
 *
 * @example
 * ```typescript
 * import { createAdminCore, createAdminConfig } from '@conduit/admin';
 * import { createNodeAdminServer } from '@conduit/admin/adapters/node';
 *
 * const config = createAdminConfig({ auth: { methods: ['apiKey'] } });
 * const admin = createAdminCore({ config });
 * const server = createNodeAdminServer({ admin });
 * server.listen(9001);
 * ```
 */
export { ApiKeyAuth } from "./auth/apiKey.js";
export { BasicAuth } from "./auth/basic.js";
export { type AuthManager, type AuthResult, createAuthManager, } from "./auth/index.js";
export { JWTAuth } from "./auth/jwt.js";
export { SessionManager } from "./auth/session.js";
export { type AdminConfig, type AdminConfigOptions, type AdminRateLimitConfig, type AdminWebSocketConfig, type AuditConfig, type AuthConfig, createAdminConfig, type MetricsConfig, type SSEConfig, validateAdminConfig, } from "./config.js";
export { createPersistenceStore, MemoryStore, type PersistenceConfig, type PersistenceStore, type SQLiteStore, } from "./persistence/index.js";
export { type ActionableClient, type ActionableServerCore, type AdminActions, type AdminCore, type AuditLogger, type AuditLoggerOptions, type BanManager, type CreateAdminCoreOptions, createAdminActions, createAdminCore, createAuditLogger, createBanManager, } from "./core/index.js";
export { CircularTimeSeries, Counter, CounterMap, createMetricsCollector, createMetricsProxy, Gauge, GaugeMap, type InstrumentableServerCore, type InstrumentationHooks, instrumentServerCore, type MetricsCollector, syncRealmToMetrics, TimeSeriesMap, type TimeSeriesPoint, type TimeSeriesStats, } from "./metrics/index.js";
export { createRoutes, error, forbidden, json, notFound, type Route, type RouteContext, type RouteHandler, type RouteResponse, unauthorized, } from "./routes/index.js";
export { createSSERoutes, createSSEServer, type SSEClient, type SSEServer, type SSEServerOptions, } from "./sse/index.js";
export { type AdminEventMessage, type AdminEventType, type AdminWSClient, type AdminWSServer, type AdminWSServerOptions, type ClientToServerEvents, createAdminWSServer, createEvent, parseClientMessage, type ServerToClientEvents, serializeEvent, } from "./websocket/index.js";
export { createExpressAdminMiddleware, createFastifyAdminPlugin, createHonoAdminMiddleware, createNodeAdminServer, type ExpressAdminServerOptions, type ExpressMiddleware, type ExpressNext, type ExpressRequest, type ExpressResponse, type FastifyAdminServerOptions, type FastifyInstance, type FastifyPlugin, type FastifyReply, type FastifyRequest, type HonoAdminServerOptions, type HonoContext, type HonoMiddleware, type HonoNext, type NodeAdminServer, type NodeAdminServerOptions, } from "./adapters/index.js";
export { type AggregatedMetrics, type AggregatedStatus, aggregateMetrics, aggregateStatus, createRemoteServer, createStandaloneAdmin, type RemoteServer, type RemoteServerOptions, type StandaloneAdmin, type StandaloneAdminOptions, } from "./standalone/index.js";
export type { AdminActionResult, AdminRequest, AdminResponse, AdminWSCommand, AdminWSEventMap, APIError, AuditAction, AuditEntry, AuthSession, BanEntry, BanList, BroadcastOptions, ClientDetails, ClientInfo, ClientMetrics, ConnectedServer, ErrorMetrics, FeatureToggle, JWTPayload, MemoryUsage, MessageMetrics, MetricsHistory, MetricsSnapshot, RateLimitConfig, RateLimitMetrics, ServerConfigSummary, ServerConnection, ServerStatus, } from "./types.js";
//# sourceMappingURL=index.d.ts.map