// ============================================================================
// Persistence Store Interface
// ============================================================================
import { createRequire } from "node:module";
import { MemoryStore } from "./memory.js";
// ============================================================================
// Factory
// ============================================================================
/** Create a {@link PersistenceStore} based on the given configuration. */
export function createPersistenceStore(config = { type: "memory" }) {
    if (config.type === "sqlite") {
        // Loaded lazily: ./sqlite.js imports "bun:sqlite", which does not exist
        // outside the Bun runtime. A static import would make this whole module --
        // and therefore the admin core -- unloadable under Node, even for
        // deployments that never select the SQLite backend.
        const { SQLiteStore } = loadSQLiteStore();
        return new SQLiteStore(config.dbPath || "conduit-admin.db");
    }
    return new MemoryStore();
}
/** Resolve the SQLite backend on demand. Throws outside the Bun runtime. */
function loadSQLiteStore() {
    try {
        return createRequire(import.meta.url)("./sqlite.js");
    }
    catch (cause) {
        throw new Error('SQLite persistence requires the Bun runtime ("bun:sqlite" is unavailable). ' +
            'Use persistence type "memory", or run the server under Bun.', { cause });
    }
}
export { MemoryStore } from "./memory.js";
//# sourceMappingURL=index.js.map