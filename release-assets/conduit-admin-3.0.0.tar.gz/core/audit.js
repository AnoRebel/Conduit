import { randomBytes } from "node:crypto";
/** Create an {@link AuditLogger} with optional persistence backing. */
export function createAuditLogger(options = {}) {
    const { enabled = true, maxEntries = 1000, store } = options;
    // In-memory buffer for fast access (even with persistence, we keep a cache)
    const entries = [];
    // Hydrate from persistence store on creation
    if (store) {
        const persisted = store.getAuditEntries(maxEntries);
        // persisted is newest-first, reverse for our oldest-first array
        entries.push(...persisted.reverse());
    }
    function log(action, userId, details) {
        const entry = {
            id: generateId(),
            timestamp: Date.now(),
            action,
            userId,
            details,
        };
        if (enabled) {
            entries.push(entry);
            // Auditing must not take down the operation being audited: a failing
            // store is reported, not propagated into the caller's request.
            try {
                store?.saveAuditEntry(entry);
            }
            catch (err) {
                console.error("Failed to persist audit entry:", err);
            }
            // Trim old entries from memory
            while (entries.length > maxEntries) {
                entries.shift();
            }
        }
        return entry;
    }
    function getEntries(limit) {
        // Prefer store for full history, fall back to in-memory
        if (store) {
            return store.getAuditEntries(limit);
        }
        if (!limit) {
            return [...entries].reverse();
        }
        return entries.slice(-limit).reverse();
    }
    function getEntriesByUser(userId, limit) {
        if (store) {
            return store.getAuditEntriesByUser(userId, limit);
        }
        const filtered = entries.filter(e => e.userId === userId);
        if (!limit) {
            return [...filtered].reverse();
        }
        return filtered.slice(-limit).reverse();
    }
    function getEntriesByAction(action, limit) {
        if (store) {
            return store.getAuditEntriesByAction(action, limit);
        }
        const filtered = entries.filter(e => e.action === action);
        if (!limit) {
            return [...filtered].reverse();
        }
        return filtered.slice(-limit).reverse();
    }
    function getEntriesInRange(startTime, endTime) {
        if (store) {
            return store.getAuditEntriesInRange(startTime, endTime);
        }
        return entries.filter(e => e.timestamp >= startTime && e.timestamp <= endTime).reverse();
    }
    function clear() {
        entries.length = 0;
        store?.clearAudit();
    }
    /**
     * Generate an audit record identifier.
     *
     * Uses a CSPRNG rather than Math.random: this value is the audit_log PRIMARY
     * KEY, so a collision is a failed INSERT, and predictable identifiers weaken
     * the audit trail itself. 96 bits makes collisions unexpected for the
     * lifetime of a deployment.
     */
    function generateId() {
        return `audit_${Date.now()}_${randomBytes(12).toString("base64url")}`;
    }
    return {
        log,
        getEntries,
        getEntriesByUser,
        getEntriesByAction,
        getEntriesInRange,
        clear,
        get enabled() {
            return enabled;
        },
        get size() {
            if (store) {
                return store.getAuditSize();
            }
            return entries.length;
        },
    };
}
//# sourceMappingURL=audit.js.map