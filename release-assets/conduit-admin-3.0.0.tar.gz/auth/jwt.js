import jwt from "jsonwebtoken";
/**
 * Signing algorithms accepted when verifying a token.
 *
 * Pinned explicitly so a token cannot dictate how it is verified: without this,
 * verification is driven by the `alg` header of the token being checked.
 */
const ALLOWED_ALGORITHMS = ["HS256"];
/** Authenticator for JWT-based authentication with token generation and validation. */
export class JWTAuth {
    _secret;
    _expiresIn;
    constructor(secret, expiresIn = 3600) {
        this._secret = secret;
        this._expiresIn = expiresIn;
    }
    validate(token) {
        if (!token || typeof token !== "string") {
            return { valid: false, error: "Invalid token format" };
        }
        try {
            const decoded = jwt.verify(token, this._secret, {
                algorithms: [...ALLOWED_ALGORITHMS],
            });
            return {
                valid: true,
                userId: decoded.sub,
                // A token that does not claim a role is not treated as privileged.
                role: decoded.role ?? "viewer",
            };
        }
        catch (error) {
            if (error instanceof jwt.TokenExpiredError) {
                return { valid: false, error: "Token expired" };
            }
            if (error instanceof jwt.JsonWebTokenError) {
                return { valid: false, error: "Invalid token" };
            }
            return { valid: false, error: "Token verification failed" };
        }
    }
    generate(userId, role = "admin") {
        const payload = {
            sub: userId,
            iat: Math.floor(Date.now() / 1000),
            exp: Math.floor(Date.now() / 1000) + this._expiresIn,
            role,
        };
        return jwt.sign(payload, this._secret, { algorithm: ALLOWED_ALGORITHMS[0] });
    }
    decode(token) {
        try {
            return jwt.decode(token);
        }
        catch {
            return null;
        }
    }
}
//# sourceMappingURL=jwt.js.map