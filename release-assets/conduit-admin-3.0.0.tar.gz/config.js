// ============================================================================
// Default Configuration
// ============================================================================
/** Default admin configuration values. */
export const defaultAdminConfig = {
    path: "/admin",
    apiVersion: "v1",
    auth: {
        methods: ["apiKey"],
        sessionTimeout: 3600000, // 1 hour
        jwtExpiresIn: 3600, // 1 hour
    },
    rateLimit: {
        enabled: true,
        maxRequests: 100,
        windowMs: 60000, // 1 minute
    },
    trustProxy: false,
    metrics: {
        retentionMs: 86400000, // 24 hours
        snapshotIntervalMs: 1000, // 1 second
        maxSnapshots: 3600, // 1 hour of history at 1/sec
    },
    audit: {
        enabled: true,
        maxEntries: 10000,
        logLevel: "actions",
    },
    websocket: {
        enabled: true,
        path: "/ws",
        heartbeatInterval: 30000,
    },
    sse: {
        enabled: true,
        keepAliveInterval: 15000,
    },
};
/** Create a full {@link AdminConfig} by merging partial overrides with defaults. */
export function createAdminConfig(options = {}) {
    return {
        ...defaultAdminConfig,
        ...options,
        auth: {
            ...defaultAdminConfig.auth,
            ...options.auth,
        },
        rateLimit: {
            ...defaultAdminConfig.rateLimit,
            ...options.rateLimit,
        },
        metrics: {
            ...defaultAdminConfig.metrics,
            ...options.metrics,
        },
        audit: {
            ...defaultAdminConfig.audit,
            ...options.audit,
        },
        websocket: {
            ...defaultAdminConfig.websocket,
            ...options.websocket,
        },
        sse: {
            ...defaultAdminConfig.sse,
            ...options.sse,
        },
    };
}
// ============================================================================
// Validation
// ============================================================================
/** Validate an {@link AdminConfig} and return any configuration errors. */
export function validateAdminConfig(config) {
    const errors = [];
    // Validate auth
    if (config.auth.methods.length === 0) {
        errors.push("At least one authentication method must be configured");
    }
    if (config.auth.methods.includes("apiKey") && !config.auth.apiKey) {
        errors.push("API key authentication enabled but no apiKey provided");
    }
    if (config.auth.methods.includes("jwt") && !config.auth.jwtSecret) {
        errors.push("JWT authentication enabled but no jwtSecret provided");
    }
    if (config.auth.methods.includes("basic") && !config.auth.basicCredentials) {
        errors.push("Basic authentication enabled but no basicCredentials provided");
    }
    // Validate rate limiting
    if (config.rateLimit.maxRequests < 1) {
        errors.push("Rate limit maxRequests must be at least 1");
    }
    if (config.rateLimit.windowMs < 1000) {
        errors.push("Rate limit windowMs must be at least 1000ms");
    }
    // Validate metrics
    if (config.metrics.snapshotIntervalMs < 100) {
        errors.push("Metrics snapshotIntervalMs must be at least 100ms");
    }
    if (config.metrics.maxSnapshots < 10) {
        errors.push("Metrics maxSnapshots must be at least 10");
    }
    // Validate standalone mode
    if (config.standalone) {
        for (const server of config.standalone.servers) {
            if (!server.id || !server.url || !server.adminKey) {
                errors.push(`Invalid server connection: ${server.id || "unknown"}`);
            }
        }
    }
    return {
        valid: errors.length === 0,
        errors,
    };
}
//# sourceMappingURL=config.js.map