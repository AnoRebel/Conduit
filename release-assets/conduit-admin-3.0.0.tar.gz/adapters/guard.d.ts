/**
 * @module
 *
 * Framework-agnostic request guard shared by every admin adapter.
 *
 * Rate limiting, role-based access control, CSRF content-type checking and
 * body-size limiting used to live only in the Node adapter, which meant an
 * Express, Fastify or Hono deployment silently enforced none of them. This
 * module is the single implementation all four adapters delegate to, so the
 * protections cannot drift apart again.
 *
 * The guard is pure with respect to the transport: it takes a normalized
 * request description and returns either `null` (proceed) or the response the
 * adapter must send. It never touches a framework request or response object.
 */
import type { AuthResult } from "../auth/index.js";
import type { AdminRateLimitConfig } from "../config.js";
import { type RouteResponse } from "../routes/index.js";
/** Maximum allowed request body size (1MB) to prevent DoS attacks. */
export declare const MAX_BODY_SIZE: number;
/** A transport-independent description of an inbound request. */
export interface NormalizedRequest {
    /** Uppercase HTTP method. */
    method: string;
    /** Lowercased header names mapped to their values. */
    headers: Record<string, string | string[] | undefined>;
    /** Request path, already stripped of the admin base path. */
    path: string;
    /** Transport-level peer address, before any forwarded-header handling. */
    remoteAddress?: string;
    /**
     * Declared body size in bytes, when the transport knows it up front. Adapters
     * that stream the body enforce {@link MAX_BODY_SIZE} while reading instead.
     */
    contentLength?: number;
}
/** Options controlling how a client address is derived from a request. */
export interface ClientAddressOptions {
    /**
     * Whether the server sits behind a trusted reverse proxy. Forwarded headers
     * are only honoured when this is true -- otherwise any client could spoof
     * `X-Forwarded-For` and mint itself an unlimited rate-limit budget.
     */
    trustProxy: boolean;
}
/**
 * Resolve the address used for rate limiting and ban decisions.
 *
 * `X-Forwarded-For` is attacker-controlled unless a trusted proxy is known to
 * overwrite it, so it is consulted only when `trustProxy` is enabled.
 */
export declare function resolveClientAddress(req: NormalizedRequest, options: ClientAddressOptions): string;
/** Returns true when the method changes state. */
export declare function isWriteMethod(method: string): boolean;
/** Token-bucket rate limiter keyed by client address. */
export interface RateLimiter {
    isAllowed(clientId: string): boolean;
    destroy(): void;
}
/** Create a token-bucket rate limiter. */
export declare function createRateLimiter(maxRequests: number, windowMs: number): RateLimiter;
/** Create a rate limiter from config, or `null` when rate limiting is disabled. */
export declare function createRateLimiterFromConfig(rateLimitConfig: AdminRateLimitConfig): RateLimiter | null;
/**
 * Reject a state-changing request that does not positively declare a JSON body.
 *
 * A missing `Content-Type` is rejected rather than allowed: a cross-site
 * `fetch` can omit the header entirely, so treating "absent" as acceptable
 * would leave the hole this check exists to close.
 */
export declare function checkCsrf(req: NormalizedRequest): RouteResponse | null;
/** Reject a request whose declared body size exceeds the maximum. */
export declare function checkBodySize(req: NormalizedRequest, maxBytes?: number): RouteResponse | null;
/** Reject a state-changing request from a caller lacking the admin role. */
export declare function checkRole(method: string, auth: AuthResult): RouteResponse | null;
/** Reject a request that exceeds the configured rate limit. */
export declare function checkRateLimit(limiter: RateLimiter | null, clientAddress: string): RouteResponse | null;
/** Options for {@link applyPreAuthGuard}. */
export interface PreAuthGuardOptions {
    limiter: RateLimiter | null;
    trustProxy: boolean;
    maxBodySize?: number;
}
/**
 * Run every check that does not depend on the caller's identity.
 *
 * Ordering matters: rate limiting runs first so that flooding the endpoint is
 * cheap to refuse, and the body-size check runs before any body is read.
 * Returns `null` when the request may proceed to authentication.
 */
export declare function applyPreAuthGuard(req: NormalizedRequest, options: PreAuthGuardOptions): RouteResponse | null;
/**
 * Run checks that depend on the authenticated caller.
 *
 * Returns `null` when the request may proceed to its route handler.
 */
export declare function applyPostAuthGuard(method: string, auth: AuthResult): RouteResponse | null;
//# sourceMappingURL=guard.d.ts.map