/**
 * @module @conduit/admin/adapters/express
 *
 * Express middleware adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import express from 'express';
 * import { createExpressAdminMiddleware } from '@conduit/admin/adapters/express';
 *
 * const app = express();
 * app.use('/admin', createExpressAdminMiddleware({ admin }));
 * ```
 */
import type { AdminCore } from "../core/index.js";
/**
 * Express-compatible request object (minimal interface)
 */
export interface ExpressRequest {
    method: string;
    path: string;
    query: Record<string, string>;
    body?: unknown;
    headers: Record<string, string | string[] | undefined>;
    params?: Record<string, string>;
    /** Underlying connection, used as the transport-level peer address. */
    socket?: {
        remoteAddress?: string | undefined;
    };
}
/**
 * Express-compatible response object (minimal interface)
 */
export interface ExpressResponse {
    status(code: number): ExpressResponse;
    json(body: unknown): void;
    set(headers: Record<string, string>): void;
    end(): void;
}
/**
 * Express-compatible next function
 */
export type ExpressNext = (err?: unknown) => void;
/**
 * Express-compatible middleware
 */
export type ExpressMiddleware = (req: ExpressRequest, res: ExpressResponse, next: ExpressNext) => void | Promise<void>;
export interface ExpressAdminServerOptions {
    admin: AdminCore;
}
/**
 * Create an Express middleware for the admin API
 */
export declare function createExpressAdminMiddleware(options: ExpressAdminServerOptions): ExpressMiddleware;
//# sourceMappingURL=express.d.ts.map