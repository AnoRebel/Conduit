/**
 * @module @conduit/admin/adapters/fastify
 *
 * Fastify plugin adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import Fastify from 'fastify';
 * import { createFastifyAdminPlugin } from '@conduit/admin/adapters/fastify';
 *
 * const fastify = Fastify();
 * fastify.register(createFastifyAdminPlugin({ admin }));
 * ```
 */
import type { AdminCore } from "../core/index.js";
/**
 * Fastify-compatible request object (minimal interface)
 */
export interface FastifyRequest {
    method: string;
    url: string;
    query: Record<string, string>;
    body?: unknown;
    headers: Record<string, string | string[] | undefined>;
    params?: Record<string, string>;
    /** Underlying socket, used as the transport-level peer address. */
    socket?: {
        remoteAddress?: string;
    };
}
/**
 * Fastify-compatible reply object (minimal interface)
 */
export interface FastifyReply {
    code(code: number): FastifyReply;
    send(body: unknown): void;
    headers(headers: Record<string, string>): FastifyReply;
}
/**
 * Fastify-compatible done callback
 */
export type FastifyDone = (err?: Error) => void;
/**
 * Fastify-compatible hook handler
 */
export type FastifyHook = (request: FastifyRequest, reply: FastifyReply, done: FastifyDone) => void;
/**
 * Fastify-compatible plugin
 */
export type FastifyPlugin = (fastify: FastifyInstance, opts: FastifyPluginOptions, done: FastifyDone) => void;
export interface FastifyInstance {
    get(path: string, handler: FastifyRouteHandler): void;
    post(path: string, handler: FastifyRouteHandler): void;
    put(path: string, handler: FastifyRouteHandler): void;
    patch(path: string, handler: FastifyRouteHandler): void;
    delete(path: string, handler: FastifyRouteHandler): void;
    addHook(name: string, hook: FastifyHook): void;
}
export type FastifyRouteHandler = (request: FastifyRequest, reply: FastifyReply) => void | Promise<void>;
export interface FastifyPluginOptions {
    prefix?: string;
}
export interface FastifyAdminServerOptions {
    admin: AdminCore;
}
/**
 * Create a Fastify plugin for the admin API
 */
export declare function createFastifyAdminPlugin(options: FastifyAdminServerOptions): FastifyPlugin;
//# sourceMappingURL=fastify.d.ts.map