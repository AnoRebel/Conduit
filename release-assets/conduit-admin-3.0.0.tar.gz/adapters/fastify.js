/**
 * @module @conduit/admin/adapters/fastify
 *
 * Fastify plugin adapter for the Conduit Admin API.
 *
 * @example
 * ```typescript
 * import Fastify from 'fastify';
 * import { createFastifyAdminPlugin } from '@conduit/admin/adapters/fastify';
 *
 * const fastify = Fastify();
 * fastify.register(createFastifyAdminPlugin({ admin }));
 * ```
 */
import { createRoutes, error, unauthorized, } from "../routes/index.js";
import { applyPostAuthGuard, applyPreAuthGuard, createRateLimiterFromConfig, } from "./guard.js";
/**
 * Build the transport-independent request description the shared guard needs.
 *
 * Deliberately reads the raw socket address rather than Fastify's `request.ip`:
 * `request.ip` already reflects `X-Forwarded-For` when Fastify's own trustProxy
 * option is enabled, which would silently override the admin config's
 * `trustProxy` decision. Keeping the forwarded-header choice in one place means
 * an operator cannot accidentally trust a spoofable address here.
 */
function toNormalizedRequest(request, path) {
    const declaredLength = Number(request.headers["content-length"]);
    return {
        method: request.method?.toUpperCase() ?? "GET",
        headers: request.headers,
        path,
        remoteAddress: request.socket?.remoteAddress,
        contentLength: Number.isFinite(declaredLength) ? declaredLength : undefined,
    };
}
/**
 * Create a Fastify plugin for the admin API
 */
export function createFastifyAdminPlugin(options) {
    const { admin } = options;
    const routes = createRoutes();
    // Initialize rate limiter from config. Created once per plugin, never per
    // request -- a per-request limiter would refill its bucket every time.
    const rateLimiter = createRateLimiterFromConfig(admin.config.rateLimit);
    return (fastify, _opts, done) => {
        // Register routes
        for (const route of routes) {
            const handler = createRouteHandler(admin, route, rateLimiter);
            const method = route.method.toLowerCase();
            // Convert :param to Fastify's :param format (same format, just register)
            fastify[method](route.path, handler);
        }
        done();
    };
}
function createRouteHandler(admin, route, rateLimiter) {
    return async (request, reply) => {
        // Rate limiting, CSRF and body-size checks, shared with every other adapter
        const preAuth = applyPreAuthGuard(toNormalizedRequest(request, route.path), {
            limiter: rateLimiter,
            trustProxy: admin.config.trustProxy,
        });
        if (preAuth) {
            sendResponse(reply, preAuth);
            return;
        }
        // Handle authentication
        let authResult = { valid: false, error: "Not authenticated" };
        if (route.requiresAuth) {
            authResult = admin.auth.authenticateRequest(request.headers);
            if (!authResult.valid) {
                sendResponse(reply, unauthorized(authResult.error));
                return;
            }
            // Role-based access control: write operations require admin role
            const postAuth = applyPostAuthGuard(request.method?.toUpperCase() ?? "GET", authResult);
            if (postAuth) {
                sendResponse(reply, postAuth);
                return;
            }
        }
        else {
            authResult = { valid: true };
        }
        // Create context
        const ctx = {
            admin,
            auth: authResult,
            params: request.params ?? {},
            query: request.query,
            body: request.body,
        };
        // Execute handler
        try {
            const response = await route.handler(ctx);
            sendResponse(reply, response);
        }
        catch (err) {
            console.error("Route handler error:", err);
            sendResponse(reply, error("Internal server error", 500));
        }
    };
}
function sendResponse(reply, response) {
    const { status, body, headers } = response;
    reply.code(status);
    if (headers) {
        reply.headers(headers);
    }
    reply.send(body);
}
//# sourceMappingURL=fastify.js.map