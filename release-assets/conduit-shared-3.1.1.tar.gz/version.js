/**
 * Runtime Conduit version constant.
 * Stamped from the root `version.json` by `scripts/sync-version.ts`.
 */
export const VERSION = "3.1.0";
//# sourceMappingURL=version.js.map