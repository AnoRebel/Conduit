/**
 * @module @conduit/shared
 *
 * Shared types, enums, and constants for the Conduit WebRTC signaling ecosystem.
 * This package provides the foundational building blocks used by both
 * `@conduit/client` and `@conduit/server`.
 *
 * @example
 * ```typescript
 * import { MessageType, ConnectionType, VERSION } from '@conduit/shared';
 * ```
 */
export { ConduitErrorType, ConnectionType, MessageType, SerializationType, ServerErrorType, SocketEventType, TransportType, } from "./enums.js";
export { VERSION } from "./version.js";
export type { AsyncResult, ConnectionState, DataChannelState, DeepPartial, DeepPartialServerConfig, DeepReadonly, EventHandler, IAnswerMessage, IAnswerPayload, IAutoConnectionOptions, IBrowserSupport, IBufferStats, ICandidateMessage, ICandidatePayload, ICEConnectionState, ICEGatheringState, IClientDetails, IClientInfo, IConduitConfig, IConduitError, IConduitEvents, IConfigurationError, IConnectionEvents, IConnectionStats, IDataConnectionOptions, IErrorMessage, IErrorPayload, IErrorPayload as ConduitError, IEventEmitter, IExpireMessage, IGoAwayMessage, IGoAwayPayload, IHeartbeatMessage, IHeartbeatPayload, IIdTakenMessage, IJoinMessage, IJoinPayload, ILeaveMessage, ILeavePayload, ILeaveRoomMessage, ILeaveRoomPayload, IMediaConnectionEvents, IMediaConnectionOptions, IMessage, IMessage as ServerMessage, INetworkError, IOfferMessage, IOfferPayload, IOpenMessage, IOpenPayload, IPeerError, IPeerJoinedMessage, IPeerJoinedPayload, IPeerLeftMessage, IPeerLeftPayload, IPublishMessage, IPublishPayload, IRelayCloseMessage, IRelayMessage, IRelayOpenMessage, IRelayPayload, IRoomBroadcastMessage, IRoomBroadcastPayload, IRoomStateMessage, IRoomStatePayload, IServerConfig, IServerError, IServerMessage, ISubscribedMessage, ISubscribeMessage, ISubscribePayload, ITopicMessage, ITopicMessagePayload, IUnsubscribedMessage, IUnsubscribeMessage, IUnsubscribePayload, IWebRTCConnectionOptions, IWebRTCError, IWebSocketConnectionOptions, KeysOfType, LogLevel, LogLevelName, MessageTypeOf, Nullable, Optional, OptionalKeys, PartialServerConfig, PayloadOf, RequireKeys, Result, SignalingState, SpecificConduitError, TransportConnectionOptions, TypedMessage, } from "./types.js";
//# sourceMappingURL=index.d.ts.map