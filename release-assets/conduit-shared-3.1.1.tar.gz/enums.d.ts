/**
 * Message types used for signaling between client and server
 */
export declare enum MessageType {
    /** Server confirms connection is open */
    OPEN = "OPEN",
    /** Conduit is leaving/disconnecting */
    LEAVE = "LEAVE",
    /** ICE candidate exchange */
    CANDIDATE = "CANDIDATE",
    /** SDP offer for connection negotiation */
    OFFER = "OFFER",
    /** SDP answer for connection negotiation */
    ANSWER = "ANSWER",
    /** Message/offer has expired */
    EXPIRE = "EXPIRE",
    /** Keep-alive heartbeat */
    HEARTBEAT = "HEARTBEAT",
    /** Requested conduit ID is already taken */
    ID_TAKEN = "ID-TAKEN",
    /** Generic error message */
    ERROR = "ERROR",
    /** Data relayed through server */
    RELAY = "RELAY",
    /** WebSocket relay channel established */
    RELAY_OPEN = "RELAY_OPEN",
    /** WebSocket relay channel closed */
    RELAY_CLOSE = "RELAY_CLOSE",
    /** Server is shutting down gracefully */
    GOAWAY = "GOAWAY",
    /** Join a named room */
    JOIN = "JOIN",
    /** Leave a named room. Distinct from LEAVE, which remains peer-to-peer. */
    LEAVE_ROOM = "LEAVE_ROOM",
    /** Current membership of a room, sent to a peer that just joined */
    ROOM_STATE = "ROOM_STATE",
    /** A peer joined a room this peer belongs to */
    PEER_JOINED = "PEER_JOINED",
    /** A peer left a room this peer belongs to */
    PEER_LEFT = "PEER_LEFT",
    /** Subscribe to a topic or topic prefix */
    SUBSCRIBE = "SUBSCRIBE",
    /** Unsubscribe from a topic or topic prefix */
    UNSUBSCRIBE = "UNSUBSCRIBE",
    /** Server confirms a subscription was recorded */
    SUBSCRIBED = "SUBSCRIBED",
    /** Server confirms a subscription was removed */
    UNSUBSCRIBED = "UNSUBSCRIBED",
    /** Publish a message to a topic */
    PUBLISH = "PUBLISH",
    /** A publication delivered to a matching subscriber */
    TOPIC_MESSAGE = "TOPIC_MESSAGE",
    /** Multicast a message to the members of a room */
    ROOM_BROADCAST = "ROOM_BROADCAST"
}
/**
 * Types of conduit connections
 */
export declare enum ConnectionType {
    /** Data channel connection */
    Data = "data",
    /** Media stream connection */
    Media = "media"
}
/**
 * Data serialization formats for DataConnections
 */
export declare enum SerializationType {
    /** Binary pack format (default) */
    Binary = "binary",
    /** Binary UTF-8 format */
    BinaryUTF8 = "binary-utf8",
    /** JSON format */
    JSON = "json",
    /** Raw binary (no serialization) */
    None = "raw",
    /** MessagePack format (requires streams support) */
    MsgPack = "msgpack"
}
/**
 * Transport types for data connections
 */
export declare enum TransportType {
    /** WebRTC DataChannel (default P2P) */
    WebRTC = "webrtc",
    /** WebSocket relay through server (fallback) */
    WebSocket = "websocket",
    /** Auto-detect: try WebRTC, fallback to WebSocket */
    Auto = "auto"
}
/**
 * Conduit error types
 */
export declare enum ConduitErrorType {
    /** Browser doesn't support WebRTC */
    BrowserIncompatible = "browser-incompatible",
    /** Lost connection to signaling server */
    Disconnected = "disconnected",
    /** Invalid API key */
    InvalidKey = "invalid-key",
    /** Invalid conduit ID format */
    InvalidID = "invalid-id",
    /** Network error */
    Network = "network",
    /** Remote conduit not found */
    ConduitUnavailable = "conduit-unavailable",
    /** SSL required but not used */
    SslUnavailable = "ssl-unavailable",
    /** Server error */
    ServerError = "server-error",
    /** Socket error */
    SocketError = "socket-error",
    /** Socket closed unexpectedly */
    SocketClosed = "socket-closed",
    /** Connection unavailable */
    UnavailableID = "unavailable-id",
    /** WebRTC error */
    WebRTC = "webrtc"
}
/**
 * Server error types
 */
export declare enum ServerErrorType {
    /** Invalid WebSocket parameters */
    InvalidWSParameters = "Invalid WS parameters",
    /** Connection limit exceeded */
    ConnectionLimitExceed = "Connection limit exceeded",
    /** Invalid API key */
    InvalidKey = "Invalid key"
}
/**
 * Socket event types
 */
export declare enum SocketEventType {
    Message = "message",
    Disconnected = "disconnected",
    Error = "error",
    Close = "close"
}
//# sourceMappingURL=enums.d.ts.map