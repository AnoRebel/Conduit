/**
 * Message types used for signaling between client and server
 */
export var MessageType;
(function (MessageType) {
    /** Server confirms connection is open */
    MessageType["OPEN"] = "OPEN";
    /** Conduit is leaving/disconnecting */
    MessageType["LEAVE"] = "LEAVE";
    /** ICE candidate exchange */
    MessageType["CANDIDATE"] = "CANDIDATE";
    /** SDP offer for connection negotiation */
    MessageType["OFFER"] = "OFFER";
    /** SDP answer for connection negotiation */
    MessageType["ANSWER"] = "ANSWER";
    /** Message/offer has expired */
    MessageType["EXPIRE"] = "EXPIRE";
    /** Keep-alive heartbeat */
    MessageType["HEARTBEAT"] = "HEARTBEAT";
    /** Requested conduit ID is already taken */
    MessageType["ID_TAKEN"] = "ID-TAKEN";
    /** Generic error message */
    MessageType["ERROR"] = "ERROR";
    // WebSocket relay messages (for fallback transport)
    /** Data relayed through server */
    MessageType["RELAY"] = "RELAY";
    /** WebSocket relay channel established */
    MessageType["RELAY_OPEN"] = "RELAY_OPEN";
    /** WebSocket relay channel closed */
    MessageType["RELAY_CLOSE"] = "RELAY_CLOSE";
    // Server lifecycle messages
    /** Server is shutting down gracefully */
    MessageType["GOAWAY"] = "GOAWAY";
    // Room membership and presence
    /** Join a named room */
    MessageType["JOIN"] = "JOIN";
    /** Leave a named room. Distinct from LEAVE, which remains peer-to-peer. */
    MessageType["LEAVE_ROOM"] = "LEAVE_ROOM";
    /** Current membership of a room, sent to a peer that just joined */
    MessageType["ROOM_STATE"] = "ROOM_STATE";
    /** A peer joined a room this peer belongs to */
    MessageType["PEER_JOINED"] = "PEER_JOINED";
    /** A peer left a room this peer belongs to */
    MessageType["PEER_LEFT"] = "PEER_LEFT";
    // Topic subscription and multicast
    /** Subscribe to a topic or topic prefix */
    MessageType["SUBSCRIBE"] = "SUBSCRIBE";
    /** Unsubscribe from a topic or topic prefix */
    MessageType["UNSUBSCRIBE"] = "UNSUBSCRIBE";
    /** Server confirms a subscription was recorded */
    MessageType["SUBSCRIBED"] = "SUBSCRIBED";
    /** Server confirms a subscription was removed */
    MessageType["UNSUBSCRIBED"] = "UNSUBSCRIBED";
    /** Publish a message to a topic */
    MessageType["PUBLISH"] = "PUBLISH";
    /** A publication delivered to a matching subscriber */
    MessageType["TOPIC_MESSAGE"] = "TOPIC_MESSAGE";
    /** Multicast a message to the members of a room */
    MessageType["ROOM_BROADCAST"] = "ROOM_BROADCAST";
})(MessageType || (MessageType = {}));
/**
 * Types of conduit connections
 */
export var ConnectionType;
(function (ConnectionType) {
    /** Data channel connection */
    ConnectionType["Data"] = "data";
    /** Media stream connection */
    ConnectionType["Media"] = "media";
})(ConnectionType || (ConnectionType = {}));
/**
 * Data serialization formats for DataConnections
 */
export var SerializationType;
(function (SerializationType) {
    /** Binary pack format (default) */
    SerializationType["Binary"] = "binary";
    /** Binary UTF-8 format */
    SerializationType["BinaryUTF8"] = "binary-utf8";
    /** JSON format */
    SerializationType["JSON"] = "json";
    /** Raw binary (no serialization) */
    SerializationType["None"] = "raw";
    /** MessagePack format (requires streams support) */
    SerializationType["MsgPack"] = "msgpack";
})(SerializationType || (SerializationType = {}));
/**
 * Transport types for data connections
 */
export var TransportType;
(function (TransportType) {
    /** WebRTC DataChannel (default P2P) */
    TransportType["WebRTC"] = "webrtc";
    /** WebSocket relay through server (fallback) */
    TransportType["WebSocket"] = "websocket";
    /** Auto-detect: try WebRTC, fallback to WebSocket */
    TransportType["Auto"] = "auto";
})(TransportType || (TransportType = {}));
/**
 * Conduit error types
 */
export var ConduitErrorType;
(function (ConduitErrorType) {
    /** Browser doesn't support WebRTC */
    ConduitErrorType["BrowserIncompatible"] = "browser-incompatible";
    /** Lost connection to signaling server */
    ConduitErrorType["Disconnected"] = "disconnected";
    /** Invalid API key */
    ConduitErrorType["InvalidKey"] = "invalid-key";
    /** Invalid conduit ID format */
    ConduitErrorType["InvalidID"] = "invalid-id";
    /** Network error */
    ConduitErrorType["Network"] = "network";
    /** Remote conduit not found */
    ConduitErrorType["ConduitUnavailable"] = "conduit-unavailable";
    /** SSL required but not used */
    ConduitErrorType["SslUnavailable"] = "ssl-unavailable";
    /** Server error */
    ConduitErrorType["ServerError"] = "server-error";
    /** Socket error */
    ConduitErrorType["SocketError"] = "socket-error";
    /** Socket closed unexpectedly */
    ConduitErrorType["SocketClosed"] = "socket-closed";
    /** Connection unavailable */
    ConduitErrorType["UnavailableID"] = "unavailable-id";
    /** WebRTC error */
    ConduitErrorType["WebRTC"] = "webrtc";
})(ConduitErrorType || (ConduitErrorType = {}));
/**
 * Server error types
 */
export var ServerErrorType;
(function (ServerErrorType) {
    /** Invalid WebSocket parameters */
    ServerErrorType["InvalidWSParameters"] = "Invalid WS parameters";
    /** Connection limit exceeded */
    ServerErrorType["ConnectionLimitExceed"] = "Connection limit exceeded";
    /** Invalid API key */
    ServerErrorType["InvalidKey"] = "Invalid key";
})(ServerErrorType || (ServerErrorType = {}));
/**
 * Socket event types
 */
export var SocketEventType;
(function (SocketEventType) {
    SocketEventType["Message"] = "message";
    SocketEventType["Disconnected"] = "disconnected";
    SocketEventType["Error"] = "error";
    SocketEventType["Close"] = "close";
})(SocketEventType || (SocketEventType = {}));
//# sourceMappingURL=enums.js.map