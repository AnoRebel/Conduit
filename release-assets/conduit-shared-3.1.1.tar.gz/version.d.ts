/**
 * Runtime Conduit version constant.
 * Stamped from the root `version.json` by `scripts/sync-version.ts`.
 */
export declare const VERSION = "3.1.0";
//# sourceMappingURL=version.d.ts.map