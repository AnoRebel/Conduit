/**
 * The documented default key from Conduit 1.x.
 *
 * Published in the README and therefore no protection at all. Retained only so
 * the server can recognise and reject it; see {@link assertSecureKey}.
 */
export const INSECURE_DEFAULT_KEY = "conduit";
/**
 * Whether a signaling key is set and is not the well-known default.
 *
 * Exported so hosts (the CLI, tests, embedders) can check a key without
 * triggering the throw.
 */
export function isKeyAcceptable(key) {
    return typeof key === "string" && key.trim() !== "" && key !== INSECURE_DEFAULT_KEY;
}
/**
 * Throw unless the configured signaling key is safe to serve with.
 *
 * Enforced in the library rather than only in the CLI: a key published in the
 * project's own README offers no protection, and embedding the server directly
 * must not be a way to bypass that.
 *
 * @throws When auth mode is `"key"` and the key is missing or the public default.
 */
export function assertSecureKey(config, options = {}) {
    if (config.auth.mode !== "key" || options.allowInsecureKey) {
        return;
    }
    if (!isKeyAcceptable(config.key)) {
        throw new Error((config.key === INSECURE_DEFAULT_KEY
            ? `Refusing to start: the signaling key "${INSECURE_DEFAULT_KEY}" is the documented default and is public.`
            : "Refusing to start: no signaling key is configured.") +
            "\n\nSet config.key to a generated secret, e.g. randomBytes(24).toString('base64url')." +
            "\nFor local development only, pass allowInsecureKey: true to proceed anyway.");
    }
}
/**
 * Throw unless a configured distributed backend is safe to use.
 *
 * Inter-node messages carry assertions about which peer a message is from. An
 * unauthenticated Redis would let anyone able to publish to the channel forge
 * those assertions, so the credential is mandatory rather than advisory —
 * mirroring how {@link assertSecureKey} refuses the public default key rather
 * than warning about it.
 *
 * @throws When the backend is `redis` and no password is configured.
 */
export function assertSecureClusterBackend(config) {
    if (config.cluster.backend !== "redis") {
        return;
    }
    const password = config.cluster.redis.password;
    if (typeof password !== "string" || password.trim() === "") {
        throw new Error("Refusing to start: the redis cluster backend requires a password." +
            "\n\nInter-node messages assert which peer they originate from, so an" +
            "\nunauthenticated backend would let anyone able to publish to it" +
            "\nimpersonate any peer." +
            "\n\nSet config.cluster.redis.password, or use the default in-memory backend.");
    }
}
/** Default server configuration values. */
export const defaultConfig = {
    port: 9000,
    host: "0.0.0.0",
    path: "/",
    // Deliberately the insecure default: assertSecureKey rejects it, so an
    // embedder who never sets a key gets a clear error rather than a server
    // silently authenticated by a value published in the README.
    key: INSECURE_DEFAULT_KEY,
    auth: {
        mode: "key",
    },
    expireTimeout: 5000,
    aliveTimeout: 60000,
    concurrentLimit: 5000,
    allowDiscovery: false,
    cleanupOutMsgs: 1000,
    corsOrigin: true,
    allowedOrigins: undefined, // Allow all by default - set to array for whitelist
    proxied: false,
    requireSecure: false, // Set to true in production to enforce HTTPS/WSS
    relay: {
        enabled: true,
        maxMessageSize: 65536, // 64KB
    },
    cluster: {
        // Single-process by default: no external service, no new failure mode.
        backend: "memory",
        peerTtlSeconds: 90,
        forwardTimeoutMs: 2000,
        redis: {
            url: "redis://127.0.0.1:6379",
            keyPrefix: "conduit",
        },
    },
    rooms: {
        enabled: true,
        maxRoomsPerPeer: 32,
        maxMembersPerRoom: 256,
        maxRooms: 10000,
    },
    topics: {
        // Multicast is opt-in: see TopicsConfig.enabled.
        enabled: false,
        maxSubscriptionsPerPeer: 64,
        maxSubscribersPerTopic: 1024,
        maxTopics: 10000,
        maxRecipientsPerMessage: 256,
        maxMulticastMessageSize: 16384,
    },
    rateLimit: {
        enabled: true,
        maxTokens: 100, // Burst capacity
        refillRate: 50, // Messages per second sustained
    },
    logging: {
        level: "info",
        pretty: false,
    },
};
/** Create a full {@link ServerConfig} by merging partial overrides with {@link defaultConfig}. */
export function createConfig(options = {}) {
    return {
        ...defaultConfig,
        ...options,
        auth: {
            ...defaultConfig.auth,
            ...options.auth,
        },
        relay: {
            ...defaultConfig.relay,
            ...options.relay,
        },
        cluster: {
            ...defaultConfig.cluster,
            ...options.cluster,
            redis: {
                ...defaultConfig.cluster.redis,
                ...options.cluster?.redis,
            },
        },
        rooms: {
            ...defaultConfig.rooms,
            ...options.rooms,
        },
        topics: {
            ...defaultConfig.topics,
            ...options.topics,
        },
        rateLimit: {
            ...defaultConfig.rateLimit,
            ...options.rateLimit,
        },
        logging: {
            ...defaultConfig.logging,
            ...options.logging,
        },
    };
}
//# sourceMappingURL=config.js.map