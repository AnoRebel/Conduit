/**
 * @module @conduit/server
 *
 * WebRTC signaling server for Conduit. Provides the core server logic
 * and adapters for Node.js, Bun, Hono, Express, and Fastify.
 *
 * @example
 * ```typescript
 * import { createConduitServer } from '@conduit/server/adapters/node';
 *
 * const server = createConduitServer({ config: { port: 9000 } });
 * server.listen();
 * ```
 */
export { type AsyncResult, ConduitErrorType, ConnectionType, type DeepPartialServerConfig, type IAnswerMessage, type IAnswerPayload, type ICandidateMessage, type ICandidatePayload, type IErrorPayload, type IMessage, type IOfferMessage, type IOfferPayload, type IRelayPayload, type IServerConfig, type IServerMessage, MessageType, type PartialServerConfig, type Result, SerializationType, type ServerMessage, TransportType, type TypedMessage, } from "@conduit/shared";
export { assertSecureClusterBackend, assertSecureKey, type ClusterBackendKind, type ClusterConfig, createConfig, defaultConfig, INSECURE_DEFAULT_KEY, isKeyAcceptable, type LoggingConfig, type RateLimitConfig, type RedisClusterConfig, type RoomsConfig, type ServerAuthConfig, type ServerConfig, type ServerConfigOverrides, type TopicsConfig, } from "./config.js";
export { createChildLogger, createLogger, getLogger, type ILogger, type LoggerConfig, type LogLevel, logger, wrapLogger, } from "./logger.js";
export { Client, type IClient } from "./core/client.js";
export { getMulticastDeliveryCount, resetMulticastDeliveryCount, } from "./core/delivery.js";
export { type ConduitServerCore, type CreateConduitServerCoreOptions, createConduitServerCore, } from "./core/index.js";
export { DefaultMessageHandler, type MessageHandler } from "./core/messageHandler/index.js";
export { type IMessageQueue, MessageQueue } from "./core/messageQueue.js";
export { type IRealm, Realm } from "./core/realm.js";
export { type BackendHealth, type ClusterBackend, createClusterBackend, type ForwardedEnvelope, type ForwardHandler, InMemoryClusterBackend, type PeerLocation, RedisClusterBackend, type RedisClusterBackendOptions, type RedisLike, } from "./cluster/index.js";
export { ExpressConduitServer } from "./adapters/express.js";
export { fastifyConduitPlugin } from "./adapters/fastify.js";
export { type ConduitServer, createConduitServer, type NodeAdapterOptions, } from "./adapters/node.js";
export { MAX_ID_LENGTH, MAX_KEY_LENGTH, MAX_MESSAGE_SIZE, MAX_PAYLOAD_DEPTH, MAX_ROOM_NAME_LENGTH, MAX_TOKEN_LENGTH, MAX_TOPIC_NAME_LENGTH, MAX_TOPIC_SEGMENTS, safeJsonParse, type ValidationResult, validateId, validateKey, validateMessage, validatePayloadDestination, validateRoomName, validateToken, validateTopicName, validateTopicPattern, } from "./core/validation.js";
//# sourceMappingURL=index.d.ts.map