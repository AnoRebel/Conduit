export class RateLimiter {
    _buckets = new Map();
    _maxTokens;
    _refillRate;
    constructor(config) {
        this._maxTokens = config.maxTokens;
        this._refillRate = config.refillRate;
    }
    tryConsume(clientId, cost = 1) {
        // A non-positive or non-finite cost would either be a free pass or corrupt
        // the bucket; treat anything unexpected as the minimum chargeable unit.
        const charge = Number.isFinite(cost) && cost > 0 ? Math.ceil(cost) : 1;
        // A cost larger than the bucket could never be met however long a caller
        // waits, so refuse without disturbing the bucket rather than deadlocking.
        if (charge > this._maxTokens) {
            return false;
        }
        const now = Date.now();
        let bucket = this._buckets.get(clientId);
        if (!bucket) {
            // New client starts with full bucket
            bucket = {
                tokens: this._maxTokens,
                lastRefill: now,
            };
            this._buckets.set(clientId, bucket);
        }
        // Refill tokens based on time elapsed
        const elapsed = (now - bucket.lastRefill) / 1000; // Convert to seconds
        const refill = elapsed * this._refillRate;
        bucket.tokens = Math.min(this._maxTokens, bucket.tokens + refill);
        bucket.lastRefill = now;
        // All-or-nothing: a partial charge would mean a partially delivered
        // multicast, which the spec forbids.
        if (bucket.tokens >= charge) {
            bucket.tokens -= charge;
            return true;
        }
        return false;
    }
    removeClient(clientId) {
        this._buckets.delete(clientId);
    }
    clear() {
        this._buckets.clear();
    }
}
// Default rate limit: 100 messages per second burst, 50 messages per second sustained
export const DEFAULT_RATE_LIMIT_CONFIG = {
    maxTokens: 100,
    refillRate: 50,
};
//# sourceMappingURL=rateLimiter.js.map