import type { ClusterBackend, PeerLocation } from "../cluster/types.js";
import type { ServerConfig } from "../config.js";
/** Why a subscription was refused. */
export type SubscribeRefusal = "topics-disabled" | "topic-full" | "peer-subscription-limit" | "server-topic-limit" | "unauthorized";
/** Outcome of a subscribe attempt. */
export type SubscribeResult = {
    ok: true;
    alreadySubscribed: boolean;
} | {
    ok: false;
    refusal: SubscribeRefusal;
};
/** Outcome of an unsubscribe attempt. */
export type UnsubscribeResult = {
    ok: true;
} | {
    ok: false;
    refusal: "not-subscribed";
};
/**
 * Decides whether a peer may subscribe to, or publish on, a topic.
 *
 * Absent by default, in which case any authenticated peer may use any topic.
 * Synchronous for the same reason as the room authorizer: an await in the
 * message path is its own amplification vector.
 *
 * @returns `false` to refuse the operation.
 */
export type TopicAuthorizer = (peerId: string, topic: string, action: "subscribe" | "publish") => boolean;
/**
 * Every subscription pattern that could match a published topic.
 *
 * For `a.b.c` this is the topic itself plus `a.*` and `a.b.*` — one entry per
 * ancestor namespace. The count is bounded by the topic's segment depth, which
 * validation caps, so resolving subscribers never scales with how many
 * subscriptions exist on the server. That bound is the reason only a trailing
 * `.*` is supported: arbitrary glob matching would force a scan of every
 * subscription per publish, which is itself a denial-of-service vector.
 */
export declare function matchingPatterns(topic: string): string[];
/**
 * Topic subscriptions, pattern matching, and the limits that bound them.
 *
 * Like {@link RoomRegistry}, state lives in the {@link ClusterBackend} so a
 * subscription made on one instance is visible to every other.
 */
export declare class TopicRegistry {
    private readonly backend;
    private readonly config;
    private readonly authorize?;
    constructor(backend: ClusterBackend, config: ServerConfig, authorize?: TopicAuthorizer | undefined);
    /** Record a subscription, enforcing every limit and the authorization hook. */
    subscribe(peerId: string, pattern: string): Promise<SubscribeResult>;
    /** Remove a subscription the peer holds. */
    unsubscribe(peerId: string, pattern: string): Promise<UnsubscribeResult>;
    /**
     * Peers whose subscriptions match a published topic.
     *
     * A peer holding several matching patterns appears once: the union is taken
     * by peer id, so a subscriber can never receive one publication twice.
     */
    subscribers(topic: string): Promise<readonly PeerLocation[]>;
    /** Whether a peer may publish on a topic. */
    canPublish(peerId: string, topic: string): boolean;
    /** Subscriptions a peer currently holds. */
    subscriptionsOf(peerId: string): Promise<readonly string[]>;
    /** Number of distinct topics in existence. */
    count(): Promise<number>;
}
//# sourceMappingURL=topicRegistry.d.ts.map