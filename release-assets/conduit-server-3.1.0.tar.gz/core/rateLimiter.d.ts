/**
 * Token bucket rate limiter for per-client message limiting
 */
export interface RateLimiterConfig {
    /** Maximum tokens (burst capacity) */
    maxTokens: number;
    /** Tokens added per second */
    refillRate: number;
}
export interface IRateLimiter {
    /**
     * Try to consume `cost` tokens.
     *
     * @param cost - Tokens to consume, defaulting to 1. Fan-out handlers pass the
     * number of recipients so a peer's budget is denominated in *deliveries*
     * rather than received messages: without this, addressing a 100-member room
     * would grant 100x the throughput of addressing one peer.
     * @returns `true` when the full cost was consumed. A cost that cannot be met
     * consumes nothing, so a refused multicast delivers to nobody rather than
     * partially.
     */
    tryConsume(clientId: string, cost?: number): boolean;
    /** Remove a client from the rate limiter */
    removeClient(clientId: string): void;
    /** Clear all clients */
    clear(): void;
}
export declare class RateLimiter implements IRateLimiter {
    private readonly _buckets;
    private readonly _maxTokens;
    private readonly _refillRate;
    constructor(config: RateLimiterConfig);
    tryConsume(clientId: string, cost?: number): boolean;
    removeClient(clientId: string): void;
    clear(): void;
}
export declare const DEFAULT_RATE_LIMIT_CONFIG: RateLimiterConfig;
//# sourceMappingURL=rateLimiter.d.ts.map