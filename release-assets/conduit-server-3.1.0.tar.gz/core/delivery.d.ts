import type { IMessage } from "@conduit/shared";
import type { ServerConfig } from "../config.js";
import type { IClient } from "./client.js";
import type { IRateLimiter } from "./rateLimiter.js";
import type { IRealm } from "./realm.js";
/**
 * What to do when a recipient cannot be written to right now.
 *
 * Signaling (OFFER/ANSWER/CANDIDATE) is queued for an absent peer so a callee
 * that connects moments later still receives it. Multicast is dropped: a
 * publication is meaningful only to peers currently subscribed, and queueing it
 * would let one sender grow the queue by the size of a room.
 */
export type UndeliverablePolicy = "queue" | "drop";
/** A resolved delivery target. */
export interface Recipient {
    /** The peer's identifier. */
    id: string;
    /** The connected client, when it is local to this instance. */
    client?: IClient;
}
/** Why a fan-out was refused before any recipient was written to. */
export type FanOutRefusal = "too-many-recipients" | "rate-limited";
/** Messages produced by multicast fan-out since the process started. */
export declare function getMulticastDeliveryCount(): number;
/** Reset the fan-out counter. Intended for tests and metric resets. */
export declare function resetMulticastDeliveryCount(): void;
/** Outcome of a delivery attempt. */
export interface DeliveryResult {
    /** Number of recipients the message was written to. */
    delivered: number;
    /** Number of recipients whose copy was queued for later. */
    queued: number;
    /** Number of recipients whose copy was dropped. */
    dropped: number;
}
/**
 * Validate a destination identifier the same way a peer ID is validated.
 *
 * Without this an arbitrary string becomes a message-queue key, letting a
 * client grow the queue map without bound by addressing destinations that never
 * exist. Shared by every handler so the rule cannot drift between them.
 *
 * @returns `true` when the destination is well-formed; otherwise sends the
 * client an error and returns `false`.
 */
export declare function ensureValidDestination(client: IClient, dst: string): boolean;
/**
 * The single point at which a message reaches its recipients.
 *
 * Every handler routes through here so that the fan-out ceiling and the
 * weighted rate-limit charge are enforced in one place. A handler that resolved
 * its own recipients and sent to them directly could bypass both, and that kind
 * of invariant decays as handlers are added -- so there is exactly one door.
 *
 * Rate limiting is charged by recipient count *before* anything is written, so
 * a refused multicast delivers to nobody rather than partially.
 */
export declare function deliver(realm: IRealm, message: IMessage, recipients: readonly Recipient[], policy: UndeliverablePolicy): DeliveryResult;
/**
 * Deliver to exactly one peer, queueing when it is not writable.
 *
 * The shape every pre-existing 1:1 handler needs.
 */
export declare function deliverToPeer(realm: IRealm, message: IMessage, dst: string): DeliveryResult;
/** Whether a multicast payload is within the configured size limit. */
export declare function withinMulticastSizeLimit(config: ServerConfig, data: unknown): boolean;
/**
 * Deliver to many recipients, enforcing the amplification bounds first.
 *
 * The order matters and is the whole point of this function:
 *
 * 1. Refuse outright if the recipient set exceeds the per-message ceiling.
 * 2. Charge the sender for every recipient, all-or-nothing.
 * 3. Only then write to anyone.
 *
 * Checking after partial delivery would leave a refused multicast half-sent,
 * and charging one token per inbound message (as the ordinary path does) would
 * let a peer in a large room buy throughput proportional to the room size.
 *
 * @returns The delivery result, or a refusal naming which bound was hit.
 */
export declare function deliverFanOut(realm: IRealm, config: ServerConfig, senderId: string, message: IMessage, recipients: readonly Recipient[], rateLimiter: IRateLimiter | null, 
/**
 * Recipients on other nodes, which this call charges for but does not write
 * to. Keeps the sender's budget honest when most of a fan-out is remote.
 */
remoteRecipientCount?: number): DeliveryResult | {
    refused: FanOutRefusal;
};
/**
 * The node owning a peer, or `null` when no node claims it.
 *
 * Local-first: a peer connected here resolves without consulting the backend.
 * A backend that cannot be reached answers `null` rather than throwing, so
 * callers fall back to their own not-found behaviour instead of failing.
 */
export declare function resolvePeerNode(realm: IRealm, peerId: string): Promise<string | null>;
/**
 * Resolve a destination across the cluster and deliver.
 *
 * Local-first: a peer connected to this instance is written to directly and the
 * backend is never consulted. Only a local miss asks the backend who owns the
 * peer, so the common case — and every case under an affinity-based load
 * balancer — pays no cross-node cost.
 *
 * This is the function that fixes cross-instance 1:1 signaling. Before it, a
 * local miss meant "queue for a peer that will never read it".
 */
export declare function deliverAcrossCluster(realm: IRealm, message: IMessage, dst: string, srcPeerId: string): Promise<DeliveryResult>;
/**
 * Group recipients by the node that owns them.
 *
 * Local recipients come back under `local`; everything else is bucketed by node
 * so one forward carries every recipient on that node rather than one per peer.
 */
export declare function groupRecipientsByNode(realm: IRealm, peerIds: readonly string[]): Promise<{
    local: Recipient[];
    remote: Map<string, string[]>;
}>;
//# sourceMappingURL=delivery.d.ts.map