import type { ClusterBackend } from "../cluster/types.js";
import type { IClient } from "./client.js";
import { type IMessageQueue } from "./messageQueue.js";
/** Tracks all connected clients and their pending message queues. */
export interface IRealm {
    /** Look up a client by ID. */
    getClient(id: string): IClient | undefined;
    /** Return all connected client IDs. */
    getClientIds(): string[];
    /** Register a client in the realm. */
    setClient(client: IClient): void;
    /** Remove and return a client by ID. */
    removeClient(id: string): IClient | undefined;
    /** Access the realm's message queue. */
    getMessageQueue(): IMessageQueue;
    /** Generate a unique client ID. */
    generateClientId(): string;
    /** Check whether a client with the given ID exists. */
    clientExists(id: string): boolean;
    /**
     * Whether a connection may collect the messages queued for a peer ID.
     *
     * Queued signaling is addressed to whoever legitimately holds an ID, so it
     * must not follow the ID to an unrelated party. Two cases are safe:
     *
     * - The ID has never been held, so the queue belongs to this first connector
     *   (the ordinary "offer arrives before the callee connects" flow).
     * - The ID was held before by a session presenting this same token, i.e. the
     *   original peer returning after being reaped.
     *
     * A server-generated ID is additionally unguessable (96 bits from a CSPRNG),
     * so it cannot be squatted in the first place.
     */
    mayCollectQueuedMessages(id: string, token: string): boolean;
    /** Record that a peer ID has been released by its holder. */
    releaseId(id: string, token: string): void;
    /**
     * The cluster backend backing this realm.
     *
     * Deliberately reached as a separate object rather than through the methods
     * above: every member of this interface is synchronous and must stay that
     * way, because handlers use their results on the next line. Cross-instance
     * lookups are asynchronous, so they live here and are awaited only inside
     * the delivery path.
     *
     * Note what this means for {@link getClient}: it answers "connected to *this*
     * instance", never "exists in the cluster". That is already what it meant
     * before distribution; only the interpretation of `undefined` changes, from
     * "no such peer" to "not local".
     */
    readonly cluster: ClusterBackend;
}
/** In-memory implementation of {@link IRealm}. */
export declare class Realm implements IRealm {
    /** The cluster backend; single-node in-memory unless one is supplied. */
    readonly cluster: ClusterBackend;
    private readonly _clients;
    private readonly _messageQueue;
    /** IDs previously held by a session, kept briefly to detect ID takeover. */
    private readonly _releasedIds;
    /** IDs this server issued, which are unguessable by construction. */
    private readonly _serverGeneratedIds;
    constructor(cluster?: ClusterBackend);
    /**
     * Look up a client connected to this instance.
     *
     * Returns `undefined` for a peer connected to another node. Callers that
     * must reach the whole cluster go through the delivery path, which consults
     * {@link cluster} on a local miss.
     */
    getClient(id: string): IClient | undefined;
    /** Return all connected client IDs. */
    getClientIds(): string[];
    /** Register a client in the realm. */
    setClient(client: IClient): void;
    /** Remove and return a client by ID. */
    removeClient(id: string): IClient | undefined;
    /** Access the realm's message queue. */
    getMessageQueue(): IMessageQueue;
    /** Generate a unique client ID. */
    generateClientId(): string;
    /** Check whether a client with the given ID exists. */
    clientExists(id: string): boolean;
    /** Whether a connection may collect the messages queued for a peer ID. */
    mayCollectQueuedMessages(id: string, token: string): boolean;
    /** Record that a peer ID has been released by its holder. */
    releaseId(id: string, token: string): void;
    private _pruneReleasedIds;
    /**
     * Fingerprint a session token.
     *
     * Only the digest is retained, so the released-ID table never holds a value
     * that could be replayed if it leaked.
     */
    private _hashToken;
    private _randomId;
}
//# sourceMappingURL=realm.d.ts.map