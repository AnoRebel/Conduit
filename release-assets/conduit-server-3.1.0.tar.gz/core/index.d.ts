import type { RawData, WebSocket } from "ws";
import type { ClusterBackend } from "../cluster/types.js";
import { type ServerConfig, type ServerConfigOverrides } from "../config.js";
import { type ILogger } from "../logger.js";
import { type IClient } from "./client.js";
import { type MessageHandler } from "./messageHandler/index.js";
import { type IRealm } from "./realm.js";
import { type RoomAuthorizer } from "./roomRegistry.js";
import { type TopicAuthorizer } from "./topicRegistry.js";
/** The core Conduit signaling server — transport-agnostic. */
export interface ConduitServerCore {
    /** The realm that tracks all connected clients and queued messages. */
    readonly realm: IRealm;
    /** Resolved server configuration. */
    readonly config: ServerConfig;
    /** Structured logger instance. */
    readonly logger: ILogger;
    /**
     * Process a new WebSocket connection; returns the client or `null` on rejection.
     *
     * @param address - Transport-level source address, used for ban checks. Adapters
     * that cannot determine it may omit it; ban-by-address is then not enforced.
     */
    handleConnection(socket: WebSocket, id: string, token: string, key: string, address?: string): IClient | null;
    /** Process an incoming WebSocket message from an authenticated client. */
    handleMessage(client: IClient, data: RawData | string): void;
    /** Handle a client WebSocket disconnect. */
    handleDisconnect(client: IClient): void;
    /** Generate a cryptographically random, collision-free client ID. */
    generateClientId(): string;
    /**
     * Messages produced by multicast fan-out since the process started.
     *
     * Counted where the recipient set is resolved, so it reflects actual egress
     * rather than inbound message count.
     */
    getMulticastDeliveryCount(): number;
    /** Start background maintenance tasks (heartbeat checks, message expiry). */
    start(): void;
    /** Stop all background tasks and release resources. */
    stop(): void;
}
/**
 * Decides whether a connection attempt is banned.
 *
 * Supplied by the host application -- typically `@conduit/admin`, which owns the
 * ban list. The server deliberately holds no ban state of its own: admin is an
 * optional dependency, and duplicating the list here would create a sync problem.
 *
 * @param clientId - Peer ID the connection is claiming.
 * @param address - Transport-level source address, when the adapter knows it.
 * @returns `true` to refuse the connection.
 */
export type BanPredicate = (clientId: string, address?: string) => boolean;
export type { RoomAuthorizer } from "./roomRegistry.js";
export type { TopicAuthorizer } from "./topicRegistry.js";
/** Options accepted by {@link createConduitServerCore}. */
export interface CreateConduitServerCoreOptions {
    /**
     * Server configuration overrides, merged with the defaults.
     *
     * Nested sections are themselves partial, matching what `createConfig`
     * actually does.
     */
    config?: ServerConfigOverrides;
    /** Custom message handler; uses {@link DefaultMessageHandler} when omitted. */
    messageHandler?: MessageHandler;
    /** Callback invoked when a client successfully connects. */
    onClientConnect?: (client: IClient) => void;
    /** Callback invoked when a client disconnects. */
    onClientDisconnect?: (clientId: string) => void;
    /**
     * Optional ban check consulted before a client is admitted. When omitted the
     * server admits clients as normal.
     */
    isBanned?: BanPredicate;
    /**
     * Distributed realm backend.
     *
     * Omit for the default single-process behaviour. Build one with
     * `createClusterBackend(config)` to share peer routing, room membership, and
     * subscriptions across instances — which is also what makes cross-instance
     * 1:1 signaling work.
     */
    cluster?: ClusterBackend;
    /**
     * Optional room authorization decision, consulted before a peer is admitted.
     *
     * Shaped after {@link BanPredicate}: absent by default, in which case any
     * authenticated peer may join any room, matching the trust model where the
     * signaling key is the only gate. Embedders needing multi-tenancy supply one.
     */
    authorizeRoom?: RoomAuthorizer;
    /**
     * Optional topic authorization decision, consulted before a subscription is
     * recorded and before a publication is accepted.
     *
     * Absent by default, matching {@link authorizeRoom}.
     */
    authorizeTopic?: TopicAuthorizer;
    /**
     * Permit the well-known default signaling key.
     *
     * Local development only. Without this, creating the core throws when the
     * key is missing or is the public default.
     */
    allowInsecureKey?: boolean;
}
/** Create a new transport-agnostic Conduit signaling server core. */
export declare function createConduitServerCore(options?: CreateConduitServerCoreOptions): ConduitServerCore;
export { Client, type IClient } from "./client.js";
export { DefaultMessageHandler, type MessageHandler } from "./messageHandler/index.js";
export { type IMessageQueue, MessageQueue } from "./messageQueue.js";
export { type IRealm, Realm } from "./realm.js";
//# sourceMappingURL=index.d.ts.map