import { type IMessage } from "@conduit/shared";
import type { ServerConfig } from "../../../config.js";
import type { IClient } from "../../client.js";
import type { IRateLimiter } from "../../rateLimiter.js";
import type { IRealm } from "../../realm.js";
import type { RoomRegistry } from "../../roomRegistry.js";
import type { TopicRegistry } from "../../topicRegistry.js";
/** Handle a request to subscribe to a topic or prefix pattern. */
export declare function handleSubscribe(client: IClient, message: IMessage, config: ServerConfig, topics: TopicRegistry): Promise<void>;
/** Handle a request to remove a subscription. */
export declare function handleUnsubscribe(client: IClient, message: IMessage, topics: TopicRegistry): Promise<void>;
/** Handle a publication addressed to a topic. */
export declare function handlePublish(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig, topics: TopicRegistry, rateLimiter: IRateLimiter | null): Promise<void>;
/** Handle a broadcast addressed to a room's members. */
export declare function handleRoomBroadcast(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig, rooms: RoomRegistry, rateLimiter: IRateLimiter | null): Promise<void>;
//# sourceMappingURL=topic.d.ts.map