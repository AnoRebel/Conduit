import { MessageType } from "@conduit/shared";
import { deliverAcrossCluster, ensureValidDestination } from "../../delivery.js";
export function handleTransmission(client, message, realm) {
    const { type, dst, payload } = message;
    if (!dst) {
        return;
    }
    if (!ensureValidDestination(client, dst)) {
        return;
    }
    // Resolved across the cluster: a destination on another instance is
    // forwarded to its owning node, and only a peer no node claims is queued.
    // Local delivery never consults the backend, so the common case is
    // unchanged. Fire-and-forget, matching how sends already behave.
    void deliverAcrossCluster(realm, { type, src: client.id, dst, payload }, dst, client.id);
}
export function handleOffer(client, message, realm) {
    handleTransmission(client, message, realm);
}
export function handleAnswer(client, message, realm) {
    handleTransmission(client, message, realm);
}
export function handleCandidate(client, message, realm) {
    handleTransmission(client, message, realm);
}
export function handleLeave(client, message, realm) {
    const { dst } = message;
    if (!dst) {
        return;
    }
    const destinationClient = realm.getClient(dst);
    if (destinationClient) {
        destinationClient.send({
            type: MessageType.LEAVE,
            src: client.id,
            dst,
        });
    }
}
//# sourceMappingURL=transmission.js.map