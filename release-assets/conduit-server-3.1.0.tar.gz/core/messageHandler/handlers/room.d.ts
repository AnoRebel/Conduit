import { type IMessage } from "@conduit/shared";
import type { ServerConfig } from "../../../config.js";
import type { IClient } from "../../client.js";
import type { IRateLimiter } from "../../rateLimiter.js";
import type { IRealm } from "../../realm.js";
import type { RoomRegistry } from "../../roomRegistry.js";
/** Handle a request to join a room. */
export declare function handleJoin(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig, registry: RoomRegistry, rateLimiter: IRateLimiter | null): Promise<void>;
/** Handle a request to leave a room. */
export declare function handleLeaveRoom(client: IClient, message: IMessage, realm: IRealm, config: ServerConfig, registry: RoomRegistry, rateLimiter: IRateLimiter | null): Promise<void>;
/**
 * Announce that a peer has left every room it occupied.
 *
 * Used when a connection is reaped rather than left explicitly, so remaining
 * members are told regardless of how the peer departed.
 */
export declare function announceDeparture(realm: IRealm, config: ServerConfig, registry: RoomRegistry, rateLimiter: IRateLimiter | null, peerId: string): Promise<void>;
//# sourceMappingURL=room.d.ts.map