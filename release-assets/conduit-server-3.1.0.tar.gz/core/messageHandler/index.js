import { MessageType } from "@conduit/shared";
import { handleHeartbeat } from "./handlers/heartbeat.js";
import { handleRelay, handleRelayClose, handleRelayOpen } from "./handlers/relay.js";
import { handleJoin, handleLeaveRoom } from "./handlers/room.js";
import { handlePublish, handleRoomBroadcast, handleSubscribe, handleUnsubscribe, } from "./handlers/topic.js";
import { handleAnswer, handleCandidate, handleLeave, handleOffer, } from "./handlers/transmission.js";
/** Built-in {@link MessageHandler} that dispatches messages by {@link MessageType}. */
export class DefaultMessageHandler {
    realm;
    config;
    rooms;
    rateLimiter;
    topics;
    constructor(realm, config, rooms, rateLimiter, topics) {
        this.realm = realm;
        this.config = config;
        this.rooms = rooms;
        this.rateLimiter = rateLimiter;
        this.topics = topics;
    }
    /** Route a message from the given client to the appropriate handler based on its {@link MessageType}. */
    handle(client, message) {
        const { type } = message;
        switch (type) {
            case MessageType.HEARTBEAT:
                handleHeartbeat(client);
                break;
            case MessageType.OFFER:
                handleOffer(client, message, this.realm);
                break;
            case MessageType.ANSWER:
                handleAnswer(client, message, this.realm);
                break;
            case MessageType.CANDIDATE:
                handleCandidate(client, message, this.realm);
                break;
            case MessageType.LEAVE:
                handleLeave(client, message, this.realm);
                break;
            case MessageType.RELAY:
                handleRelay(client, message, this.realm, this.config);
                break;
            case MessageType.RELAY_OPEN:
                handleRelayOpen(client, message, this.realm, this.config);
                break;
            case MessageType.RELAY_CLOSE:
                handleRelayClose(client, message, this.realm, this.config);
                break;
            case MessageType.JOIN:
                // Room handling is asynchronous because membership may live in a
                // shared backend. The dispatcher stays synchronous and lets the
                // promise settle on its own, exactly as sends already do.
                if (this.rooms) {
                    void handleJoin(client, message, this.realm, this.config, this.rooms, this.rateLimiter ?? null);
                }
                break;
            case MessageType.LEAVE_ROOM:
                if (this.rooms) {
                    void handleLeaveRoom(client, message, this.realm, this.config, this.rooms, this.rateLimiter ?? null);
                }
                break;
            case MessageType.SUBSCRIBE:
                if (this.topics) {
                    void handleSubscribe(client, message, this.config, this.topics);
                }
                break;
            case MessageType.UNSUBSCRIBE:
                if (this.topics) {
                    void handleUnsubscribe(client, message, this.topics);
                }
                break;
            case MessageType.PUBLISH:
                if (this.topics) {
                    void handlePublish(client, message, this.realm, this.config, this.topics, this.rateLimiter ?? null);
                }
                break;
            case MessageType.ROOM_BROADCAST:
                if (this.rooms) {
                    void handleRoomBroadcast(client, message, this.realm, this.config, this.rooms, this.rateLimiter ?? null);
                }
                break;
            default:
                // Unknown message type, ignore
                break;
        }
    }
}
//# sourceMappingURL=index.js.map