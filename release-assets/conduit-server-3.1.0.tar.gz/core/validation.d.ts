/** Maximum allowed client ID length. */
export declare const MAX_ID_LENGTH = 64;
/** Maximum allowed connection token length. */
export declare const MAX_TOKEN_LENGTH = 64;
/** Maximum allowed API key length. */
export declare const MAX_KEY_LENGTH = 64;
/** Default maximum message size in bytes (64 KB). */
export declare const MAX_MESSAGE_SIZE: number;
/** Maximum allowed nesting depth for message payloads. */
export declare const MAX_PAYLOAD_DEPTH = 10;
/** Maximum allowed room name length. */
export declare const MAX_ROOM_NAME_LENGTH = 128;
/** Maximum allowed topic name length. */
export declare const MAX_TOPIC_NAME_LENGTH = 128;
/** Maximum number of dot-delimited segments in a topic name. */
export declare const MAX_TOPIC_SEGMENTS = 8;
/** Result of a validation check — `valid: true` or `valid: false` with an error message. */
export interface ValidationResult {
    /** Whether validation passed. */
    valid: boolean;
    /** Human-readable error message when `valid` is `false`. */
    error?: string;
}
/**
 * Validate a client ID
 */
export declare function validateId(id: unknown): ValidationResult;
/**
 * Validate a connection token
 */
export declare function validateToken(token: unknown): ValidationResult;
/**
 * Validate an API key
 */
export declare function validateKey(key: unknown): ValidationResult;
/**
 * Validate a room name.
 *
 * Rejects by allowlist rather than denylist so an unanticipated character
 * cannot slip through.
 */
export declare function validateRoomName(room: unknown): ValidationResult;
/**
 * Validate a concrete topic name.
 *
 * A published topic is always literal: wildcards belong to subscriptions only,
 * so accepting one here would let a publisher address a whole namespace.
 */
export declare function validateTopicName(topic: unknown): ValidationResult;
/**
 * Validate a topic subscription pattern.
 *
 * Accepts an exact name, or a namespace prefix ending in `.*`. No other
 * wildcard form is supported: arbitrary glob matching would make subscriber
 * resolution scale with the total number of subscriptions, which is itself a
 * denial-of-service vector, and compiling user patterns to regex invites
 * catastrophic backtracking.
 */
export declare function validateTopicPattern(pattern: unknown): ValidationResult;
/**
 * Validate a message structure
 */
export declare function validateMessage(message: unknown, _maxSize?: number): ValidationResult;
/**
 * Validate message payload has required destination
 */
export declare function validatePayloadDestination(payload: unknown): ValidationResult;
/**
 * Safely parse JSON with size limits
 */
export declare function safeJsonParse(text: string, maxSize?: number): {
    success: true;
    data: unknown;
} | {
    success: false;
    error: string;
};
//# sourceMappingURL=validation.d.ts.map