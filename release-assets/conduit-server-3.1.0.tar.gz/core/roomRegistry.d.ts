import type { ClusterBackend, PeerLocation } from "../cluster/types.js";
import type { ServerConfig } from "../config.js";
/** Why a join was refused. */
export type JoinRefusal = "rooms-disabled" | "room-full" | "peer-room-limit" | "server-room-limit" | "unauthorized";
/** Outcome of a join attempt. */
export type JoinResult = {
    ok: true;
    alreadyMember: boolean;
    members: readonly PeerLocation[];
} | {
    ok: false;
    refusal: JoinRefusal;
};
/** Outcome of a leave attempt. */
export type LeaveResult = {
    ok: true;
} | {
    ok: false;
    refusal: "not-a-member";
};
/**
 * Decides whether a peer may join a room.
 *
 * Supplied by the host application, exactly like the existing ban predicate:
 * absent by default, in which case any authenticated peer may join any room.
 * Synchronous by design — an async hook would put an await in the message path
 * and open a queue-depth amplification vector of its own.
 *
 * @returns `false` to refuse the join.
 */
export type RoomAuthorizer = (peerId: string, room: string) => boolean;
/**
 * Room membership, presence, and the limits that bound them.
 *
 * State lives in the {@link ClusterBackend} rather than in a map here. That is
 * deliberate: duplicating it would mean two sources of truth that drift the
 * moment a second instance joins, and the backend already maintains both the
 * forward (room -> members) and reverse (peer -> rooms) indexes this needs. The
 * reverse index is what makes disconnect cleanup O(rooms held by that peer)
 * rather than a scan of every room.
 */
export declare class RoomRegistry {
    private readonly backend;
    private readonly config;
    private readonly authorize?;
    constructor(backend: ClusterBackend, config: ServerConfig, authorize?: RoomAuthorizer | undefined);
    /**
     * Add a peer to a room, enforcing every limit and the authorization hook.
     *
     * Checks run before any state changes, so a refused join leaves nothing
     * behind and notifies nobody.
     */
    join(peerId: string, room: string): Promise<JoinResult>;
    /** Remove a peer from a room it belongs to. */
    leave(peerId: string, room: string): Promise<LeaveResult>;
    /** Members of a room, across every instance. */
    members(room: string): Promise<readonly PeerLocation[]>;
    /** Members of a room other than the given peer. */
    otherMembers(room: string, peerId: string): Promise<readonly PeerLocation[]>;
    /** Whether a peer belongs to a room. */
    isMember(peerId: string, room: string): Promise<boolean>;
    /** Rooms a peer currently occupies. */
    roomsOf(peerId: string): Promise<readonly string[]>;
    /** Number of rooms in existence. */
    count(): Promise<number>;
}
//# sourceMappingURL=roomRegistry.d.ts.map