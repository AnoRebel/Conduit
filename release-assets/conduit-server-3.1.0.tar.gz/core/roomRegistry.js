/**
 * Room membership, presence, and the limits that bound them.
 *
 * State lives in the {@link ClusterBackend} rather than in a map here. That is
 * deliberate: duplicating it would mean two sources of truth that drift the
 * moment a second instance joins, and the backend already maintains both the
 * forward (room -> members) and reverse (peer -> rooms) indexes this needs. The
 * reverse index is what makes disconnect cleanup O(rooms held by that peer)
 * rather than a scan of every room.
 */
export class RoomRegistry {
    backend;
    config;
    authorize;
    constructor(backend, config, authorize) {
        this.backend = backend;
        this.config = config;
        this.authorize = authorize;
    }
    /**
     * Add a peer to a room, enforcing every limit and the authorization hook.
     *
     * Checks run before any state changes, so a refused join leaves nothing
     * behind and notifies nobody.
     */
    async join(peerId, room) {
        if (!this.config.rooms.enabled) {
            return { ok: false, refusal: "rooms-disabled" };
        }
        // Authorization is consulted before anything is disclosed or recorded, so
        // a denied peer learns nothing about whether the room exists.
        if (this.authorize && !this.authorize(peerId, room)) {
            return { ok: false, refusal: "unauthorized" };
        }
        const currentRooms = await this.backend.getPeerRooms(peerId);
        const alreadyMember = currentRooms.includes(room);
        if (!alreadyMember) {
            if (currentRooms.length >= this.config.rooms.maxRoomsPerPeer) {
                return { ok: false, refusal: "peer-room-limit" };
            }
            // Only a join that creates a room counts against the server-wide cap.
            const existing = await this.backend.getRoomMembers(room);
            if (existing.length === 0) {
                const roomCount = await this.backend.countRooms();
                if (roomCount >= this.config.rooms.maxRooms) {
                    return { ok: false, refusal: "server-room-limit" };
                }
            }
        }
        // The capacity check and insert are one atomic operation in the backend:
        // a read-then-write here would let peers joining different instances race
        // past the member cap.
        const admitted = await this.backend.joinRoom(room, peerId, this.config.rooms.maxMembersPerRoom);
        if (!admitted) {
            return { ok: false, refusal: "room-full" };
        }
        // Membership as it stands after the join, minus the joiner itself.
        const members = (await this.backend.getRoomMembers(room)).filter(m => m.peerId !== peerId);
        return { ok: true, alreadyMember, members };
    }
    /** Remove a peer from a room it belongs to. */
    async leave(peerId, room) {
        const currentRooms = await this.backend.getPeerRooms(peerId);
        if (!currentRooms.includes(room)) {
            return { ok: false, refusal: "not-a-member" };
        }
        await this.backend.leaveRoom(room, peerId);
        return { ok: true };
    }
    /** Members of a room, across every instance. */
    async members(room) {
        return await this.backend.getRoomMembers(room);
    }
    /** Members of a room other than the given peer. */
    async otherMembers(room, peerId) {
        return (await this.backend.getRoomMembers(room)).filter(m => m.peerId !== peerId);
    }
    /** Whether a peer belongs to a room. */
    async isMember(peerId, room) {
        return (await this.backend.getPeerRooms(peerId)).includes(room);
    }
    /** Rooms a peer currently occupies. */
    async roomsOf(peerId) {
        return await this.backend.getPeerRooms(peerId);
    }
    /** Number of rooms in existence. */
    async count() {
        return await this.backend.countRooms();
    }
}
//# sourceMappingURL=roomRegistry.js.map