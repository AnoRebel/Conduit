/**
 * @module @conduit/server
 *
 * WebRTC signaling server for Conduit. Provides the core server logic
 * and adapters for Node.js, Bun, Hono, Express, and Fastify.
 *
 * @example
 * ```typescript
 * import { createConduitServer } from '@conduit/server/adapters/node';
 *
 * const server = createConduitServer({ config: { port: 9000 } });
 * server.listen();
 * ```
 */
// ============================================================================
// Re-export shared types and enums
// ============================================================================
export { 
// Enums
ConduitErrorType, ConnectionType, MessageType, SerializationType, TransportType, } from "@conduit/shared";
// ============================================================================
// Server Configuration
// ============================================================================
export { assertSecureClusterBackend, assertSecureKey, createConfig, defaultConfig, INSECURE_DEFAULT_KEY, isKeyAcceptable, } from "./config.js";
// ============================================================================
// Logger
// ============================================================================
export { createChildLogger, createLogger, getLogger, logger, wrapLogger, } from "./logger.js";
// ============================================================================
// Core Server Components
// ============================================================================
// Client and realm management
export { Client } from "./core/client.js";
export { getMulticastDeliveryCount, resetMulticastDeliveryCount, } from "./core/delivery.js";
export { createConduitServerCore, } from "./core/index.js";
// Message handling
export { DefaultMessageHandler } from "./core/messageHandler/index.js";
export { MessageQueue } from "./core/messageQueue.js";
export { Realm } from "./core/realm.js";
// ============================================================================
// Cluster (distributed realm)
// ============================================================================
export { createClusterBackend, InMemoryClusterBackend, RedisClusterBackend, } from "./cluster/index.js";
// ============================================================================
// Server Adapters
// ============================================================================
// Express adapter
export { ExpressConduitServer } from "./adapters/express.js";
// Fastify adapter
export { fastifyConduitPlugin } from "./adapters/fastify.js";
// Default adapter (Node HTTP)
export { createConduitServer, } from "./adapters/node.js";
// ============================================================================
// Validation utilities (for custom implementations)
// ============================================================================
export { MAX_ID_LENGTH, MAX_KEY_LENGTH, MAX_MESSAGE_SIZE, MAX_PAYLOAD_DEPTH, MAX_ROOM_NAME_LENGTH, MAX_TOKEN_LENGTH, MAX_TOPIC_NAME_LENGTH, MAX_TOPIC_SEGMENTS, safeJsonParse, validateId, validateKey, validateMessage, validatePayloadDestination, validateRoomName, validateToken, validateTopicName, validateTopicPattern, } from "./core/validation.js";
//# sourceMappingURL=index.js.map