import type { BackendHealth, ClusterBackend, ForwardedEnvelope, ForwardHandler, PeerLocation } from "./types.js";
/** Options for {@link InMemoryClusterBackend}. */
export interface InMemoryClusterBackendOptions {
    /** Node identifier. Generated when omitted. */
    nodeId?: string;
}
/**
 * Single-node backend holding all state in this process.
 *
 * The default, and behaviourally identical to the server before distribution
 * existed: every peer is local, so `lookupPeerNode` always answers with this
 * node and `forward` is never reached.
 *
 * It exists so the distributed code path is the only code path. A server with
 * no backend configured runs the same resolution logic as a clustered one,
 * which keeps the two from diverging.
 */
export declare class InMemoryClusterBackend implements ClusterBackend {
    readonly nodeId: string;
    readonly distributed = false;
    private readonly _peers;
    private readonly _rooms;
    private readonly _peerRooms;
    private readonly _topics;
    private readonly _peerTopics;
    constructor(options?: InMemoryClusterBackendOptions);
    registerPeer(peerId: string, token: string): Promise<void>;
    unregisterPeer(peerId: string): Promise<void>;
    refreshPeer(_peerId: string): Promise<void>;
    lookupPeerNode(peerId: string): Promise<string | null>;
    forward(nodeId: string, _envelope: ForwardedEnvelope): Promise<void>;
    joinRoom(room: string, peerId: string, maxMembers: number): Promise<boolean>;
    leaveRoom(room: string, peerId: string): Promise<void>;
    getRoomMembers(room: string): Promise<readonly PeerLocation[]>;
    getPeerRooms(peerId: string): Promise<readonly string[]>;
    countRooms(): Promise<number>;
    subscribe(topic: string, peerId: string, maxSubscribers: number): Promise<boolean>;
    unsubscribe(topic: string, peerId: string): Promise<void>;
    getTopicSubscribers(topic: string): Promise<readonly PeerLocation[]>;
    getPeerSubscriptions(peerId: string): Promise<readonly string[]>;
    countTopics(): Promise<number>;
    releasePeer(peerId: string): Promise<void>;
    onForwarded(_handler: ForwardHandler): void;
    getNodes(): Promise<readonly {
        nodeId: string;
        peers: number;
    }[]>;
    health(): Promise<BackendHealth>;
    start(): Promise<void>;
    stop(): Promise<void>;
}
//# sourceMappingURL=memory.d.ts.map