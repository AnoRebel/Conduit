import { randomBytes } from "node:crypto";
/**
 * Single-node backend holding all state in this process.
 *
 * The default, and behaviourally identical to the server before distribution
 * existed: every peer is local, so `lookupPeerNode` always answers with this
 * node and `forward` is never reached.
 *
 * It exists so the distributed code path is the only code path. A server with
 * no backend configured runs the same resolution logic as a clustered one,
 * which keeps the two from diverging.
 */
export class InMemoryClusterBackend {
    nodeId;
    distributed = false;
    _peers = new Map();
    _rooms = new Map();
    _peerRooms = new Map();
    _topics = new Map();
    _peerTopics = new Map();
    constructor(options = {}) {
        this.nodeId = options.nodeId ?? `node-${randomBytes(6).toString("hex")}`;
    }
    async registerPeer(peerId, token) {
        this._peers.set(peerId, token);
    }
    async unregisterPeer(peerId) {
        this._peers.delete(peerId);
    }
    async refreshPeer(_peerId) {
        // No TTL in a single process: nothing can expire behind our back.
    }
    async lookupPeerNode(peerId) {
        return this._peers.has(peerId) ? this.nodeId : null;
    }
    async forward(nodeId, _envelope) {
        // Unreachable in a one-node cluster: every peer resolves locally. Throwing
        // surfaces a routing bug rather than silently dropping a message.
        throw new Error(`InMemoryClusterBackend cannot forward to node ${nodeId}`);
    }
    async joinRoom(room, peerId, maxMembers) {
        const members = this._rooms.get(room) ?? new Set();
        // Idempotent: re-joining a room already joined succeeds without a second
        // membership and without consuming capacity.
        if (!members.has(peerId) && members.size >= maxMembers) {
            return false;
        }
        members.add(peerId);
        this._rooms.set(room, members);
        const rooms = this._peerRooms.get(peerId) ?? new Set();
        rooms.add(room);
        this._peerRooms.set(peerId, rooms);
        return true;
    }
    async leaveRoom(room, peerId) {
        const members = this._rooms.get(room);
        if (members) {
            members.delete(peerId);
            // A room with no members ceases to exist.
            if (members.size === 0) {
                this._rooms.delete(room);
            }
        }
        const rooms = this._peerRooms.get(peerId);
        if (rooms) {
            rooms.delete(room);
            if (rooms.size === 0) {
                this._peerRooms.delete(peerId);
            }
        }
    }
    async getRoomMembers(room) {
        const members = this._rooms.get(room);
        if (!members) {
            return [];
        }
        return Array.from(members, peerId => ({ peerId, nodeId: this.nodeId }));
    }
    async getPeerRooms(peerId) {
        return Array.from(this._peerRooms.get(peerId) ?? []);
    }
    async countRooms() {
        return this._rooms.size;
    }
    async subscribe(topic, peerId, maxSubscribers) {
        const subscribers = this._topics.get(topic) ?? new Set();
        if (!subscribers.has(peerId) && subscribers.size >= maxSubscribers) {
            return false;
        }
        subscribers.add(peerId);
        this._topics.set(topic, subscribers);
        const topics = this._peerTopics.get(peerId) ?? new Set();
        topics.add(topic);
        this._peerTopics.set(peerId, topics);
        return true;
    }
    async unsubscribe(topic, peerId) {
        const subscribers = this._topics.get(topic);
        if (subscribers) {
            subscribers.delete(peerId);
            if (subscribers.size === 0) {
                this._topics.delete(topic);
            }
        }
        const topics = this._peerTopics.get(peerId);
        if (topics) {
            topics.delete(topic);
            if (topics.size === 0) {
                this._peerTopics.delete(peerId);
            }
        }
    }
    async getTopicSubscribers(topic) {
        const subscribers = this._topics.get(topic);
        if (!subscribers) {
            return [];
        }
        return Array.from(subscribers, peerId => ({ peerId, nodeId: this.nodeId }));
    }
    async getPeerSubscriptions(peerId) {
        return Array.from(this._peerTopics.get(peerId) ?? []);
    }
    async countTopics() {
        return this._topics.size;
    }
    async releasePeer(peerId) {
        for (const room of this._peerRooms.get(peerId) ?? []) {
            const members = this._rooms.get(room);
            members?.delete(peerId);
            if (members && members.size === 0) {
                this._rooms.delete(room);
            }
        }
        this._peerRooms.delete(peerId);
        for (const topic of this._peerTopics.get(peerId) ?? []) {
            const subscribers = this._topics.get(topic);
            subscribers?.delete(peerId);
            if (subscribers && subscribers.size === 0) {
                this._topics.delete(topic);
            }
        }
        this._peerTopics.delete(peerId);
        this._peers.delete(peerId);
    }
    onForwarded(_handler) {
        // Nothing ever arrives from another node.
    }
    async getNodes() {
        return [{ nodeId: this.nodeId, peers: this._peers.size }];
    }
    async health() {
        // Always reachable: there is nothing to be unreachable.
        return { reachable: true };
    }
    async start() {
        // No background work.
    }
    async stop() {
        this._peers.clear();
        this._rooms.clear();
        this._peerRooms.clear();
        this._topics.clear();
        this._peerTopics.clear();
    }
}
//# sourceMappingURL=memory.js.map