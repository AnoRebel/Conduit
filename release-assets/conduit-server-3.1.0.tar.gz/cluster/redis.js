import { randomBytes } from "node:crypto";
/**
 * Atomically add a member to a set only when doing so stays within capacity.
 *
 * A read-then-write from each node would let concurrent joins race past the
 * limit. Returning 1 for an existing member keeps re-joining idempotent without
 * consuming capacity.
 */
const ADD_IF_ROOM = `
if redis.call('SISMEMBER', KEYS[1], ARGV[1]) == 1 then
  return 1
end
if redis.call('SCARD', KEYS[1]) >= tonumber(ARGV[2]) then
  return 0
end
redis.call('SADD', KEYS[1], ARGV[1])
return 1
`;
/** Remove a member and delete the set when it becomes empty. */
const REMOVE_AND_GC = `
redis.call('SREM', KEYS[1], ARGV[1])
if redis.call('SCARD', KEYS[1]) == 0 then
  redis.call('DEL', KEYS[1])
end
return 1
`;
/**
 * Distributed backend sharing realm state through Redis.
 *
 * Peer routing and membership live in Redis keys; inter-node messages travel on
 * a per-node pub/sub channel. Peer registrations carry a TTL refreshed by the
 * existing heartbeat, so a node that dies without cleanup has its peers expire
 * within a bounded window rather than being stranded.
 */
export class RedisClusterBackend {
    nodeId;
    distributed = true;
    _prefix;
    _ttl;
    _client;
    _subscriber;
    _handler = null;
    _lastError;
    constructor(options) {
        this.nodeId = options.nodeId ?? `node-${randomBytes(6).toString("hex")}`;
        this._prefix = options.config.keyPrefix;
        this._ttl = options.peerTtlSeconds;
        const client = options.client ?? options.createClient?.(options.config);
        if (!client) {
            throw new Error("RedisClusterBackend requires a client or createClient factory. " +
                "Install the optional 'ioredis' dependency to use the redis backend.");
        }
        this._client = client;
        this._subscriber = client.duplicate();
        this._client.defineCommand("addIfRoom", { numberOfKeys: 1, lua: ADD_IF_ROOM });
        this._client.defineCommand("removeAndGc", { numberOfKeys: 1, lua: REMOVE_AND_GC });
        for (const c of [this._client, this._subscriber]) {
            // The structural RedisLike.on is intentionally loose; narrow at the
            // call site rather than widening the interface to `any`.
            const onError = (error) => {
                this._lastError = error instanceof Error ? error.message : String(error);
            };
            c.on("error", onError);
        }
    }
    // -- key layout -----------------------------------------------------------
    _peerKey(peerId) {
        return `${this._prefix}:peer:${peerId}`;
    }
    _roomKey(room) {
        return `${this._prefix}:room:${room}`;
    }
    _peerRoomsKey(peerId) {
        return `${this._prefix}:peer-rooms:${peerId}`;
    }
    _topicKey(topic) {
        return `${this._prefix}:topic:${topic}`;
    }
    _peerTopicsKey(peerId) {
        return `${this._prefix}:peer-topics:${peerId}`;
    }
    _nodeChannel(nodeId) {
        return `${this._prefix}:node:${nodeId}`;
    }
    _nodePeersKey(nodeId) {
        return `${this._prefix}:node-peers:${nodeId}`;
    }
    // -- peers ----------------------------------------------------------------
    async registerPeer(peerId, _token) {
        await this._client.set(this._peerKey(peerId), this.nodeId, "EX", this._ttl);
        await this._client.sadd(this._nodePeersKey(this.nodeId), peerId);
    }
    async unregisterPeer(peerId) {
        await this._client.del(this._peerKey(peerId));
        await this._client.srem(this._nodePeersKey(this.nodeId), peerId);
    }
    async refreshPeer(peerId) {
        // Re-set with the TTL rather than EXPIRE so a registration that already
        // lapsed is reclaimed by the node still holding the socket.
        await this._client.set(this._peerKey(peerId), this.nodeId, "EX", this._ttl);
    }
    async lookupPeerNode(peerId) {
        return await this._client.get(this._peerKey(peerId));
    }
    // -- forwarding -----------------------------------------------------------
    async forward(nodeId, envelope) {
        await this._client.publish(this._nodeChannel(nodeId), JSON.stringify(envelope));
    }
    onForwarded(handler) {
        this._handler = handler;
    }
    /**
     * Validate and dispatch one inbound inter-node message.
     *
     * Exposed for tests. Inter-node traffic is untrusted input: anyone able to
     * publish to the channel could otherwise claim to be any peer, so the
     * sending node must actually own the peer it speaks for.
     */
    async handleForwarded(raw) {
        let envelope;
        try {
            const parsed = JSON.parse(raw);
            if (!isEnvelope(parsed)) {
                return;
            }
            envelope = parsed;
        }
        catch {
            // Malformed input must not disturb other cluster traffic.
            return;
        }
        // A node may only speak for peers it owns.
        const owner = await this.lookupPeerNode(envelope.srcPeerId).catch(() => null);
        if (owner !== null && owner !== envelope.fromNodeId) {
            return;
        }
        this._handler?.(envelope);
    }
    // -- rooms ----------------------------------------------------------------
    async joinRoom(room, peerId, maxMembers) {
        const added = (await this._client.addIfRoom(this._roomKey(room), peerId, String(maxMembers)));
        if (added !== 1) {
            return false;
        }
        await this._client.sadd(this._peerRoomsKey(peerId), room);
        return true;
    }
    async leaveRoom(room, peerId) {
        await this._client.removeAndGc(this._roomKey(room), peerId);
        await this._client.srem(this._peerRoomsKey(peerId), room);
    }
    async getRoomMembers(room) {
        const members = await this._client.smembers(this._roomKey(room));
        return await this._locate(members);
    }
    async getPeerRooms(peerId) {
        return await this._client.smembers(this._peerRoomsKey(peerId));
    }
    async countRooms() {
        return await this._countKeys(`${this._prefix}:room:*`);
    }
    // -- topics ---------------------------------------------------------------
    async subscribe(topic, peerId, maxSubscribers) {
        const added = (await this._client.addIfRoom(this._topicKey(topic), peerId, String(maxSubscribers)));
        if (added !== 1) {
            return false;
        }
        await this._client.sadd(this._peerTopicsKey(peerId), topic);
        return true;
    }
    async unsubscribe(topic, peerId) {
        await this._client.removeAndGc(this._topicKey(topic), peerId);
        await this._client.srem(this._peerTopicsKey(peerId), topic);
    }
    async getTopicSubscribers(topic) {
        const subscribers = await this._client.smembers(this._topicKey(topic));
        return await this._locate(subscribers);
    }
    async getPeerSubscriptions(peerId) {
        return await this._client.smembers(this._peerTopicsKey(peerId));
    }
    async countTopics() {
        return await this._countKeys(`${this._prefix}:topic:*`);
    }
    // -- lifecycle ------------------------------------------------------------
    async releasePeer(peerId) {
        for (const room of await this.getPeerRooms(peerId)) {
            await this.leaveRoom(room, peerId);
        }
        for (const topic of await this.getPeerSubscriptions(peerId)) {
            await this.unsubscribe(topic, peerId);
        }
        await this._client.del(this._peerRoomsKey(peerId), this._peerTopicsKey(peerId));
        await this.unregisterPeer(peerId);
    }
    async getNodes() {
        const keys = await this._scan(`${this._prefix}:node-peers:*`);
        const nodes = [];
        for (const key of keys) {
            const nodeId = key.slice(`${this._prefix}:node-peers:`.length);
            nodes.push({ nodeId, peers: await this._client.scard(key) });
        }
        return nodes;
    }
    async health() {
        try {
            await this._client.ping();
            this._lastError = undefined;
            return { reachable: true };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            return { reachable: false, error: message };
        }
    }
    async start() {
        await this._subscriber.subscribe(this._nodeChannel(this.nodeId));
        const onMessage = (channel, payload) => {
            if (channel === this._nodeChannel(this.nodeId)) {
                void this.handleForwarded(payload);
            }
        };
        this._subscriber.on("message", onMessage);
    }
    async stop() {
        // Release this node's peers so surviving nodes see the departure at once
        // rather than waiting out the TTL.
        const owned = await this._client.smembers(this._nodePeersKey(this.nodeId));
        for (const peerId of owned) {
            await this.releasePeer(peerId);
        }
        await this._client.del(this._nodePeersKey(this.nodeId));
        await this._subscriber.quit().catch(() => undefined);
        await this._client.quit().catch(() => undefined);
    }
    /**
     * Publish a raw payload onto a node's channel.
     *
     * Exposed so tests can drive malformed and forged inter-node traffic through
     * the same path a real node would use; production code should use
     * {@link forward}.
     */
    async publishRaw(nodeId, payload) {
        await this._client.publish(this._nodeChannel(nodeId), payload);
    }
    /** The most recent connection error, if any. */
    get lastError() {
        return this._lastError;
    }
    // -- helpers --------------------------------------------------------------
    /**
     * Resolve owning nodes for a set of peers.
     *
     * A peer whose registration has expired is omitted: its node is gone, so
     * delivering to it would be delivering into a void.
     */
    async _locate(peerIds) {
        const located = [];
        for (const peerId of peerIds) {
            const nodeId = await this.lookupPeerNode(peerId);
            if (nodeId !== null) {
                located.push({ peerId, nodeId });
            }
        }
        return located;
    }
    async _scan(pattern) {
        // SCAN rather than KEYS: KEYS blocks the server for the whole keyspace.
        const scan = this._client.scan.bind(this._client);
        const found = [];
        let cursor = "0";
        do {
            const [next, keys] = await scan(cursor, "MATCH", pattern, "COUNT", "200");
            found.push(...keys);
            cursor = next;
        } while (cursor !== "0");
        return found;
    }
    async _countKeys(pattern) {
        return (await this._scan(pattern)).length;
    }
}
/** Structural check for an inbound envelope, before anything trusts it. */
function isEnvelope(value) {
    if (typeof value !== "object" || value === null) {
        return false;
    }
    const v = value;
    return (typeof v.fromNodeId === "string" &&
        typeof v.srcPeerId === "string" &&
        Array.isArray(v.targets) &&
        v.targets.every(t => typeof t === "string") &&
        typeof v.message === "object" &&
        v.message !== null &&
        typeof v.message.type === "string");
}
//# sourceMappingURL=redis.js.map