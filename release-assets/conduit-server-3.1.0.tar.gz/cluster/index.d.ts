import { type ServerConfig, type ServerConfigOverrides } from "../config.js";
import type { ClusterBackend } from "./types.js";
export { InMemoryClusterBackend } from "./memory.js";
export { RedisClusterBackend, type RedisClusterBackendOptions, type RedisLike, } from "./redis.js";
export type { BackendHealth, ClusterBackend, ForwardedEnvelope, ForwardHandler, PeerLocation, } from "./types.js";
/**
 * A backend URL with any embedded credential removed.
 *
 * The password is normally supplied separately, but a URL of the form
 * `redis://user:secret@host` is valid and an operator may well use one. Since
 * this string reaches startup errors and logs, strip the userinfo rather than
 * trusting that nobody does.
 */
export declare function redactBackendUrl(url: string): string;
/**
 * Build the cluster backend a configuration asks for.
 *
 * Defaults to in-memory, so a server that configures nothing behaves exactly as
 * it did before distribution existed.
 */
export declare function createClusterBackend(options: ServerConfig | ServerConfigOverrides): Promise<ClusterBackend>;
//# sourceMappingURL=index.d.ts.map