import type { RedisClusterConfig } from "../config.js";
import type { BackendHealth, ClusterBackend, ForwardedEnvelope, ForwardHandler, PeerLocation } from "./types.js";
/**
 * Minimal structural view of the ioredis client this backend uses.
 *
 * Declared here rather than importing ioredis' types so the package remains an
 * optional dependency: a deployment using the in-memory backend must not need
 * it installed to typecheck or run.
 */
export interface RedisLike {
    defineCommand(name: string, definition: {
        numberOfKeys: number;
        lua: string;
    }): void;
    get(key: string): Promise<string | null>;
    set(key: string, value: string, mode: "EX", seconds: number): Promise<unknown>;
    del(...keys: string[]): Promise<number>;
    smembers(key: string): Promise<string[]>;
    srem(key: string, ...members: string[]): Promise<number>;
    scard(key: string): Promise<number>;
    publish(channel: string, payload: string): Promise<number>;
    subscribe(channel: string): Promise<unknown>;
    on(event: string, handler: (...args: never[]) => void): void;
    quit(): Promise<unknown>;
    duplicate(): RedisLike;
    status: string;
    [command: string]: unknown;
}
/** Options for {@link RedisClusterBackend}. */
export interface RedisClusterBackendOptions {
    /** Redis connection settings. */
    config: RedisClusterConfig;
    /** Seconds a peer registration survives without a heartbeat. */
    peerTtlSeconds: number;
    /** This node's identifier. Generated when omitted. */
    nodeId?: string;
    /** Pre-built client, primarily for tests. */
    client?: RedisLike;
    /** Factory used to build clients when none is supplied. */
    createClient?: (config: RedisClusterConfig) => RedisLike;
}
/**
 * Distributed backend sharing realm state through Redis.
 *
 * Peer routing and membership live in Redis keys; inter-node messages travel on
 * a per-node pub/sub channel. Peer registrations carry a TTL refreshed by the
 * existing heartbeat, so a node that dies without cleanup has its peers expire
 * within a bounded window rather than being stranded.
 */
export declare class RedisClusterBackend implements ClusterBackend {
    readonly nodeId: string;
    readonly distributed = true;
    private readonly _prefix;
    private readonly _ttl;
    private readonly _client;
    private readonly _subscriber;
    private _handler;
    private _lastError;
    constructor(options: RedisClusterBackendOptions);
    private _peerKey;
    private _roomKey;
    private _peerRoomsKey;
    private _topicKey;
    private _peerTopicsKey;
    private _nodeChannel;
    private _nodePeersKey;
    registerPeer(peerId: string, _token: string): Promise<void>;
    unregisterPeer(peerId: string): Promise<void>;
    refreshPeer(peerId: string): Promise<void>;
    lookupPeerNode(peerId: string): Promise<string | null>;
    forward(nodeId: string, envelope: ForwardedEnvelope): Promise<void>;
    onForwarded(handler: ForwardHandler): void;
    /**
     * Validate and dispatch one inbound inter-node message.
     *
     * Exposed for tests. Inter-node traffic is untrusted input: anyone able to
     * publish to the channel could otherwise claim to be any peer, so the
     * sending node must actually own the peer it speaks for.
     */
    handleForwarded(raw: string): Promise<void>;
    joinRoom(room: string, peerId: string, maxMembers: number): Promise<boolean>;
    leaveRoom(room: string, peerId: string): Promise<void>;
    getRoomMembers(room: string): Promise<readonly PeerLocation[]>;
    getPeerRooms(peerId: string): Promise<readonly string[]>;
    countRooms(): Promise<number>;
    subscribe(topic: string, peerId: string, maxSubscribers: number): Promise<boolean>;
    unsubscribe(topic: string, peerId: string): Promise<void>;
    getTopicSubscribers(topic: string): Promise<readonly PeerLocation[]>;
    getPeerSubscriptions(peerId: string): Promise<readonly string[]>;
    countTopics(): Promise<number>;
    releasePeer(peerId: string): Promise<void>;
    getNodes(): Promise<readonly {
        nodeId: string;
        peers: number;
    }[]>;
    health(): Promise<BackendHealth>;
    start(): Promise<void>;
    stop(): Promise<void>;
    /**
     * Publish a raw payload onto a node's channel.
     *
     * Exposed so tests can drive malformed and forged inter-node traffic through
     * the same path a real node would use; production code should use
     * {@link forward}.
     */
    publishRaw(nodeId: string, payload: string): Promise<void>;
    /** The most recent connection error, if any. */
    get lastError(): string | undefined;
    /**
     * Resolve owning nodes for a set of peers.
     *
     * A peer whose registration has expired is omitted: its node is gone, so
     * delivering to it would be delivering into a void.
     */
    private _locate;
    private _scan;
    private _countKeys;
}
//# sourceMappingURL=redis.d.ts.map