/**
 * Runtime Conduit version constant.
 * Stamped from the root `version.json` by `scripts/sync-version.ts`.
 */
export declare const VERSION = "2.0.0";
//# sourceMappingURL=version.d.ts.map